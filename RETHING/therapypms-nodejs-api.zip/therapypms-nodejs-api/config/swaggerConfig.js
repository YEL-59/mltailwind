import swaggerUi from "swagger-ui-express";
import YAML from "yamljs";
const swaggerJSDocs = YAML.load("./swagger/swagger.yaml");

const options = {
  //   customCss: `img {content:url(\'../logo.svg\'); height:auto;} `,
  //   customfavIcon: "../favicon.ico",
  customSiteTitle: "TPMS API DOC",
};

export default { swaggerServe: swaggerUi.serve, swaggerSetup: swaggerUi.setup(swaggerJSDocs, options) };
