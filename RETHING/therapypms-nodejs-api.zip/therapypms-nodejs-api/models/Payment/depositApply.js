import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const DepositApply = sequelize.define("deposit_applies", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  deopsit_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  batching_claim_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  processing_claim_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  appointment_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  provider_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  authorization_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  activity_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  dos: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  units: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  cpt: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m1: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m2: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m3: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m4: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m5: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  amount: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  payment: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  adjustment: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  balance: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  reason: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  see_payor: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  provider_24j: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  status_apply: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  billed_am: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  id_qualifier: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  degree_level: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  zone: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  units_value_calc: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  has_seceondary: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  has_claim_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  sec_submited: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  era_notes: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  hint_notes: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    timestamp: true,
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    timestamp: true,
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Appointment.sync().then(() => {
//     console.log("Appointment Model synced");
// });

export default DepositApply;
