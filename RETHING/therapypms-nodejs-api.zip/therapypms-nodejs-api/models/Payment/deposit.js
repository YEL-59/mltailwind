import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const Deposit = sequelize.define("deposits", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  payor_type: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  deposit_date: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  payment_method: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  instrument: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  instrument_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  amount: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  file: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  unapplied_amount: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  createdAt: {
    timestamp: true,
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    timestamp: true,
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Appointment.sync().then(() => {
//     console.log("Appointment Model synced");
// });

export default Deposit;
