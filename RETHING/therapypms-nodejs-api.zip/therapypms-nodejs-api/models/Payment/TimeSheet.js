import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const TimeSheet = sequelize.define("timesheets", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  provider_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  appointment_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  // payor_id: {
  //   type: DataTypes.INTEGER,
  //   allowNull: true,
  // },

  schedule_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  timein_full: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  timein_one: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  timein_two: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  timein_three: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  timeout_full: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  timeout_one: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  timeout_two: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  timeout_three: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  hours: {
    type: DataTypes.REAL,
    allowNull: true,
  },
  acceped_hours: {
    type: DataTypes.REAL,
    allowNull: true,
  },
  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  activity_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  miles: {
    type: DataTypes.REAL,
    allowNull: true,
  },
  acceped_mileage: {
    type: DataTypes.REAL,
    allowNull: true,
  },
  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  week_day: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_del: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  submitted: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_quick: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_qb: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  mileage_rate: {
    type: DataTypes.REAL,
    allowNull: true,
  },
  is_gusto: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  createdAt: {
    timestamp: true,
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    timestamp: true,
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// TimeSheet.sync().then(() => {
//     console.log("TimeSheet Model synced");
// });

export default TimeSheet;
