import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderQualification = sequelize.define("employee_qualifications", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  employee_id: {
    type: DataTypes.INTEGER,
  },

  qualification_name: {
    type: DataTypes.STRING,
  },

  qualification_date_issue: {
    type: DataTypes.DATE,
  },

  qualification_date_exp: {
    type: DataTypes.DATE,
  },

  qualification_file: {
    type: DataTypes.TEXT,
  },

  qualification_applicable: {
    type: DataTypes.INTEGER,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Admin.sync().then(() => {
//     console.log("ProviderQualification Model synced");
// });

export default ProviderQualification;
