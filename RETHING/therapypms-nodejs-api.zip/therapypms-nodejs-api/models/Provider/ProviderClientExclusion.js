import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";
import Patient from "../Patient/Patient.js";

const ProviderClientExclusion = sequelize.define("employee_client_exclusions", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
  },

  employee_id: {
    type: DataTypes.INTEGER,
  },

  client_id: {
    type: DataTypes.INTEGER,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

ProviderClientExclusion.hasOne(Patient, {
  as: "clientInfo",
  foreignKey: "id",
  sourceKey: "client_id",
});
// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default ProviderClientExclusion;
