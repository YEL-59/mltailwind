import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderClockIn = sequelize.define("employee_clock_in", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  provider_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  punch_date: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },

  time_in: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  time_out: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  status: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  pass: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  note: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

ProviderClockIn.sync().then(() => {
  console.log("ProviderClockIn Model synced");
});

export default ProviderClockIn;
