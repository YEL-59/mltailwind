import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";
import AllSubActivity from "../Setting/AllSubActivity.js";

const ProviderSubActExclusion = sequelize.define("employee_subactivity_exclusions", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: false,
  },
  
  employee_id: {
	type: DataTypes.INTEGER,
	allowNull: false,
  },
  sub_activity_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

//ProviderSubActExclusion with AllSubActivity model relation
ProviderSubActExclusion.hasOne(AllSubActivity, {
  as: "subactivity",
  foreignKey: "id",
  sourceKey: "sub_activity_id",
});

// Admin.sync().then(() => {
//     console.log("ProviderSubActExclusion Model synced");
// });

export default ProviderSubActExclusion;
