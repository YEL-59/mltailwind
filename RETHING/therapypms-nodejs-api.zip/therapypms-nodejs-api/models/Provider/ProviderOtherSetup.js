import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";
import EmployeeTypeAssign from "../Setting/EmployeeTypeAssign.js";

const ProviderOtherSetup = sequelize.define("employee_other_setups", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  employee_id: {
	type: DataTypes.INTEGER,
	allowNull: false,
  },
  
  max_hour_per_day: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  max_hour_per_week: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  adp_employee_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  provider_level: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  custom_two: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  custom_three: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  custom_four: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  custom_five: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  custom_six: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  heigh_degree: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  degree_level: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  external_software_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  signature_valid_form: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  signature_valid_to: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  signature_image: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  paid_time_off: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  exemt_staff: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  gets_paid_holiday: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  is_parttime: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  is_contractor: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  provider_render_without: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// ProviderOtherSetup.sync().then(() => {
//     console.log("ProviderOtherSetup Model synced");
// });

export default ProviderOtherSetup;
