import { DataTypes } from "sequelize";
import { sequelize } from "../../config/db.js";

const ProviderWorkSchedule = sequelize.define("staff__work__schedules", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
  },

  employee_id: {
    type: DataTypes.INTEGER,
  },

  mon_start: {
    type: DataTypes.DATE,
  },

  mon_end: {
    type: DataTypes.DATE,
  },

  tue_start: {
    type: DataTypes.DATE,
  },

  tue_end: {
    type: DataTypes.DATE,
  },

  wed_start: {
    type: DataTypes.DATE,
  },

  wed_end: {
    type: DataTypes.DATE,
  },

  thu_start: {
    type: DataTypes.DATE,
  },

  thu_end: {
    type: DataTypes.DATE,
  },

  fri_start: {
    type: DataTypes.DATE,
  },

  fri_end: {
    type: DataTypes.DATE,
  },

  sat_start: {
    type: DataTypes.DATE,
  },

  sat_end: {
    type: DataTypes.DATE,
  },

  sun_start: {
    type: DataTypes.DATE,
  },

  sun_end: {
    type: DataTypes.DATE,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// ProviderWorkSchedule.sync().then(() => {
//   console.log("ProviderWorkSchedule Model synced");
// });

export default ProviderWorkSchedule;
