import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";
import EmployeeTypeAssign from "../Setting/EmployeeTypeAssign.js";
import AllPayor from "../Setting/AllPayor.js";

const ProviderExcludePayor = sequelize.define("employee_exclude_payors", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: false,
  },
  
  payor_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  employee_id: {
	type: DataTypes.INTEGER,
	// allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// ProviderOtherSetup.sync().then(() => {
//     console.log("ProviderOtherSetup Model synced");
// });

// ProviderExcludePayor.hasOne(AllPayor, {
//     foreignKey: 'payor_id',
//     as: 'all_payor_name',
//     targetKey: 'id'
// });

ProviderExcludePayor.belongsTo(AllPayor,
	{
	  foreignKey: 'payor_id',
	  as: 'all_payor_name',
	  targetKey: 'id'
	});

export default ProviderExcludePayor;
