import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderContactDetail = sequelize.define("employee_contact_details", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  employee_id: {
    type: DataTypes.INTEGER,
  },

  address_one: {
    type: DataTypes.STRING,
  },

  address_two: {
    type: DataTypes.STRING,
  },

  city: {
    type: DataTypes.STRING,
  },

  state: {
    type: DataTypes.STRING,
  },

  zip: {
    type: DataTypes.STRING,
  },

  mobile: {
    type: DataTypes.STRING,
  },

  fax: {
    type: DataTypes.STRING,
  },

  main_phone: {
    type: DataTypes.STRING,
  },

  address_note: {
    type: DataTypes.TEXT,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default ProviderContactDetail;
