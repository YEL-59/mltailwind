import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderEmgConDetail = sequelize.define(
  "employee_emergency_contact_details",
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },

    employee_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },

    contact_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    address_one: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    address_two: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    city: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    state: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    zip: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    mobile: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    fax: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    main_phone: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    address_note: {
      type: DataTypes.TEXT,
      allowNull: true,
    },

    createdAt: {
      field: "created_at",
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: "updated_at",
      type: DataTypes.DATE,
    },
  }
);

// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default ProviderEmgConDetail;
