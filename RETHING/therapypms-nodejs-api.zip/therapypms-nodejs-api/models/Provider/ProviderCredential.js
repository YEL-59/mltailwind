import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderCredential = sequelize.define("employee_credentials", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  employee_id: {
    type: DataTypes.INTEGER,
  },

  credential_name: {
    type: DataTypes.STRING,
  },

  credential_date_issue: {
    type: DataTypes.DATE,
  },

  credential_date_expired: {
    type: DataTypes.DATE,
  },

  credential_file: {
    type: DataTypes.TEXT,
  },

  credential_applicable: {
    type: DataTypes.INTEGER,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default ProviderCredential;
