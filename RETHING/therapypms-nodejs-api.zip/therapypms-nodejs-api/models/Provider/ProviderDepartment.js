import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";
import Provider from "./Provider.js";

const ProviderDepartment = sequelize.define("employee_departments", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
  },

  employee_id: {
    type: DataTypes.INTEGER,
  },

  is_supervisor: {
    type: DataTypes.INTEGER,
  },

  supervisor_id: {
    type: DataTypes.INTEGER,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

ProviderDepartment.hasOne(Provider, {
  as: "providerName",
  foreignKey: "id",
  sourceKey: "employee_id",
});
// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default ProviderDepartment;
