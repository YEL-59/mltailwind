import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderPayroll = sequelize.define("employee_payrolls", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  employee_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  activity: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  service_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  hourly_rate: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  milage_rate: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  apply_all_activity: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Admin.sync().then(() => {
//     console.log("ProviderPayroll Model synced");
// });

export default ProviderPayroll;
