import { DataTypes } from "sequelize";
import { sequelize } from "../../config/db.js";

const ProviderBlockOffTime = sequelize.define("staff_blockoffs", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
  },

  staff_id: {
    type: DataTypes.INTEGER,
  },

  type: {
    type: DataTypes.STRING,
  },
  date: {
    type: DataTypes.DATE,
  },
  days: {
    type: DataTypes.JSON,
  },

  start_time: {
    type: DataTypes.TIME,
  },
  end_time: {
    type: DataTypes.TIME,
  },
  description: {
    type: DataTypes.STRING,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// ProviderBlockOffTime.sync().then(() => {
//   console.log("ProviderBlockOffTime Model synced");
// });

export default ProviderBlockOffTime;
