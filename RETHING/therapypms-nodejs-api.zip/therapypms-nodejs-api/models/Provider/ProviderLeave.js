import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderLeave = sequelize.define("employee_leaves", {
    id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },

    admin_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    employee_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    leave_date: {
        type: DataTypes.DATE,
        allowNull: false,
    },

    description: {
        type: DataTypes.TEXT,
        allowNull: false,
    },

    status: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    createdAt: {
        field: "created_at",
        type: DataTypes.DATE,
    },
    updatedAt: {
        field: "updated_at",
        type: DataTypes.DATE,
    },
});

// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default ProviderLeave;
