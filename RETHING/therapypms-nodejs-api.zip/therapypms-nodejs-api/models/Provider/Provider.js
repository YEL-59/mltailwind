import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";
import EmployeeTypeAssign from "../Setting/EmployeeTypeAssign.js";

const Provider = sequelize.define("employees", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  is_active: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  up_admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  employee_type: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  employee_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  first_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  middle_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  last_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  full_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  nickname: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  staff_birthday: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  ssn: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  staff_other_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  office_phone: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  office_fax: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  office_email: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  driver_license: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  license_exp_date: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  title: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  hir_date_compnay: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  credential_type: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  treatment_type: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  individual_npi: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  caqh_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  service_area_zip: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  terminated_date: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  language: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  taxonomy_code: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  gender: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  military_service: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  therapist_bill: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  is_staff_active: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  enable_fource_creation: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  has_catalsty_access: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  notes: {
	type: DataTypes.TEXT,
	allowNull: true,
  },
  login_email: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  password: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  remember_token: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  back_color: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  text_color: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  profile_photo: {
	type: DataTypes.TEXT,
	allowNull: true,
  },
  timezone: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  profile_color: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  gcalendar_integration: {
	type: DataTypes.TEXT,
	allowNull: true,
  },
  gcalendar_access_tokken: {
	type: DataTypes.TEXT,
	allowNull: true,
  },
  gcalendar_refresh_tokken: {
	type: DataTypes.TEXT,
	allowNull: true,
  },
  session_check: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  email_remainder: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  ver_code: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  ver_code_url: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  // is_qb: {
  //   type: DataTypes.INTEGER,
  //   allowNull: true,
  // },
  // qb_id: {
  //   type: DataTypes.INTEGER,
  //   allowNull: true,
  // },
  // qb_name: {
  //   type: DataTypes.INTEGER,
  //   allowNull: true,
  // },
  // provider_origin: {
  //   type: DataTypes.INTEGER,
  //   allowNull: true,
  // },
  // is_gusto: {
  // 	type: DataTypes.INTEGER,
  // 	allowNull: true,
  // },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

Provider.hasOne(EmployeeTypeAssign, {
  as: "employeeTypeAssign",
  foreignKey: "id",
  sourceKey: "credential_type",
});
// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default Provider;
