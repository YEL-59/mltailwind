import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderClearnce = sequelize.define("employee_clearances", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  employee_id: {
    type: DataTypes.INTEGER,
  },

  clearance_name: {
    type: DataTypes.STRING,
  },

  clearance_date_issue: {
    type: DataTypes.DATE,
  },

  clearance_date_exp: {
    type: DataTypes.DATE,
  },

  clearance_file: {
    type: DataTypes.TEXT,
  },

  clearance_applicable: {
    type: DataTypes.INTEGER,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default ProviderClearnce;
