import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ProviderDetailTxType = sequelize.define("employee_details_tx_types", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    // allowNull: false,
    allowNull: true,
  },

  employee_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  treatment_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  treatment_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },

  box_24j: {
    type: DataTypes.STRING,
    allowNull: false,
  },

  id_qualifire: {
    type: DataTypes.STRING,
    allowNull: false,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Admin.sync().then(() => {
//   console.log("InternalAdmin Model synced");
// });

export default ProviderDetailTxType;
