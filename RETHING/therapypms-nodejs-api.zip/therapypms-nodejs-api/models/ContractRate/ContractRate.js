import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const ContractRate = sequelize.define("rate_lists", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  treatment_type: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  activity_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  sub_activity: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  cpt_code: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  m1: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m2: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m3: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m4: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  rate_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  rate_per: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  contracted_rate: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  billed_rate: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  increasing_percentage: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  active: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  add_auth: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  degree_level: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    timestamp: true,
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    timestamp: true,
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Appointment.sync().then(() => {
//     console.log("Appointment Model synced");
// });

export default ContractRate;
