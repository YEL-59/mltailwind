import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";
import TreatmentFacility from "../Setting/TreatmentFacility.js";
import SettingService from "../Setting/SettingService.js";
import Patient from "../Patient/Patient.js";
import PatientAuthorization from "../Patient/PatientAuthorization.js";
import PatientAuthActivity from "../Patient/PatientAuthActivity.js";
import Provider from "../Provider/Provider.js";
import SettingPos from "../Setting/PointOfService.js";

const Appointment = sequelize.define("appoinments", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_mark_gen: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  g_event_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  pg_event_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  recurring_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  billable: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  client_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },
  authorization_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  authorization_activity_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },
  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  provider_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },
  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  time_duration: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  from_time: {
    type: DataTypes.TIME,
    allowNull: true,
  },
  activity_type: {
    type: DataTypes.TIME,
    allowNull: true,
  },
  to_time: {
    type: DataTypes.TIME,
    allowNull: true,
  },
  cpt_code: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  reminder_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  schedule_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  notes: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  m1: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  m2: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  m3: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  m4: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  weekly_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  week_day_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  degree_level: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  gender: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  zone: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  zip_code: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  lagunage: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  chkrecurrence: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  daily: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_locked: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_show: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  rendered_at: {
    type: DataTypes.TIME,
    allowNull: true,
  },

  createdAt: {
    timestamp: true,
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    timestamp: true,
    field: "updated_at",
    type: DataTypes.DATE,
  },
  comment: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  audit: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
});



Appointment.hasOne(Patient, {
  as: "app_patient",
  foreignKey: "id",
  sourceKey: "client_id",
});

Appointment.hasOne(PatientAuthorization, {
  as: "app_auth",
  foreignKey: "id",
  sourceKey: "authorization_id",
});

Appointment.hasOne(PatientAuthActivity, {
  as: "app_activity",
  foreignKey: "id",
  sourceKey: "authorization_activity_id",
});

Appointment.hasOne(Provider, {
  as: "app_provider",
  foreignKey: "id",
  sourceKey: "provider_id",
});

Appointment.hasOne(SettingPos, {
  as: "app_pos",
  foreignKey: "pos_code",
  sourceKey: "location",
});

Appointment.sync().then(() => {
    console.log("Appointment Model synced");
});

export default Appointment;
