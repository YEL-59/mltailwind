import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";
import SettingPos from "../Setting/PointOfService.js";

const RecurringSession = sequelize.define("recurring_sessions", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  provider_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  session_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  activity_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  provider_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  schedule_date_start: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  schedule_date_end: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  horus_form: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  horus_to: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// RecurringSession.sync().then(() => {
//   console.log("RecurringSession Data Model synced");
// });

export default RecurringSession;
