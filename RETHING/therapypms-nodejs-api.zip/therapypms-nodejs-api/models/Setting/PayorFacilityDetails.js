import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const PayorFacilityDetails = sequelize.define("payor_facility_details", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
  },
  
  name: {
	type: DataTypes.STRING,
  },
  address: {
	type: DataTypes.STRING,
  },
  city: {
	type: DataTypes.STRING,
  },
  state: {
	type: DataTypes.STRING,
  },
  zip: {
	type: DataTypes.STRING,
  },
  contact_one: {
	type: DataTypes.STRING,
  },
  contact_two: {
	type: DataTypes.STRING,
  },
  phone_one: {
	type: DataTypes.STRING,
  },
  phone_two: {
	type: DataTypes.STRING,
  },
  payor_id: {
	type: DataTypes.STRING,
  },
  is_regional_center: {
	type: DataTypes.INTEGER,
  },
  regional_center_name: {
	type: DataTypes.STRING,
  },
  billing_aber: {
	type: DataTypes.STRING,
  },
  ele_payor_id: {
	type: DataTypes.STRING,
  },
  create_by: {
	type: DataTypes.STRING,
  },
  plain_medicare: {
	type: DataTypes.STRING,
  },
  plan_medicalid: {
	type: DataTypes.STRING,
  },
  plan_campus: {
	type: DataTypes.STRING,
  },
  plan_champva: {
	type: DataTypes.STRING,
  },
  plan_group_health: {
	type: DataTypes.STRING,
  },
  plan_feca: {
	type: DataTypes.STRING,
  },
  plan_others: {
	type: DataTypes.STRING,
  },
  claim_filing_indicator: {
	type: DataTypes.STRING,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// PayorFacilityDetails.sync().then(() => {
//     console.log("Payor Facility Details Model synced");
// });

export default PayorFacilityDetails;
