import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";
import Admin from "./Admin.js";

const SettingNameLocation = sequelize.define("setting_name_locations", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
  },

  company_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  facility_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  address: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  address_two: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  city: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  state: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  zip: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  phone_one: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  short_code: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  email: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  ein: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  npi: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  taxonomy: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  //   taxonomy_code: {
  // 	type: DataTypes.STRING,
  // 	allowNull: true,
  //   },

  contact_person: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  service_area_miles: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  default_pos: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  timezone: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  //   start_time: {
  //     type: DataTypes.TIME,
  //     allowNull: true,
  //   },

  //   end_time: {
  //     type: DataTypes.TIME,
  //     allowNull: true,
  //   },

  service_area_miles: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  //   user_default_password: {
  //     type: DataTypes.STRING,
  //     allowNull: true,
  //   },

  default_pos: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  timezone: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  ftp_username: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  ftp_password: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_combo: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  email_reminder: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  ch_type: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  sop_email: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  vob_email: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// SettingNameLocation.sync().then(() => {
//     console.log("Setting Name Location Model synced");
// });

export default SettingNameLocation;
