import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const AllSubActivity = sequelize.define("all_sub_activities", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
	unique: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
  },
  
  is_billable: {
	type: DataTypes.INTEGER,
  },
  
  facility_treatment_id: {
	type: DataTypes.INTEGER,
  },
  
  service_id: {
	type: DataTypes.INTEGER,
  },
  
  sub_activity: {
	type: DataTypes.STRING,
  },
  
  is_active: {
	type: DataTypes.INTEGER,
  },
  
  hide_client_calender: {
	type: DataTypes.INTEGER,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// AllSubActivity.sync().then(() => {
//   console.log("AllSubActivity Model synced");
// });

export default AllSubActivity;
