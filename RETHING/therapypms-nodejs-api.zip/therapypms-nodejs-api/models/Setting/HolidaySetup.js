import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const HolidaySetup = sequelize.define("holiday_setups", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
	unique: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  holiday_date: {
	type: DataTypes.DATE,
	allowNull: false,
  },
  
  description: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  is_fed: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  holiday_name: {
	type: DataTypes.STRING,
	allowNull: false,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// HolidaySetup.sync().then(() => {
//   console.log("Setting HolidaySetup Model synced");
// });

export default HolidaySetup;
