import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const PayorDetailsTxType = sequelize.define("payor_details_tx_types", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  payor_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  treatment_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  treatment_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  box_24j: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  id_qualifire: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// PayorDetailsTxType.sync().then(() => {
//     console.log("Payor PayorDetailsTxType Model synced");
// });

export default PayorDetailsTxType;
