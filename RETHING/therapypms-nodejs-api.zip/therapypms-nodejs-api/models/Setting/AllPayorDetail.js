import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const AllPayorDetail = sequelize.define("all_payor_details", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
  },
  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  facility_payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  payor_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  co_pay: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  day_club: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_electronic: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  facility_32: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  facility_33: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms_1500_31: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms_1500_32a: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms_1500_32b: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms_1500_33a: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms_1500_33b: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_active: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  npi: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  tax_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  ssn: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  box_17: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms1500_32address: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms1500_32city: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms1500_32state: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms1500_32zip: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms1500_33address: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms1500_33city: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms1500_33state: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  cms1500_33zip: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  day_pay_cpt: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  //   insurance_type: {
  // 	type: DataTypes.INTEGER,
  // 	allowNull: true,
  //   },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// AllPayorDetail.sync().then(() => {
//     console.log("AllPayorDetail Model synced");
// });

export default AllPayorDetail;
