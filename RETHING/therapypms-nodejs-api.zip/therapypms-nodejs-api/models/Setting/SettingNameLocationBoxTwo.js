import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const SettingNameLocationBoxTwo = sequelize.define("setting_name_location_box_twos", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
  },

  facility_name_two: {
    type: DataTypes.STRING,
  },

  zone_name: {
    type: DataTypes.STRING,
  },

  address: {
    type: DataTypes.STRING,
  },

  //   address_two: {
  // 	type: DataTypes.STRING,
  //   },

  city: {
    type: DataTypes.STRING,
  },

  state: {
    type: DataTypes.STRING,
  },

  zip: {
    type: DataTypes.STRING,
  },

  phone_one: {
    type: DataTypes.STRING,
  },

  npi: {
    type: DataTypes.STRING,
  },

  admin_create: {
    type: DataTypes.INTEGER,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// SettingNameLocationBoxTwo.sync().then(() => {
//     console.log("SettingNameLocationBoxTwo Model synced");
// });

export default SettingNameLocationBoxTwo;
