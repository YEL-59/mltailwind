import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const Admin = sequelize.define("admins", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
  },

  company_id: {
    type: DataTypes.INTEGER,
  },

  name: {
    type: DataTypes.STRING,
  },
  first_name: {
    type: DataTypes.STRING,
  },
  last_name: {
    type: DataTypes.STRING,
  },

  email: {
    type: DataTypes.STRING,
  },

  dob: {
    field: "dob",
    type: DataTypes.DATE,
  },

  gender: {
    type: DataTypes.STRING,
  },

  phone: {
    type: DataTypes.STRING,
  },

  fax: {
    type: DataTypes.STRING,
  },

  password: {
    type: DataTypes.STRING,
  },

  login_email: {
    type: DataTypes.STRING,
  },

  gcalendar_integration: {
    type: DataTypes.TEXT,
  },
  gcalendar_access_tokken: {
    type: DataTypes.TEXT,
  },

  gcalendar_refresh_tokken: {
    type: DataTypes.TEXT,
  },

  ver_code: {
    type: DataTypes.STRING,
  },

  ver_code_url: {
    type: DataTypes.STRING,
  },

  account_status: {
    type: DataTypes.INTEGER,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
  },

  up_admin_id: {
    type: DataTypes.INTEGER,
  },

  lockout_time: {
    type: DataTypes.INTEGER,
  },

  locked_token: {
    type: DataTypes.STRING,
  },
  // profile_color: {
  // type: DataTypes.STRING,
  // },

  blocked: {
    type: DataTypes.INTEGER,
  },
  active: {
    type: DataTypes.INTEGER,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Admin.sync().then(() => {
//     console.log("InternalAdmin Model synced");
// });

export default Admin;
