import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const ApiUser = sequelize.define("api_users", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
  },
  
  facility_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  email: {
	type: DataTypes.STRING,
	allowNull: false,
  },
  password: {
	type: DataTypes.STRING,
	allowNull: false,
  },
  account_status: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  api_user_type: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  api_type: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  api_credential_type: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  api_token: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  secret_key: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  public_key: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  remember_token: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// ApiUser.sync().then(() => {
//     console.log("Api User Model synced");
// });

export default ApiUser;
