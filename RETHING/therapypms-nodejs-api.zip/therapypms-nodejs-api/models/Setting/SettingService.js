import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";
import TreatmentFacility from "./TreatmentFacility.js";

const SettingService = sequelize.define("setting_services", {
  id: {
    field: "id",
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
    type: DataTypes.BIGINT,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  facility_treatment_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  service: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  description: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  rate: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  duration: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  make_default: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  bill_in_unit: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  type: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  mileage: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// setting service with treatment facility relation
//In Sequelize, a source key is a primary key in a model, and a foreign key is a key in a model that refers to the primary key of another model
//sourceKey:Main model's key, foreignKey:related model's key
SettingService.hasOne(TreatmentFacility, {
  as: "service_treatment",
  foreignKey: "id",
  sourceKey: "facility_treatment_id",
});

// SettingService.sync().then(() => {
//     console.log("Setting Services Model synced");
// });

export default SettingService;
