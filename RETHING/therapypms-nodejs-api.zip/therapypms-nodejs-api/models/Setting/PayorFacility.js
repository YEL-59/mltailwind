import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const PayorFacility = sequelize.define("payor_facilities", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  payor_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  facility_payor_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  payor_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  address: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  city: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  state: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  zip: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  contact_one: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  contact_two: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  phone_one: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  phone_two: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  fpayor_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  is_regional_center: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  regional_center_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  billing_aber: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  ele_payor_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  create_by: {
	type: DataTypes.STRING,
  },
  plain_medicare: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  plan_medicalid: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  plan_campus: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  plan_champva: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  plan_group_health: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  plan_feca: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  plan_others: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  claim_filing_indicator: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  payor_file: {
	type: DataTypes.TEXT,
	allowNull: true,
  },
  payor_id_eligibility: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  no_box_two: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// PayorFacility.sync().then(() => {
//     console.log("Payor Facility Model synced");
// });

export default PayorFacility;
