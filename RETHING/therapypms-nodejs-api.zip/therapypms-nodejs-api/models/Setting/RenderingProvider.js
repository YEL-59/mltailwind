import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const ReferringProvider = sequelize.define("rendering_providers", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  provider_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  provider_last_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  npi: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  upin: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  id_qual: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// ReferringProviders.sync().then(() => {
//   console.log("Setting Referring Providers synced");
// });

export default ReferringProvider;
