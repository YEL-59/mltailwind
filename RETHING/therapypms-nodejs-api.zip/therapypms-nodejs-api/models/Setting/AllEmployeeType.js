import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const AllEmployeeTypes = sequelize.define("all_employee_types", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
	unique: true,
  },
  
  type_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// AllEmployeeTypes.sync().then(() => {
//   console.log("Setting AllEmployeeTypes Model synced");
// });

export default AllEmployeeTypes;
