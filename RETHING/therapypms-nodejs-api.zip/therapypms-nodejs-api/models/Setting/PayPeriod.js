import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const PayPeriod = sequelize.define("pay_periods", {
  id: {
	field: "id",
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
	type: DataTypes.BIGINT,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  period_length: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  year: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  start_date: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  
  end_date: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  
  show_start_date: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  show_end_date: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  check_date: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  
  time_sheet: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  time_sheet_date: {
	type: DataTypes.DATE,
	allowNull: true,
  },
  
  week_day_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  color: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// PayPeriod.sync().then(() => {
//   console.log("Setting PayPeriod Model synced");
// });

export default PayPeriod;
