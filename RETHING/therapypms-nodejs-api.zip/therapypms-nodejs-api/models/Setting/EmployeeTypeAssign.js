import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const EmployeeTypeAssign = sequelize.define("employee_type_assigns", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
	unique: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  type_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  type_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// EmployeeTypeAssign.sync().then(() => {
//   console.log("Setting EmployeeTypeAssign Model synced");
// });

export default EmployeeTypeAssign;
