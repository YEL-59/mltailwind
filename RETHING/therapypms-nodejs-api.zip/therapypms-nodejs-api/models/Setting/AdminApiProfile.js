import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const AdminApiProfile = sequelize.define("admin_api_profiles", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
  },
  
  city: {
	type: DataTypes.INTEGER,
  },
  country: {
	type: DataTypes.INTEGER,
  },
  state: {
	type: DataTypes.INTEGER,
  },
  zip: {
	type: DataTypes.INTEGER,
  },
  profile_photo: {
	type: DataTypes.INTEGER,
  },
  profile_color: {
	type: DataTypes.INTEGER,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// AdminApiProfile.sync().then(() => {
//     console.log("InternalAdmin Admin Api Profile Data Model synced");
// });

export default AdminApiProfile;
