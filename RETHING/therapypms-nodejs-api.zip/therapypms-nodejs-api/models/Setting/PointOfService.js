import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const SettingPos = sequelize.define("point_of_services", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  pos_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  pos_code: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_tele: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// SettingPos.sync().then(() => {
//   console.log("Setting POS Model synced");
// });

export default SettingPos;
