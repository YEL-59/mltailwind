import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const SettingNameLocationBox32 = sequelize.define(
	"setting_name_location_box_twos",
	{
	  id: {
		type: DataTypes.BIGINT,
		allowNull: false,
		primaryKey: true,
	  },
	  
	  admin_id: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  facility_name_two: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  zone_name: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  address: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  address_two: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  city: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  state: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  zip: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  phone_one: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  npi: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  admin_create: {
		type: DataTypes.INTEGER,
		allowNull: true,
	  },
	  
	  createdAt: {
		field: "created_at",
		type: DataTypes.DATE,
	  },
	  updatedAt: {
		field: "updated_at",
		type: DataTypes.DATE,
	  },
	}
);

// SettingNameLocationBox32.sync().then(() => {
//     console.log("Setting Name Location box 32 Model synced");
// });

export default SettingNameLocationBox32;
