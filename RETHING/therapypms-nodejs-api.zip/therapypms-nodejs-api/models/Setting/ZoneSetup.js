import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const ZoneSetup = sequelize.define("zone_setups", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  zone_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  description: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// ZoneSetup.sync().then(() => {
//     console.log("ZoneSetup Model synced");
// });

export default ZoneSetup;
