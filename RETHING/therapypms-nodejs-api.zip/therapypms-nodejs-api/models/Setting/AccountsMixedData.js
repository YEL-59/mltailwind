import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";
import Admin from "./Admin.js";

const AccountMixedData = sequelize.define("accounts_mixed_datas", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
  },
  
  expected: {
	type: DataTypes.FLOAT,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// AccountMixedData.sync().then(() => {
//     console.log("InternalAdmin Account Mixed Data Model synced");
// });

export default AccountMixedData;
