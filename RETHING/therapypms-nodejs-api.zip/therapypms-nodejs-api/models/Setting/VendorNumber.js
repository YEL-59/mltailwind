import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const VendorNumber = sequelize.define("vendor_numbers", {
  id: {
	field: "id",
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
	type: DataTypes.BIGINT,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  service_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  treatment_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  regional_center_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  vendor_no: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  service_code: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// VendorNumber.sync().then(() => {
//   console.log("Setting VendorNumbers Model synced");
// });

export default VendorNumber;
