import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const TreatmentFacility = sequelize.define("treatment_facilities", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  treatment_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  treatment_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// TreatmentFacility.sync().then(() => {
//     console.log("Treatment Facility Model synced");
// });

export default TreatmentFacility;
