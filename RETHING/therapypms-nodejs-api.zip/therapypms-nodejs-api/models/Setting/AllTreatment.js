import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const AllTreatment = sequelize.define("all_treatments", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
  },
  
  treatment_name: {
	type: DataTypes.STRING,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// AllTreatment.sync().then(() => {
//     console.log("All Treatment Model synced");
// });

export default AllTreatment;
