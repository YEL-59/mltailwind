import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const CptCodeExclusions = sequelize.define("cpt_code_exclusions", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
  },
  
  cpt_code_id: {
	type: DataTypes.INTEGER,
  },
  
  cpt_code: {
	type: DataTypes.STRING,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// CptCodeExclusions.sync().then(() => {
//     console.log("CptCodeExclusions Model synced");
// });

export default CptCodeExclusions;
