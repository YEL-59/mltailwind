import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";
import TreatmentFacility from "./TreatmentFacility.js";

const SettingCptCode = sequelize.define("setting_cpt_codes", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
	autoIncrement: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  cpt_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  facility_treatment_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  cpt_code: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// setting cpt codes with treatment facility relation
SettingCptCode.hasOne(TreatmentFacility, {
  as: "treatment_details",
  foreignKey: "id",
  sourceKey: "facility_treatment_id",
});

// SettingCptCode.sync().then(() => {
//     console.log("Setting Cpt Code Model synced");
// });

export default SettingCptCode;
