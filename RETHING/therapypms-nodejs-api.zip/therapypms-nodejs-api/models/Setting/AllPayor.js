import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const AllPayor = sequelize.define("all_payors", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
  },
  
  facility_payor_id: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  payor_name: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  co_pay: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  day_club: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  is_electronic: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  cms_1500_31: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  cms_1500_32a: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  cms_1500_32b: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  cms_1500_33a: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  cms_1500_33b: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  is_active: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  npi: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  tax_id: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  ssn: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  box_17: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  cms150032_address: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  cms150033_address: {
	type: DataTypes.STRING,
	allowNull: true,
  },
  day_pay_cpt: {
	type: DataTypes.INTEGER,
	allowNull: true,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// AllPayor.sync().then(() => {
//     console.log("All Payor Model synced");
// });

export default AllPayor;
