import {sequelize} from "../../config/db.js";
import {DataTypes} from "sequelize";

const SettingWorkingHour = sequelize.define("setting_working_hours", {
  id: {
	type: DataTypes.BIGINT,
	allowNull: false,
	primaryKey: true,
  },
  
  admin_id: {
	type: DataTypes.INTEGER,
  },
  
  monday: {
	type: DataTypes.DATE,
  },
  
  mon_start_time: {
	type: DataTypes.DATE,
  },
  
  mon_end_time: {
	type: DataTypes.DATE,
  },
  
  tus_start: {
	type: DataTypes.DATE,
  },
  
  tus_end: {
	type: DataTypes.DATE,
  },
  
  wed_start: {
	type: DataTypes.DATE,
  },
  
  wed_end: {
	type: DataTypes.DATE,
  },
  
  thur_start: {
	type: DataTypes.DATE,
  },
  
  thur_end: {
	type: DataTypes.DATE,
  },
  
  fri_start: {
	type: DataTypes.DATE,
  },
  
  fri_end: {
	type: DataTypes.DATE,
  },
  
  sat_start: {
	type: DataTypes.DATE,
  },
  
  sat_end: {
	type: DataTypes.DATE,
  },
  
  sun_start: {
	type: DataTypes.DATE,
  },
  
  sun_end: {
	type: DataTypes.DATE,
  },
  
  createdAt: {
	field: "created_at",
	type: DataTypes.DATE,
  },
  updatedAt: {
	field: "updated_at",
	type: DataTypes.DATE,
  },
});

// SettingWorkingHour.sync().then(() => {
//     console.log("SettingWorkingHour Model synced");
// });

export default SettingWorkingHour;
