import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";
import PriManageClaimTransaction from "./ManageClaimTransaction.js";
import ProcessClaim from "./ProcessClaim.js";
import Patient from "../Patient/Patient.js";
import PayorFacility from "../Setting/PayorFacility.js";

const PriManageClaim = sequelize.define("manage_claims", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  baching_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  claim_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  batch_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  appointment_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  provider_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  activity_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  authorization_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  activity_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  schedule_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  cpt: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m1: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m2: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m3: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m4: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  pos: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  units: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  rate: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  cms_24j: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  id_qualifier: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  degree_level: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  zone: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  units_value_calc: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  billed_am: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  billed_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  is_mark_gen: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  resubmit_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  box_19: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  resubmit_code: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  orginal_ref_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  auth_no: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  is_primary: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Appointment.sync().then(() => {
//     console.log("Appointment Model synced");
// });

PriManageClaim.hasMany(PriManageClaimTransaction, {
  as: "mngclam_tran_asc",
  foreignKey: "claim_id",
  sourceKey: "claim_id",
});

PriManageClaim.hasMany(PriManageClaimTransaction, {
  as: "mngclam_tran_desc",
  foreignKey: "claim_id",
  sourceKey: "claim_id",
});

PriManageClaim.hasMany(PriManageClaimTransaction, {
  as: "mngclam_tran",
  foreignKey: "claim_id",
  sourceKey: "claim_id",
});

PriManageClaim.hasOne(Patient, {
  as: "mngclam_patient",
  foreignKey: "id",
  sourceKey: "client_id",
});



export default PriManageClaim;
