import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const Ledger = sequelize.define("ledger_lists", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  batching_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  processing_claim_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  appointment_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  provider_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  authorization_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  activity_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  activity_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  schedule_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  cpt: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m1: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m2: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m3: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m4: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  pos: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  units: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  rate: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  cms_24j: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  id_qualifier: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  zone: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  units_value_calc: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  billed_am: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  billed_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  is_mark_gen: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  has_manage_claim: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  category_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  followup_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  worked_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Appointment.sync().then(() => {
//     console.log("Appointment Model synced");
// });

export default Ledger;
