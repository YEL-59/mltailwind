import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";
import PatientAuthorization from "../Patient/PatientAuthorization.js";
import Appointment from "../Appointment/Appointment.js";
import PayorFacility from "../Setting/PayorFacility.js";
import Patient from "../Patient/Patient.js";
import Provider from "../Provider/Provider.js";
import PatientAuthActivity from "../Patient/PatientAuthActivity.js";

const ProcessClaim = sequelize.define("processing_claims", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  appointment_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  provider_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  authorization_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  activity_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  activity_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  schedule_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  from_time: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  to_time: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  time_duration: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  cpt: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m1: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m2: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m3: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m4: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  pos: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  units: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  rate: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  cms_24j: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  id_qualifier: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  degree_level: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  zone: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  units_value_calc: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  is_mark_gen: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  has_deposit: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Appointment.sync().then(() => {
//     console.log("Appointment Model synced");
// });

ProcessClaim.hasOne(PayorFacility, {
  as: "procc_payor",
  foreignKey: "payor_id",
  sourceKey: "payor_id",
});

ProcessClaim.hasOne(Patient, {
  as: "procc_patient",
  foreignKey: "id",
  sourceKey: "client_id",
});

ProcessClaim.hasOne(Provider, {
  as: "procc_provider",
  foreignKey: "id",
  sourceKey: "provider_id",
});

ProcessClaim.hasOne(Provider, {
  as: "procc_provider_cms",
  foreignKey: "id",
  sourceKey: "cms_24j",
});

ProcessClaim.hasOne(PatientAuthorization, {
  as: "procc_patient_auth",
  foreignKey: "id",
  sourceKey: "authorization_id",
});

ProcessClaim.hasOne(PatientAuthActivity, {
  as: "procc_patient_auth_act",
  foreignKey: "id",
  sourceKey: "activity_id",
});

export default ProcessClaim;
