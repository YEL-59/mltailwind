import { sequelize } from "../../config/db.js";
import { DataTypes, Sequelize } from "sequelize";
import Patient from "../Patient/Patient.js";
import Provider from "../Provider/Provider.js";
import ProcessClaim from "./ProcessClaim.js";
import PayorFacility from "../Setting/PayorFacility.js";

const PriManageClaimTransaction = sequelize.define("manage_claim_transactions", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  baching_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  processing_claim_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  claim_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  batch_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  appointment_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  provider_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  authorization_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  activity_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  activity_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  schedule_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  from_time: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  to_time: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  cpt: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m1: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m2: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m3: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m4: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  pos: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  units: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  is_primary: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  rate: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  cms_24j: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  degree_level: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  zone: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  location: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  units_value_calc: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  billed_am: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  billed_date: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  is_mark_gen: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  resubmit_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  box_19: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  resubmit_code: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  orginal_ref_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  auth_no: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  is_primary: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  control_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  isa_control_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  isa_status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  tnine_status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// Appointment.sync().then(() => {
//     console.log("Appointment Model synced");
// });

PriManageClaimTransaction.hasOne(Patient, {
  as: "pri_mngclmtrn_patient",
  foreignKey: "id",
  sourceKey: "client_id",
});

PriManageClaimTransaction.hasOne(Provider, {
  as: "pri_mngclm_cms_provider",
  foreignKey: "id",
  sourceKey: "cms_24j",
});

PriManageClaimTransaction.hasOne(ProcessClaim, {
  as: "pri_mngclmtrn_prcclm",
  foreignKey: "id",
  sourceKey: "processing_claim_id",
});

PriManageClaimTransaction.hasOne(PayorFacility, {
  as: "pri_mngclmtrn_payor",
  foreignKey: "payor_id",
  sourceKey: "payor_id",
});

export default PriManageClaimTransaction;
