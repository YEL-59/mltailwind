import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientCallLog = sequelize.define("client_calllogs", {
    id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },

    admin_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    client_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    call_log: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    log_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    createdAt: {
        field: "created_at",
        type: DataTypes.DATE,
    },
    updatedAt: {
        field: "updated_at",
        type: DataTypes.DATE,
    },
});

// PatientCallLog.sync().then(() => {
//     console.log("PatientCallLog Facility Model synced");
// });



export default PatientCallLog;
