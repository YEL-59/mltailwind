import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientAuthActivity = sequelize.define("client_authorization_activities", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  rate_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  dup_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  activity_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  authorization_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  activity_one: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  activity_one_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  activity_two: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  cpt_code: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  onset_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  end_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  m1: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  m2: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  m3: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  m4: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  auth_activity: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  billed_type: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  billed_time: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  rate: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  hours_max_one: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  hours_max_per_one: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  hours_max_is_one: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  hours_max_two: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  hours_max_per_two: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  hours_max_is_two: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  hours_max_three: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  hours_max_per_three: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  hours_max_is_three: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  // contracted_rate: {
  //   type: DataTypes.DOUBLE,
  //   allowNull: true,
  // },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

export default PatientAuthActivity;
