import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientActivity = sequelize.define("client_activities", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  who_created: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  title: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  message: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  act_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

export default PatientActivity;
