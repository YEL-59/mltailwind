import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientInfo = sequelize.define("client_infos", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_active_client: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  client_gender_identity: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  client_relationship: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  client_employe_status: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  race_ethnicity: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  race_ethnicity_details: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  preferred_language: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  client_notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  client_date_first_seen: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  client_reffered_by: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  relationship: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  asignment: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_guarantor: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  signature_image: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  phy_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

export default PatientInfo;
