import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientStatus = sequelize.define("client_statuses", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  title: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  is_active: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// PatientStatus.sync().then(() => {
//   console.log("PatientStatus Data Model synced");
// });

export default PatientStatus;
