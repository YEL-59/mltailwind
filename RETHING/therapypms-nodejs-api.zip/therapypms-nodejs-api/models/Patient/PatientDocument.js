import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientDocument = sequelize.define("client_documents", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  file_name: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  exp_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  created_by: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  type: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  intake_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  file_name_temp: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// PatientDocument.sync().then(() => {
//   console.log("PatientDocument Model synced");
// });

export default PatientDocument;
