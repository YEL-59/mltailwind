import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientGurantorInfo = sequelize.define("client_guarantar_infos", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  guarantor_first_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  guarantor_last_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  guarantor_dob: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  guarantor_relationship: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  g_street: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  g_city: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  g_state: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  g_zip: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// PatientGurantorInfo.sync().then(() => {
//   console.log(" PatientGurantorInfo Model synced");
// });

export default PatientGurantorInfo;
