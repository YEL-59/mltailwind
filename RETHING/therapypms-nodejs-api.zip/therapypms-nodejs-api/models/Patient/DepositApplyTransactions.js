import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const DepositApplyTransaction = sequelize.define("deposit_apply_transactions", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  deposit_apply_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  processing_claim_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  batching_claim_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  appointment_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  authorization_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  activity_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },

  dos: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  units: {
    type: DataTypes.REAL,
    allowNull: true,
  },

  cpt: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  instrument: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  code: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m1: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  amount: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  payment: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  adjustment: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },

  balance: {
    type: DataTypes.REAL,
    allowNull: true,
  },

  reason: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m2: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m3: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m4: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  m5: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  who_paid: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  instrument_no: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  has_seceondary: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

// DepositApplyTransaction.sync().then(() => {
//   console.log("DepositApplyTransaction Data Model synced");
// });

export default DepositApplyTransaction;
