import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientPhone = sequelize.define("client_phones", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  phone_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  phone_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  is_send_sms: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_voice_sms: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

export default PatientPhone;
