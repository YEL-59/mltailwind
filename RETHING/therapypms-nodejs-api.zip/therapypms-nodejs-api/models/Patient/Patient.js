import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const Patient = sequelize.define("clients", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_active_client: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_type: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_full_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_first_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_middle: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_last_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_preferred: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_gender: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_dob: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  email: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  email_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  email_reminder: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  is_email_ok: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  phone_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  phone_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  is_send_sms: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_voice_sms: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  location: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  zone: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_street: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_city: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_state: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  client_zip: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  profile_photo: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  supervisor_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  login_email: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  password: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  remember_token: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  profile_color: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  timezone: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  intake: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  intake_uploaded: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  intake_form: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  // intake_multiple: {
  //   type: DataTypes.JSON,
  //   allowNull: true,
  // },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

export default Patient;
