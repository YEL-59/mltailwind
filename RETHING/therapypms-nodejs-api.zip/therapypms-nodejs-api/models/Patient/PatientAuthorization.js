import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientAuthorization = sequelize.define("client_authorizations", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  authorization_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  payor_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  treatment_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  treatment_type_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  supervisor_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  description: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  selected_date: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  onset_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  end_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  authorization_number: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  uci_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  cms_four: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  csm_eleven: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  diagnosis_one: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  diagnosis_two: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  diagnosis_three: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  diagnosis_four: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  deductible: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  in_network: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  copay: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  max_total_auth: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  value: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  upload_authorization: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

  is_primary: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_placeholder: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_valid: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_required: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

export default PatientAuthorization;
