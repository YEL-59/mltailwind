import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientEmail = sequelize.define("client_emails", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  is_up_admin: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  email: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  email_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  email_reminder: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  is_email_ok: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

export default PatientEmail;
