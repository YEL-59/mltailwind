import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientColors = sequelize.define("client_colors", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  provider_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  back_color: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  text_color: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },
});

export default PatientColors;
