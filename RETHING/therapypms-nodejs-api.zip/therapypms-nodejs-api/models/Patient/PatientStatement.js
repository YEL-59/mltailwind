import { sequelize } from "../../config/db.js";
import { DataTypes } from "sequelize";

const PatientStatement = sequelize.define("patient_statements", {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },

  admin_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  down_admin_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  dep_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  deposit_apply_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  client_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  service_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },

  activity_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  co_pay: {
    type: DataTypes.REAL,
    allowNull: true,
  },
  coins: {
    type: DataTypes.REAL,
    allowNull: true,
  },
  ded: {
    type: DataTypes.REAL,
    allowNull: true,
  },
  status: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  // is_voice_sms: {
  //   type: DataTypes.INTEGER,
  //   allowNull: true,
  // },
  is_paid: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_submit: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },

  createdAt: {
    field: "created_at",
    type: DataTypes.DATE,
  },
  updatedAt: {
    field: "updated_at",
    type: DataTypes.DATE,
  },

  processing_claim_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },
  appointment_id: {
    type: DataTypes.BIGINT,
    allowNull: true,
  },
  pr: {
    type: DataTypes.REAL,
    allowNull: true,
  },
});

// PatientStatement.sync().then(() => {
//   console.log("PatientStatement Data Model synced");
// });

export default PatientStatement;
