import Appointment from "../../../models/Appointment/Appointment.js";
import {getPagination} from "../../../helpers/pagination.js";

const getAppointment = async (req, res, next) => {
  try {
	
	
  } catch (e) {
	
  }
};

export default {
  getAppointment
}

