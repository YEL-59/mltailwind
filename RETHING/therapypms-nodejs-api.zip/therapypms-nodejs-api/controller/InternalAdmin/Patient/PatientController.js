import { INTEGER, Op, Sequelize } from "sequelize";
import { parseISO, format } from "date-fns";
import moment from "moment";
import Patient from "../../../models/Patient/Patient.js";
import PatientInfo from "../../../models/Patient/PatientInfo.js";
import { getPagination, getPagingData } from "../../../helpers/pagination.js";
import PatientPhone from "../../../models/Patient/PatientPhone.js";
import PatientEmail from "../../../models/Patient/PatientEmail.js";
import PatientAddress from "../../../models/Patient/PatientAddress.js";
import SettingNameLocationBoxTwo from "../../../models/Setting/SettingNameLocationBoxTwo.js";
import ZoneSetup from "../../../models/Setting/ZoneSetup.js";
import ReferringProvider from "../../../models/Setting/RenderingProvider.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import SettingNameLocation from "../../../models/Setting/SettingNameLocation.js";
import SettingCptCode from "../../../models/Setting/SettingCptCode.js";
import AllSubActivity from "../../../models/Setting/AllSubActivity.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import ProviderDepartment from "../../../models/Provider/ProviderDepartment.js";
import TreatmentFacility from "../../../models/Setting/TreatmentFacility.js";
import PayorFacility from "../../../models/Setting/PayorFacility.js";
import PatientGurantorInfo from "../../../models/Patient/PatientGurantorInfo.js";
import Appointment from "../../../models/Appointment/Appointment.js";
import PatientActivity from "../../../models/Patient/PatientActivity.js";
import PatientCallLog from "../../../models/Patient/PatientCallLog.js";
import SettingService from "../../../models/Setting/SettingService.js";

const patientCreate = async (req, res, next) => {
  try {
    const {
      first_name,
      middle_name,
      last_name,
      email,
      email_type,
      email_reminder,
      phone_number,
      phone_type,
      is_send_sms,
      is_voice_sms,
      location,
      gender,
      dob,
      is_active,
    } = req.body;

    const checkExists = await Patient.findOne({
      where: {
        admin_id: req.user.id,
        email: email,
      },
    });

    if (checkExists) {
      res.json({
        status: "error",
        message: "Patient already exist",
      });
      return false;
    }

    const full_name = `${first_name}  ${middle_name} ${last_name}`;

    const newPatientCreate = await Patient.create({
      admin_id: req.user.id,
      client_full_name: full_name,
      client_first_name: first_name,
      client_last_name: last_name,
      email: email,
      email_type: email_type,
      email_reminder: email_reminder,
      phone_number: phone_number,
      phone_type: phone_type,
      is_send_sms: is_send_sms,
      is_voice_sms: is_voice_sms,
      location: location,
      client_gender: gender,
      client_dob: dob,
      is_active_client: is_active,
    });

    const patientInfoCreate = await PatientInfo.create({
      admin_id: req.user.id,
      client_id: newPatientCreate.id,
      is_active_client: 1,
    });

    res.json({
      status: "success",
      message: "Patient successfully created",
      data: newPatientCreate,
      patient_info: patientInfoCreate,
    });
  } catch (e) {
    console.log(e.message);
    res.status(500).send("Server error");
  }
};

const patientList = async (req, res, next) => {
  try {
    const { page } = req.body;
    const { perPage, offset } = getPagination(page);

    const patientList = await Patient.findAndCountAll({
      where: {
        admin_id: req.user.id,
      },
      order: [["client_full_name", "ASC"]],
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "Patient List",
      data: getPagingData(patientList, page, perPage),
    });
  } catch (e) {
    console.log(e.message);
    res.status(500).send("Server error");
  }
};

const patientStatusChange = async (req, res, next) => {
  try {
    const { patient_id, is_active } = req.body;

    const patient = await Patient.findOne({
      where: {
        admin_id: req.user.id,
        id: patient_id,
      },
    });
    patient.set({
      is_active_client: is_active,
    });
    await patient.save();

    res.json({
      status: "success",
      message: "Patient active status changed successfully",
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

// ================ PATIENT INFO START ================
const patientInfo = async (req, res, next) => {
  try {
    const { patient_id } = req.body;
    const client = await Patient.findOne({
      where: {
        id: patient_id,
        admin_id: req.user.id,
      },
    });

    const phones = await PatientPhone.findAll({
      where: {
        client_id: patient_id,
        admin_id: req.user.id,
      },
    });

    const emails = await PatientEmail.findAll({
      where: {
        client_id: patient_id,
        admin_id: req.user.id,
      },
    });

    const address = await PatientAddress.findAll({
      where: {
        client_id: patient_id,
        admin_id: req.user.id,
      },
    });

    const allZone = await ZoneSetup.findAll();

    const renProviders = await ReferringProvider.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    let clientInfo = await PatientInfo.findOne({
      where: {
        client_id: patient_id,
        admin_id: req.user.id,
      },
    });

    if (!clientInfo) {
      clientInfo = await PatientInfo.create({
        client_id: client.id,
        admin_id: req.user.id,
      });
    }

    const guarantorInfoInstance = await PatientGurantorInfo.findOne({
      where: {
        client_id: patient_id,
        admin_id: req.user.id,
      },
    });

    let guarantorInfo;
    if (guarantorInfoInstance) {
      guarantorInfo = guarantorInfoInstance;
    } else {
      const lastRecord = await PatientGurantorInfo.findOne({
        order: [["id", "DESC"]],
      });
      guarantorInfo = await PatientGurantorInfo.create({
        id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
        client_id: patient_id,
        admin_id: req.user.id,
        // is_up_admin: req.user.is_up_admin == 1 ? 1 : 2,
        // down_admin_id: req.user.is_up_admin == 1 ? 0 : req.user.id,
      });
    }

    const box32 = await SettingNameLocationBoxTwo.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.status(200).json({
      status: "success",
      message: "patient info get",
      data: {
        client_info: client,
        client_other_info: clientInfo,
        phones: phones,
        emails: emails,
        address: address,
        guarantor_info: guarantorInfo,
        all_zone: allZone,
        box_32: box32,
        ren_providers: renProviders,
      },
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

const patientInfoUpdate = async (req, res, next) => {
  try {
    const {
      client_edit_id,
      client_first_name,
      client_middle,
      client_last_name,
      client_preferred,
      client_phone,
      client_phone_type,
      is_voice_sms,
      is_send_sms,
      client_email,
      client_email_type,
      email_reminder,
      is_email_ok,
      client_dob,
      client_gender,
      client_street,
      client_city,
      client_state,
      client_zip,
      location,
      zone,
      is_active_client,
      client_gender_identity,
      client_relationship,
      client_employe_status,
      race_ethnicity,
      race_ethnicity_details,
      preferred_language,
      client_notes,
      client_date_first_seen,
      client_reffered_by,
      relationship,
      asignment,
      phy_type,
      is_guarantor,
      guarantor_first_name,
      guarantor_last_name,
    } = req.body;

    // Basic Patient Info Update
    const patientInstance = await Patient.findOne({
      where: {
        id: client_edit_id,
        admin_id: req.user.id,
      },
    });

    patientInstance.is_active_client = is_active_client;
    patientInstance.client_full_name = `${client_first_name} ${client_middle} ${client_last_name}`;
    patientInstance.client_first_name = client_first_name;
    patientInstance.client_middle = client_middle;
    patientInstance.client_last_name = client_last_name;
    patientInstance.client_preferred = client_preferred;
    patientInstance.phone_number = client_phone;
    patientInstance.phone_type = client_phone_type;
    patientInstance.is_voice_sms = is_voice_sms;
    patientInstance.is_send_sms = is_send_sms;
    patientInstance.email = client_email;
    patientInstance.email_type = client_email_type;
    patientInstance.email_reminder = email_reminder;
    patientInstance.is_email_ok = is_email_ok;
    patientInstance.client_dob = format(parseISO(client_dob), "yyyy-MM-dd");
    patientInstance.client_gender = client_gender;
    patientInstance.client_street = client_street;
    patientInstance.client_city = client_city;
    patientInstance.client_state = client_state;
    patientInstance.client_zip = client_zip;
    patientInstance.location = location;
    patientInstance.zone = zone;
    await patientInstance.save();

    // Other Patient Info Update
    const patientInfoInstance = await patientInfo.findOne({
      where: {
        client_id: client_edit_id,
        admin_id: req.user.id,
      },
    });

    patientInfoInstance.is_active_client = is_active_client;
    patientInfoInstance.client_gender_identity = client_gender_identity;
    patientInfoInstance.client_relationship = client_relationship;
    patientInfoInstance.client_employe_status = client_employe_status;
    patientInfoInstance.race_ethnicity = race_ethnicity;
    patientInfoInstance.race_ethnicity_details = race_ethnicity_details;
    patientInfoInstance.preferred_language = preferred_language;
    patientInfoInstance.client_notes = client_notes;
    patientInfoInstance.client_date_first_seen = format(parseISO(client_date_first_seen), "yyyy-MM-dd");
    patientInfoInstance.client_reffered_by = client_reffered_by;
    patientInfoInstance.relationship = relationship;
    patientInfoInstance.asignment = asignment;
    patientInfoInstance.phy_type = phy_type;
    patientInfoInstance.is_guarantor = is_guarantor;

    await patientInfoInstance.save();

    // Guarantor Info Update
    const guarantorInfoInstance = await guarantorInfo.findOne({
      where: {
        client_id: client_edit_id,
        admin_id: req.user.id,
      },
    });
    guarantorInfoInstance.guarantor_first_name = request.guarantor_first_name;
    guarantorInfoInstance.guarantor_last_name = request.guarantor_last_name;
    guarantorInfoInstance.guarantor_relationship = request.guarantor_relationship;
    guarantorInfoInstance.guarantor_dob = moment(request.guarantor_dob).format("YYYY-MM-DD");
    guarantorInfoInstance.g_street = request.g_street;
    guarantorInfoInstance.g_city = request.g_city;
    guarantorInfoInstance.g_state = request.g_state;
    guarantorInfoInstance.g_zip = request.g_zip;

    await guarantorInfoInstance.save();
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

const clientExtraPhoneDelete = async (req, res) => {
  try {
    const deletePhone = await PatientPhone.findOne({
      where: {
        id: req.body.phoneid,
        admin_id: req.user.id,
      },
    });
    if (deletePhone) {
      await deletePhone.destroy();
      res.status(200).send({ message: "Phone number deleted successfully." });
    } else {
      res.status(404).send({ error: "Phone number not found." });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({ error: "Server error. Failed to delete phone number." });
  }
};
const clientExtraEmailDelete = async (req, res) => {
  try {
    const deleteEmail = await PatientEmail.findOne({
      where: {
        id: req.body.emailid,
        admin_id: req.user.id,
      },
    });
    if (deleteEmail) {
      await deleteEmail.destroy();
      res.status(200).send({ message: "Email address deleted successfully." });
    } else {
      res.status(404).send({ error: "Email address not found." });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({ error: "Server error. Failed to delete email address." });
  }
};

const clientExtraAddressDelete = async (req, res) => {
  try {
    const deleteAddress = await PatientAddress.findOne({
      where: {
        id: req.body.addressid,
        admin_id: req.user.id,
      },
    });
    if (deleteAddress) {
      await deleteAddress.destroy();
      res.status(200).send({ message: "Address deleted successfully." });
    } else {
      res.status(404).send({ error: "Address not found." });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({ error: "Server error. Failed to delete address." });
  }
};

// ================ PATIENT INFO END ================

// ================ PATIENT AUTHORIZATION START ================

const patientAuthList = async (req, res, next) => {
  try {
    const id = req.body.client_id;
    const client_id = await Patient.findOne({ where: { id, admin_id: req.user.id } });
    const allAuthorization = await PatientAuthorization.findAll({
      where: { client_id: id, admin_id: req.user.id },
      order: [["id", "DESC"]],
    });
    const selectedPayors = await PayorFacility.findAll({
      where: { admin_id: req.user.id },
      attributes: ["id", "payor_id", "payor_name"],
    });
    const allSubActivity = await AllSubActivity.findAll({
      where: { admin_id: req.user.id },
      order: [["sub_activity", "ASC"]],
    });
    const nameLocation = await SettingNameLocation.findOne({
      where: { admin_id: req.user.id },
      attributes: ["id", "admin_id", "is_combo"],
    });
    return res.status(200).json({
      message: "success",
      client_id,
      allAuthorization,
      selectedPayors,
      allSubActivity,
      nameLocation,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
};

const patientAuthorizationCreateInfo = async (req, res, next) => {
  try {
    const { id } = req.params;
    const adminId = req.user.id;
    // const patientDataExists = await Patient.findOne({
    //   where: {
    //     id,
    //     admin_id: adminId,
    //     client_first_name: null,
    //     client_last_name: null,
    //     client_dob: null,
    //     client_gender: null,
    //     location: null,
    //     zone: null,
    //     client_street: null,
    //     client_city: null,
    //     client_state: null,
    //     client_zip: null,
    //   },
    // });

    // if (patientDataExists) {
    //   return res.status(400).json({
    //     message: "Please complete the client info to create authorization",
    //   });
    // }

    // const patientInfoDataExists = await patientInfo.findOne({
    //   where: {
    //     client_id: id,
    //     admin_id: adminId,
    //     relationship: null,
    //   },
    // });

    // if (patientInfoDataExists) {
    //   return res.status(400).json({
    //     message: "Please complete the client info to create authorization",
    //   });
    // }

    const patient = await Patient.findOne({
      where: {
        id,
        admin_id: adminId,
      },
    });

    const allPayors = await PayorFacility.findAll({
      where: { admin_id: adminId },
      order: [["payor_name", "asc"]],
    });
    const supervisors = await ProviderDepartment.findAll({
      where: { is_supervisor: 1, admin_id: adminId },
      include: ["providerName"],
      attributes: ["employee_id"],
    });
    const treatmentTypes = await TreatmentFacility.findAll({
      where: { admin_id: adminId },
      order: [["treatment_name", "asc"]],
    });

    return res.status(200).json({
      message: "success",
      patient,
      allPayors,
      supervisors,
      treatmentTypes,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send("Internal Server Error");
  }
};

const patientAuthCreate = async (req, res, next) => {
  try {
    const {
      select_date,
      authorization_number,
      client_id,
      description,
      payor_id,
      treatment_type,
      supervisor_id,
      uci_id,
      max_total_auth,
      value,
      diagnosis_one,
      diagnosis_two,
      diagnosis_three,
      diagnosis_four,
      deductible,
      in_network,
      copay,
      cms_four,
      csm_eleven,
      notes,
      is_primary,
      is_placeholder,
      is_valid,
      is_required,
    } = req.body;

    const date = select_date;
    const first_date = select_date.substring(0, 10);
    const second_date = select_date.substring(12);
    const onset_date = moment(first_date, "MM/DD/YYYY").format("YYYY-MM-DD");
    const end_date = moment(second_date, "MM/DD/YYYY").format("YYYY-MM-DD");

    const checkExistsAuth = await PatientAuthorization.findOne({
      where: {
        authorization_number,
        is_required: { [Sequelize.Op.ne]: 1 },
        client_id,
        admin_id: req.user.id,
      },
    });

    if (checkExistsAuth) {
      return res.status(200).json({
        message: "Authorization number already exists",
      });
    } else {
      const lastRecord = await PatientAuthorization.findOne({
        order: [["id", "DESC"]],
      });
      console.log("lastRecord", lastRecord);
      const newAuthorization = new PatientAuthorization();
      // if (req.body.file) {
      //   const uploadPath = "assets/dashboard/authorization/";
      //   const imageUrl = uploadPath + req.file.filename;
      //   newAuthorization.upload_authorization = imageUrl;
      // }

      const payoData = await PayorFacility.findOne({ where: { payor_id } });
      const payor_name = payoData ? payoData.payor_name : "";

      const tretTypeName = await TreatmentFacility.findOne({
        where: {
          admin_id: req.user.id,
          treatment_name: treatment_type,
        },
      });

      newAuthorization.id = lastRecord ? parseInt(lastRecord.id) + 1 : 1;
      newAuthorization.admin_id = req.user.id;
      // newAuthorization.is_up_admin = req.user.is_up_admin === 1 ? 1 : 2;
      // newAuthorization.down_admin_id = req.user.is_up_admin === 1 ? 0 : req.user.id;
      newAuthorization.authorization_name = `${payor_name} ${treatment_type}`;
      newAuthorization.client_id = client_id;
      newAuthorization.description = description;
      newAuthorization.payor_id = payor_id;
      newAuthorization.treatment_type = treatment_type;
      newAuthorization.treatment_type_id = tretTypeName ? tretTypeName.id : 0;
      newAuthorization.supervisor_id = supervisor_id;
      newAuthorization.onset_date = onset_date;
      newAuthorization.end_date = end_date;
      newAuthorization.selected_date = select_date;
      newAuthorization.authorization_number = authorization_number;
      newAuthorization.uci_id = uci_id;
      newAuthorization.max_total_auth = max_total_auth;
      newAuthorization.value = value;
      newAuthorization.diagnosis_one = diagnosis_one;
      newAuthorization.diagnosis_two = diagnosis_two;
      newAuthorization.diagnosis_three = diagnosis_three;
      newAuthorization.diagnosis_four = diagnosis_four;
      newAuthorization.deductible = deductible;
      newAuthorization.in_network = in_network;
      newAuthorization.copay = copay;
      newAuthorization.cms_four = cms_four;
      newAuthorization.csm_eleven = csm_eleven;
      newAuthorization.notes = notes;
      if (is_primary !== null || is_primary !== "") {
        newAuthorization.is_primary = is_primary;
      }
      newAuthorization.is_placeholder = is_placeholder;
      newAuthorization.is_valid = is_valid;
      newAuthorization.is_required = is_required ? 1 : 2;
      await newAuthorization.save();

      return res.status(200).json({
        message: "success",
        newAuthorization,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
};

const patientAuthSingle = async (req, res, next) => {
  const { id } = req.params;
  const adminId = req.user.id;
  console.log(id);
  try {
    const editAuthorization = await PatientAuthorization.findOne({
      where: { id, admin_id: adminId },
    });
    // const patient = await Patient.findOne({
    //   where: { id: editAuthorization?.client_id, admin_id: adminId },
    // });
    // const activities = await PatientAuthActivity.findAll({
    //   where: { authorization_id: id, admin_id: adminId },
    //   order: [["id", "desc"]],
    //   limit: 15,
    // });
    const cptCodes = await SettingCptCode.findAll({
      where: { admin_id: adminId },
    });
    const allPayors = await PayorFacility.findAll({
      where: { admin_id: adminId },
      order: [["payor_name", "asc"]],
    });
    const supervisors = await ProviderDepartment.findAll({
      where: { is_supervisor: 1, admin_id: adminId },
      include: ["providerName"],
    });
    const treatmentTypes = await TreatmentFacility.findAll({
      where: { admin_id: adminId },
      order: [["treatment_name", "asc"]],
    });
    const allSubActs = await AllSubActivity.findAll({
      where: { admin_id: adminId },
      order: [["sub_activity", "asc"]],
    });

    res.status(200).json({
      message: "success",
      // patient_id: patient,
      client_authorization_info: editAuthorization,
      // activities,
      cpt_codes: cptCodes,
      all_payors: allPayors,
      supervisor: supervisors,
      treatment_types: treatmentTypes,
      allSubActivities: allSubActs,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json("Server error");
  }
};

const patientAuthUpdate = async (req, res, next) => {
  try {
    const {
      select_date,
      edit_authorization_id,
      authorization_number,
      client_id,
      payor_id,
      treatment_type,
      supervisor_id,
      uci_id,
      max_total_auth,
      value,
      diagnosis_one,
      diagnosis_two,
      diagnosis_three,
      diagnosis_four,
      deductible,
      in_network,
      copay,
      cms_four,
      csm_eleven,
      notes,
      is_primary,
      is_placeholder,
      is_valid,
      is_required,
    } = req.body;

    const first_date = select_date.substring(0, 10);
    const second_date = select_date.substring(12);
    const onset_date = moment(first_date, "MM/DD/YYYY").format("YYYY-MM-DD");
    const end_date = moment(second_date, "MM/DD/YYYY").format("YYYY-MM-DD");

    if (is_primary == 2) {
      const checkApp = await Appointment.count({
        where: {
          admin_id: req.user.id,
          authorization_id: edit_authorization_id,
        },
      });

      if (checkApp > 0) {
        return res.status(200).json({
          message: "error",
          error: "This authorization is already used in appointment",
        });
      }
    }

    const updateAuthorization = await PatientAuthorization.findOne({
      where: {
        id: edit_authorization_id,
        admin_id: req.user.id,
      },
    });

    // if (req.file) {
    //   fs.unlinkSync(updateAuthorization.upload_authorization);
    //   const uploadPath = "assets/dashboard/authorization/";
    //   const imageUrl = uploadPath + req.file.filename;
    //   updateAuthorization.upload_authorization = imageUrl;
    // }

    const payoData = await PayorFacility.findOne({ where: { payor_id } });
    const payor_name = payoData ? payoData.payor_name : "";

    const tretTypeName = await TreatmentFacility.findOne({
      where: {
        admin_id: req.user.id,
        treatment_name: treatment_type,
      },
    });

    updateAuthorization.authorization_name = `${payor_name} ${treatment_type}`;
    updateAuthorization.client_id = client_id;
    updateAuthorization.description = req.description;
    updateAuthorization.payor_id = payor_id;
    updateAuthorization.treatment_type = treatment_type;
    updateAuthorization.treatment_type_id = tretTypeName ? tretTypeName.id : 0;
    updateAuthorization.supervisor_id = supervisor_id;
    updateAuthorization.onset_date = onset_date;
    updateAuthorization.end_date = end_date;
    updateAuthorization.selected_date = select_date;
    updateAuthorization.authorization_number = authorization_number;
    updateAuthorization.uci_id = uci_id;
    updateAuthorization.max_total_auth = max_total_auth;
    updateAuthorization.value = value;
    updateAuthorization.diagnosis_one = diagnosis_one;
    updateAuthorization.diagnosis_two = diagnosis_two;
    updateAuthorization.diagnosis_three = diagnosis_three;
    updateAuthorization.diagnosis_four = diagnosis_four;
    updateAuthorization.deductible = deductible;
    updateAuthorization.in_network = in_network;
    updateAuthorization.copay = copay;
    updateAuthorization.cms_four = cms_four;
    updateAuthorization.csm_eleven = csm_eleven;
    updateAuthorization.notes = notes;
    if (is_primary !== null || is_primary !== "") {
      updateAuthorization.is_primary = is_primary;
    }
    updateAuthorization.is_placeholder = is_placeholder;
    updateAuthorization.is_valid = is_valid;
    updateAuthorization.is_required = is_required && is_required == 1 ? 1 : 2;
    await updateAuthorization.save();

    if (is_placeholder != 1) {
      await Appointment.update({ is_show: 0 }, { where: { authorization_id: updateAuthorization.id } });
    } else {
      await Appointment.update({ is_show: 1 }, { where: { authorization_id: updateAuthorization.id } });
    }

    const clientActivities = await PatientAuthActivity.findAll({
      where: {
        authorization_id: updateAuthorization.id,
        admin_id: req.user.id,
      },
    });
    //console.log("clientActivities", clientActivities);
    if (clientActivities.length > 0) {
      for (const activity of clientActivities) {
        activity.onset_date = updateAuthorization.onset_date;
        activity.end_date = updateAuthorization.end_date;
        await activity.save();
      }
    }

    await PatientActivity.create({
      admin_id: req.user.id,
      is_up_admin: req.user.is_up_admin == 1 ? 1 : 2,
      down_admin_id: req.user.is_up_admin == 1 ? 0 : req.user.id,
      who_created: `${req.user.first_name} ${req.user.last_name}`,
      client_id: updateAuthorization.client_id,
      title: "Client Authorization Updated",
      message: "Client Authorization Updated",
      act_date: moment().format("YYYY-MM-DD HH:mm:ss"),
    });

    return res.status(200).json({
      message: "success",
      data: updateAuthorization,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send("Internal Server Error");
  }
};
const patientAuthDelete = async (req, res, next) => {
  try {
    const { id } = req.body;
    const adminId = req.user.id;
    const delAuth = await PatientAuthorization.findOne({
      where: {
        id,
        admin_id: adminId,
      },
    });

    const checkApp = await Appointment.count({
      where: {
        authorization_id: delAuth.id,
      },
    });

    if (checkApp > 0) {
      return res.status(200).json({
        message: "error",
        error: "This authorization is already used in appointment",
      });
    }

    //Delete auth from patient authorization activity as well
    await PatientAuthActivity.destroy({
      where: {
        authorization_id: id,
        admin_id: adminId,
      },
    });

    await PatientActivity.create({
      admin_id: adminId,
      // is_up_admin: user.is_up_admin == 1 ? 1 : 2,
      // down_admin_id: user.is_up_admin == 1 ? 0 : user.id,
      is_up_admin: null,
      down_admin_id: null,
      who_created: null,
      client_id: delAuth.client_id,
      message: "Client Authorization Deleted",
      act_date: moment().format("YYYY-MM-DD HH:mm:ss"),
    });

    await delAuth.destroy();

    return res.status(200).json({
      success: true,
      message: "Authorization Deleted Successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send("Internal Server Error");
  }
};

// ================ PATIENT AUTHORIZATION END ================

// ================ PATIENT AUTHORIZATION ACTIVITY START ================
const patientAuthActList = async (req, res, next) => {
  try {
    const { authorization_id } = req.body;
    const authActivity = await PatientAuthActivity.findAll({
      where: { authorization_id, admin_id: req.user.id },
      order: [["id", "desc"]],
    });

    return res.status(200).json({
      message: "success",
      patientActivities: authActivity,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send("Internal Server Error");
  }
};

const patientAuthActCreate = async (req, res, next) => {
  try {
    const {
      authrization_id,
      activity_one,
      activity_two,
      cpt_code,
      client_id,
      m1,
      m2,
      m3,
      m4,
      auth_activity,
      billed_type,
      billed_time,
      rate,
      hours_max_one,
      hours_max_per_one,
      hours_max_is_one,
      hours_max_two,
      hours_max_per_two,
      hours_max_is_two,
      hours_max_three,
      hours_max_per_three,
      hours_max_is_three,
      notes,
    } = req.body;

    const auth = await PatientAuthorization.findOne({
      where: {
        id: authrization_id,
        admin_id: req.user.id,
      },
    });

    const d_name = activity_one + activity_two + cpt_code;

    const checkExist = await PatientAuthActivity.findOne({
      where: {
        client_id,
        admin_id: req.user.id,
        authorization_id: authrization_id,
        dup_name: d_name,
      },
    });

    console.log("checkExist", checkExist);
    if (checkExist) {
      return res.status(200).json({
        message: "error",
        error: "This activity already exist",
      });
    } else {
      const newActivity = await PatientAuthActivity.create({
        admin_id: req.user.id,
        is_up_admin: 0,
        down_admin_id: 0,
        dup_name: d_name,
        activity_name: activity_one + " " + activity_two,
        client_id,
        authorization_id: authrization_id,
        activity_one,
        activity_two,
        cpt_code,
        onset_date: auth.onset_date,
        end_date: auth.end_date,
        m1,
        m2,
        m3,
        m4,
        auth_activity,
        billed_type,
        billed_time,
        rate: parseFloat(rate).toFixed(2),
        hours_max_one,
        hours_max_per_one,
        hours_max_is_one,
        hours_max_two,
        hours_max_per_two,
        hours_max_is_two,
        hours_max_three,
        hours_max_per_three,
        hours_max_is_three,
        notes,
      });

      await PatientActivity.create({
        admin_id: req.user.id,
        is_up_admin: 0,
        down_admin_id: 0,
        who_created: null,
        client_id: auth.client_id,
        title: "Authorization Activity Created",
        message: `${newActivity.activity_name} Authorization Activity Created`,
        act_date: new Date().toISOString(),
      });

      return res.status(200).json({
        message: "success",
        activity: newActivity,
      });
    }
  } catch (error) {
    console.log("Error saving client authorization activity:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const patientAuthActSingle = async (req, res, next) => {
  try {
    const { id } = req.params;
    console.log("parameter id", id);
    const authActivity = await PatientAuthActivity.findOne({
      where: {
        admin_id: req.user.id,
        id,
      },
    });
    res.status(200).json({
      message: "success",
      patientAuthActivity: authActivity,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send("Internal Server Error");
  }
};

const patientAuthActUpdate = async (req, res, next) => {
  try {
    const {
      authrization_id,
      activity_id,
      activity_one,
      activity_two,
      cpt_code,
      m1,
      m2,
      m3,
      m4,
      auth_activity,
      billed_type,
      billed_time,
      rate,
      hours_max_one,
      hours_max_per_one,
      hours_max_is_one,
      hours_max_two,
      hours_max_per_two,
      hours_max_is_two,
      hours_max_three,
      hours_max_per_three,
      hours_max_is_three,
      notes,
    } = req.body;

    const auth = await PatientAuthorization.findOne({
      where: {
        id: authrization_id,
        admin_id: req.user.id,
      },
    });

    const checkNumeric = !isNaN(parseFloat(rate));
    if (!checkNumeric) {
      return res.status(200).json({
        message: "Please enter numeric value for rate",
      });
    } else {
      const updateActivity = await PatientAuthActivity.findOne({
        where: {
          id: activity_id,
          admin_id: req.user.id,
        },
      });

      // const check = await this.authHoursValidation(req, updateActivity);

      // if (check === "less") {
      //   return res
      //     .redirect("back")
      //     .with("alert", "Approved hrs/units cannot be changed as it is less than rendered hrs/units. Contact administrator or support team");
      // }

      updateActivity.activity_name = activity_one + " " + activity_two;
      updateActivity.activity_one = activity_one;
      updateActivity.activity_two = activity_two;
      updateActivity.cpt_code = cpt_code;
      updateActivity.onset_date = auth.onset_date;
      updateActivity.end_date = auth.end_date;
      updateActivity.m1 = m1;
      updateActivity.m2 = m2;
      updateActivity.m3 = m3;
      updateActivity.m4 = m4;
      updateActivity.auth_activity = auth_activity;
      updateActivity.billed_type = billed_type;
      updateActivity.billed_time = billed_time;
      updateActivity.rate = parseFloat(rate).toFixed(2);
      updateActivity.hours_max_one = hours_max_one;
      updateActivity.hours_max_per_one = hours_max_per_one !== null ? hours_max_per_one : updateActivity.hours_max_per_one;
      updateActivity.hours_max_is_one = hours_max_is_one !== null ? hours_max_is_one : updateActivity.hours_max_is_one;
      updateActivity.hours_max_two = hours_max_two !== null ? hours_max_two : updateActivity.hours_max_two;
      updateActivity.hours_max_per_two = hours_max_per_two;
      updateActivity.hours_max_is_two = hours_max_is_two;
      updateActivity.hours_max_three = hours_max_three;
      updateActivity.hours_max_per_three = hours_max_per_three;
      updateActivity.hours_max_is_three = hours_max_is_three;
      updateActivity.notes = notes;
      await updateActivity.save();

      await PatientActivity.create({
        admin_id: req.user.id,
        is_up_admin: 0,
        down_admin_id: 0,
        who_created: null,
        client_id: auth.client_id,
        title: "Authorization Activity Created",
        message: `${updateActivity.activity_name + " Authorization Activity Updated"}`,
        act_date: new Date().toISOString(),
      });

      return res.status(200).json({
        message: "success",
        activity: updateActivity,
      });
    }
  } catch (error) {
    console.log("Error updating client authorization activity:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const patientAuthActDelete = async (req, res, next) => {
  try {
    const { activity_id } = req.body;
    const delActivity = await PatientAuthActivity.findOne({
      where: {
        id: activity_id,
        admin_id: req.user.id,
      },
    });

    const checkAppAct = await Appointment.count({
      where: { authorization_activity_id: activity_id },
    });

    if (checkAppAct > 0) {
      return res.status(200).json({ message: "Activity cannot be deleted as it is associated with appointment" });
    } else {
      await PatientActivity.create({
        admin_id: req.user.id,
        is_up_admin: 0,
        down_admin_id: 0,
        who_created: null,
        client_id: delActivity.client_id,
        title: "Authorization Activity Deleted",
        message: `${delActivity.activity_name} Authorization Activity Deleted`,
        act_date: Sequelize.literal("CURRENT_TIMESTAMP"),
      });

      await delActivity.destroy();

      return res.status(200).json({ success: "Activity Deleted Successfully" });
    }
  } catch (error) {
    console.log("Error deleting authorization activity:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const getServiceTxType = async (req, res) => {
  try {
    const { treatment_name } = req.body;
    const treatmentType = await TreatmentFacility.findAll({
      where: {
        admin_id: req.user.id,
        treatment_name: treatment_name,
      },
    });

    const array = treatmentType.map((types) => types.id);

    const settSer = await SettingService.findAll({
      where: {
        facility_treatment_id: {
          [Op.in]: array,
        },
        admin_id: req.user.id,
      },
    });

    res.status(200).json({ settService: settSer });
  } catch (error) {
    console.log("Error retrieving service tx type:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const getSubTypeTxType = async (req, res) => {
  try {
    const { treatment_name } = req.body;
    const treatmentType = await TreatmentFacility.findAll({
      where: {
        admin_id: req.user.id,
        treatment_name: treatment_name,
      },
    });

    const array = treatmentType.map((types) => types.id);

    const subActs = await AllSubActivity.findAll({
      where: {
        facility_treatment_id: {
          [Op.in]: array,
        },
        admin_id: req.user.id,
      },
    });

    res.status(200).json({
      settingSubActivity: subActs,
    });
  } catch (error) {
    console.log("Error retrieving sub type tx type:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const getCptCodesTxType = async (req, res) => {
  try {
    const { treatment_name } = req.body;
    const treatmentType = await TreatmentFacility.findAll({
      where: {
        admin_id: req.user.id,
        treatment_name: treatment_name,
      },
    });

    const array = treatmentType.map((types) => types.id);

    const settingcptCodeGet = await SettingCptCode.findAll({
      where: {
        facility_treatment_id: {
          [Op.in]: array,
        },
        admin_id: req.user.id,
      },
    });

    res.status(200).json({
      settingCptCode: settingcptCodeGet,
    });
  } catch (error) {
    console.log("Error retrieving cpt codes tx type:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const getServiceSubType = async (req, res) => {
  try {
    const { service_id, facility_treatment_id } = req.body;
    const data = await AllSubActivity.findAll({
      where: {
        admin_id: req.user.id,
        facility_treatment_id,
        service_id: service_id,
      },
    });
    res.status(200).json(data);
  } catch (error) {
    console.log("Error fetching subactivities:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
// ================ PATIENT AUTHORIZATION ACTIVITY END ===================

// ================ PATIENT DOCUMENT START ================
const patientDocList = async (req, res, next) => {};

const patientDocCreate = async (req, res, next) => {};

const patientDocGetSingle = async (req, res, next) => {};
// ================ PATIENT DOCUMENT END ==================

// -------------------call log---------------

const patientCallLogs = async (req, res) => {
  try {
    const logs = await PatientCallLog.findAll({
      where: {
        admin_id: req.user.id,
        client_id: req.body.id,
      },
    });
    const client_id = await Patient.findOne({
      where: {
        id: req.body.id,
        admin_id: req.user.id,
      },
    });

    res.json({
      response: client_id,
    });
    return false;
    res.status(200).json({
      message: "success",
      admin_id: req.user?.id,
      logs,
    });
  } catch (error) {
    console.log(error);
    // Handle the error appropriately
    // res.status(500).json({ error: 'Server error' });
    res.json({
      e: error.message,
    });
  }
};

// call log insert
const PatientCalllogInsert = async (req, res) => {
  try {
    const { client_id, call_log, log_date } = req.body;
    const adminId = req.user.id;

    const newCallLog = await PatientCallLog.create({
      admin_id: adminId,
      client_id: client_id,
      call_log: call_log,
      log_date: log_date,
    });

    return res.json({
      message: "Call Log Added Successfully",
    });
  } catch (error) {
    console.log(error);
    // Handle the error appropriately
    return res.status(500).json({ error: "Server error" });
  }
};

export default {
  patientCreate,
  patientList,
  patientStatusChange,
  patientInfo,
  patientAuthList,
  patientAuthorizationCreateInfo,
  patientAuthCreate,
  patientAuthSingle,
  patientAuthUpdate,
  patientAuthDelete,
  patientAuthActList,
  patientAuthActCreate,
  patientAuthActSingle,
  patientAuthActUpdate,
  patientAuthActDelete,
  getServiceTxType,
  getSubTypeTxType,
  getCptCodesTxType,
  getServiceSubType,
  patientDocList,
  patientDocCreate,
  patientDocGetSingle,
  patientCallLogs,
  PatientCalllogInsert,
};
