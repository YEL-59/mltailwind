import { Op } from "sequelize";
import RecurringSession from "../../../models/Appointment/RecurringSession.js";
import Patient from "../../../models/Patient/Patient.js";
import Provider from "../../../models/Provider/Provider.js";

const recurringSessionGetSortedInfo = async (req, res, next) => {
  const { sortBy } = req.body;

  if (sortBy === 2) {
    try {
      const result = await Patient.findAll({
        attributes: ["id", "admin_id", "client_full_name"],
        where: { admin_id: req.user.id },
        order: [["client_full_name", "ASC"]],
      });
      res.status(200).json({
        message: "Success",
        allClients: result,
      });
    } catch (error) {
      res.status(500).json({ error: "Internal Server Error" });
    }
  } else if (sortBy === 3) {
    try {
      const employees = await Provider.findAll({
        attributes: ["id", "admin_id", "full_name"],
        where: { admin_id: req.user.id },
        order: [["full_name", "ASC"]],
      });
      res.status(200).json({
        message: "Success",
        allEmployees: employees,
      });
    } catch (error) {
      res.status(500).json({ error: "Internal Server Error" });
    }
  } else {
    res.status(400).json({ error: "Invalid sort_by parameter" });
  }
};

const recurringSessionDataGet = async (req, res, next) => {
  const { sort_by, patient_ids, provider_ids } = req.body;
  const admin_id = req.user.id;

  const options = {
    where: { admin_id: admin_id },
    order: [["id", "DESC"]],
  };

  if (sort_by == 2 && patient_ids) {
    options.where.client_id = { [Op.in]: patient_ids };
  }

  if (sort_by == 3 && provider_ids) {
    options.where.provider_id = { [Op.in]: provider_ids };
  }

  try {
    const recurring_sessions = await RecurringSession.findAll(options);

    res.json({
      message: "Success",
      recurring_sessions: recurring_sessions,
    });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

async function recurring_session_edit(id) {
  try {
    const recurringSession = await RecurringSession.findOne({ id });

    const session_data = await appoinment.findOne(
      {
        recurring_id: id,
      },
      {
        attributes: [
          "recurring_id",
          "client_id",
          "authorization_id",
          "authorization_activity_id",
          "provider_id",
          "location",
          "time_duration",
          "from_time",
          "to_time",
          "status",
          "notes",
          "created_at",
        ],
      }
    );

    if (!session_data) {
      return res.status(200).json("alert", "Sessions for this recurring pattern have been deleted.");
    }

    const clients = await DB.table("clients").find();
    const authorization = await DB.table("client_authorizations").where("client_id", session_data.client_id).find();
    const activity = await DB.table("client_authorization_activities").where("authorization_id", session_data.authorization_id).find();
    const provider = await DB.table("employees").find();
    const sessions_not_sheduled = await DB.table("appoinments")
      .where({ recurring_id: id, is_locked: { "!=": "1" } })
      .find();
    const sessions_sheduled = await DB.table("appoinments").where({ recurring_id: id, is_locked: "1" }).find();

    return res.render("superadmin.appoinment.recurringSessionEdit", {
      sessions_not_sheduled,
      sessions_sheduled,
      session_data,
      clients,
      authorization,
      activity,
      provider,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
}

export default {
  recurringSessionGetSortedInfo,
  recurringSessionDataGet,
};
