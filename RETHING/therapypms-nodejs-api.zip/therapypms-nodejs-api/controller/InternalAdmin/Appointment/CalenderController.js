import Appointment from "../../../models/Appointment/Appointment.js";

import { getPagination, getPagingData } from "../../../helpers/pagination.js";
import { Op } from "sequelize";
import Patient from "../../../models/Patient/Patient.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import Provider from "../../../models/Provider/Provider.js";

const calenderList = async (req, res) => {
  try {
    const { page, start_data, end_date } = req.body;

    const { perPage, offset } = getPagination(page);

    const appointments = await Appointment.findAndCountAll({
      attributes: [
        "id",
        "admin_id",
        "billable",
        "client_id",
        "authorization_id",
        "authorization_activity_id",
        "provider_id",
        "location",
        "from_time",
        "to_time",
        "schedule_date",
        "status",
        "is_locked",
        "is_show",
        "activity_type",
      ],
      where: {
        admin_id: req.user.id,
        schedule_date: {
          [Op.between]: [start_data, end_date],
        },
      },
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
        {
          model: PatientAuthorization,
          as: "app_auth",
          attributes: ["id", "admin_id", "authorization_name"],
        },
        {
          model: PatientAuthActivity,
          as: "app_activity",
          attributes: ["id", "admin_id", "activity_name"],
        },
        {
          model: Provider,
          as: "app_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
      ],
      order: [["schedule_date", "DESC"]],
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "calender appointment list",
      data: getPagingData(appointments, page, perPage),
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const calenderSingleSession = async (req, res) => {
  try {
    const { appointment_id } = req.body;
    const single_appointment = await Appointment.findOne({
      where: {
        admin_id: req.user.id,
        id: appointment_id,
      },
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
        {
          model: PatientAuthorization,
          as: "app_auth",
          attributes: ["id", "admin_id", "authorization_name"],
        },
        {
          model: PatientAuthActivity,
          as: "app_activity",
          attributes: ["id", "admin_id", "activity_name"],
        },
        {
          model: Provider,
          as: "app_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
      ],
    });

    res.json({
      status: "success",
      message: "calender appointment single",
      data: single_appointment,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

export default {
  calenderList,
  calenderSingleSession,
};
