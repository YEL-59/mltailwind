import { Op } from "sequelize";

import Appointment from "../../../models/Appointment/Appointment.js";
import { getPagination, getPagingData } from "../../../helpers/pagination.js";

import { isQueryParam, isQueryParamArray } from "../../../helpers/queryValidation.js";
import Patient from "../../../models/Patient/Patient.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import Provider from "../../../models/Provider/Provider.js";
import PatientStatus from "../../../models/Patient/PatientStatus.js";

const getSessionClientAll = async (req, res, next) => {
  const active = await PatientStatus.findAll({
    attributes: ["id", "admin_id"],
    where: {
      is_active: 1,
      admin_id: req.user.id,
    },
  });

  // const activeIds = active.map((status) => status.id);
  // activeIds.push(1);

  const clients = await Patient.findAll({
    attributes: ["id", "client_full_name"],
    where: {
      admin_id: req.user.id,
      is_active_client: 1,
    },
    order: [["client_full_name", "ASC"]],
  });

  return res.status(200).json(clients);
};

const getSessionProviderAll = async (req, res, next) => {
  try {
    const providers = await Provider.findAll({
      attributes: ["id", "full_name"],
      where: {
        admin_id: req.user.id,
        is_active: 1,
      },
      order: [["full_name", "ASC"]],
    });
    return res.status(200).json(providers);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};

const getAppointmentListBillable = async (req, res, next) => {
  try {
    const { page, patient_ids, provider_ids, status, from_date, to_date, ses_pos } = req.body;

    const { perPage, offset } = getPagination(page);

    let searchAppointment = {};
    searchAppointment.admin_id = req.user.id;
    if (await isQueryParamArray(patient_ids)) {
      searchAppointment.client_id = {
        [Op.in]: patient_ids,
      };
    }

    if (await isQueryParamArray(provider_ids)) {
      searchAppointment.provider_id = {
        [Op.in]: provider_ids,
      };
    }

    if (await isQueryParam(status)) {
      searchAppointment.status = {
        [Op.eq]: status,
      };
    }

    if (await isQueryParam(ses_pos)) {
      searchAppointment.location = {
        [Op.eq]: ses_pos,
      };
    }

    if ((await isQueryParam(from_date)) && (await isQueryParam(to_date))) {
      searchAppointment.schedule_date = {
        [Op.between]: [from_date, to_date],
      };
    }

    const appointmentList = await Appointment.findAndCountAll({
      attributes: [
        "id",
        "admin_id",
        "is_locked",
        "billable",
        "client_id",
        "authorization_activity_id",
        "provider_id",
        "location",
        "schedule_date",
        "from_time",
        "to_time",
        "time_duration",
        "status",
        "rendered_at",
        "updated_at",
        "comment",
      ],
      where: searchAppointment,
      billable: 1,
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
        {
          model: PatientAuthorization,
          as: "app_auth",
          attributes: ["id", "admin_id", "authorization_name"],
        },
        {
          model: PatientAuthActivity,
          as: "app_activity",
          attributes: ["id", "admin_id", "activity_name"],
        },
        {
          model: Provider,
          as: "app_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
      ],
      order: [["schedule_date", "DESC"]],
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "get appointment billable list",
      billableAppointments: getPagingData(appointmentList, page, perPage),
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const getAppointmentListNonBillable = async (req, res, next) => {
  try {
    const { page, provider_ids, status, from_date, to_date } = req.body;

    const { perPage, offset } = getPagination(page);

    let searchAppointment = {};
    searchAppointment.admin_id = req.user.id;
    searchAppointment.billable = 2;
    if (await isQueryParamArray(provider_ids)) {
      searchAppointment.provider_id = {
        [Op.in]: provider_ids,
      };
    }

    const appointmentList = await Appointment.findAndCountAll({
      attributes: [
        "id",
        "admin_id",
        "is_locked",
        "billable",
        "client_id",
        "authorization_activity_id",
        "provider_id",
        "location",
        "schedule_date",
        "from_time",
        "to_time",
        "time_duration",
        "status",
        "rendered_at",
        "updated_at",
        "comment",
      ],
      where: searchAppointment,
      order: [["schedule_date", "DESC"]],
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "get appointment non billable list",
      data: getPagingData(appointmentList, page, perPage),
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const getAppointmentSingle = async (req, res, next) => {
  try {
    const { appointment_id } = req.body;

    const single_appointment = await Appointment.findOne({
      attributes: [
        "id",
        "admin_id",
        "is_locked",
        "billable",
        "client_id",
        "authorization_activity_id",
        "provider_id",
        "location",
        "schedule_date",
        "from_time",
        "to_time",
        "time_duration",
        "status",
        "rendered_at",
        "updated_at",
        "comment",
      ],
      where: {
        admin_id: req.user.id,
        id: appointment_id,
      },
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
        {
          model: PatientAuthorization,
          as: "app_auth",
          attributes: ["id", "admin_id", "authorization_name"],
        },
        {
          model: PatientAuthActivity,
          as: "app_activity",
          attributes: ["id", "admin_id", "activity_name"],
        },
        {
          model: Provider,
          as: "app_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
      ],
    });

    res.json({
      status: "success",
      message: "get single appointment",
      data: single_appointment,
    });
  } catch (error) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const getAppointmentUpdate = async (req, res, next) => {
  try {
    const { appointment_id } = req.body;

    res.json({
      status: "success",
      message: "appointment successfully updated",
    });
  } catch (error) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const appointmentStatusUpdate = async (req, res, next) => {
  try {
    const { appointment_ids, status_name } = req.body;

    const appointments = await Appointment.update(
      { status: status_name },
      {
        where: {
          admin_id: req.user.id,
          id: {
            [Op.in]: appointment_ids,
          },
        },
      }
    );

    res.json({
      status: "success",
      message: "appointment status successfully updated",
    });
  } catch (error) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const appointmentBulkDelete = async (req, res, next) => {
  try {
    const { appointment_ids, status_name } = req.body;

    if (status_name === "Bulk Delete") {
      const appointments = Appointment.destroy({
        where: {
          admin_id: req.user.id,
          is_locked: {
            [Op.ne]: 1,
          },
          id: {
            [Op.in]: appointment_ids,
          },
        },
      });
      res.json({
        status: "success",
        message: "appointment successfully deleted",
      });
      return false;
    } else {
      res.json({
        status: "error",
        message: "please choose action",
      });
      return false;
    }
  } catch (error) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

export default {
  getSessionClientAll,
  getSessionProviderAll,
  getAppointmentListBillable,
  getAppointmentListNonBillable,
  getAppointmentSingle,
  appointmentStatusUpdate,
  appointmentBulkDelete,
  getAppointmentUpdate,
};
