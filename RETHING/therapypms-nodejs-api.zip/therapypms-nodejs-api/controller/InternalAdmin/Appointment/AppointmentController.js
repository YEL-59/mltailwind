import Appointment from "../../../models/Appointment/Appointment.js";
import Patient from "../../../models/Patient/Patient.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";

import { createSession } from "../../../helpers/appointment/appointmentHelper.js";

import { convertDateTime, checkDateTimeDiff } from "../../../helpers/common/Common.js";

const getPatientList = async (req, res) => {
  try {
    const patient_list = Patient.findAll({
      where: {
        admin_id: req.user.id,
      },
    });
    res.json({
      status: "success",
      message: "appointment patient list",
      patient_list: patient_list,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const getAuthByPatientID = async (req, res, next) => {
  try {
    const { patient_id } = req.body;

    const auth_list = await PatientAuthorization.findAll({
      attributes: ["id", "admin_id", "client_id", "is_primary", "is_valid", "description", "onset_date", "end_date", "authorization_number"],
      where: {
        admin_id: req.user.id,
        client_id: patient_id,
        is_primary: 1,
      },
      order: ["authorization_name", "ASC"],
    });

    res.json({
      status: "success",
      message: "patient authorization list by patient ID",
      data: auth_list,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};
const getActByAuthID = async (req, res, next) => {
  try {
    const { auth_id } = req.body;

    const activity_list = await PatientAuthActivity.findAll({
      attributes: ["id", "admin_id", "activity_name", "authorization_id"],
      where: {
        admin_id: req.user.id,
        authorization_id: auth_id,
      },
      order: ["activity_name", "ASC"],
    });

    res.json({
      status: "success",
      message: "patient authorization activity list by patient ID",
      data: activity_list,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};
const getAvailableTime = async (req, res, next) => {
  try {
    res.json("done");
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};
const createAppointment = async (req, res, next) => {
  try {
    const {
      billable,
      patient_id,
      authorization_id,
      activity_id,
      provider_id,
      provider_mul_id,
      location,
      from_time,
      form_time_session,
      to_time_session,
      status,
      chkrecurrence,
      daily,
      end_date,
      day_name,
    } = req.body;

    const create_session = await createSession(req, req.user.id);

    res.json({
      app_data: create_session,
    });

    res.json("done");
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

export default {
  getPatientList,
  getAuthByPatientID,
  getActByAuthID,
  getAvailableTime,
  createAppointment,
};
