import Provider from "../../../models/Provider/Provider.js";
import { getPagination, getPagingData } from "../../../helpers/pagination.js";
import ProviderContactDetail from "../../../models/Provider/ProviderContactDetail.js";
import ProviderEmgConDetail from "../../../models/Provider/ProviderEmgConDetail.js";
import ProviderCredential from "../../../models/Provider/ProviderCredential.js";
import ProviderClearnce from "../../../models/Provider/ProviderClearnces.js";
import ProviderQualification from "../../../models/Provider/ProviderQualification.js";
import ProviderDepartment from "../../../models/Provider/ProviderDepartment.js";
import ProviderPayroll from "../../../models/Provider/ProviderPayroll.js";
import SettingService from "../../../models/Setting/SettingService.js";
import ProviderSubActExclusion from "../../../models/Provider/ProviderSubActExclusion.js";
import AllSubActivity from "../../../models/Setting/AllSubActivity.js";
import { Op, Sequelize } from "sequelize";
import ProviderClientExclusion from "../../../models/Provider/ProviderClientExclusion.js";
import Patient from "../../../models/Patient/Patient.js";
import TreatmentFacility from "../../../models/Setting/TreatmentFacility.js";
import ProviderDetailTxType from "../../../models/Provider/ProviderDetailTxType.js";
import ProviderOtherSetup from "../../../models/Provider/ProviderOtherSetup.js";
import ProviderWorkSchedule from "../../../models/Provider/ProviderWorkSchedule.js";
import { parseISO } from "date-fns";
import moment from "moment/moment.js";
import ProviderBlockOffTime from "../../../models/Provider/ProviderBlockOffTime.js";
import ProviderLeave from "../../../models/Provider/ProviderLeave.js";
import HolidaySetup from "../../../models/Setting/HolidaySetup.js";
import AllPayor from "../../../models/Setting/AllPayor.js";
import ProviderExcludePayor from "../../../models/Provider/ProviderExcludePayor.js";

const createProvider = async (req, res, next) => {
	try {
		const {
			employee_type,
			first_name,
			middle_name,
			last_name,
			nickname,
			staff_birthday,
			ssn,
			office_phone,
			office_fax,
			office_email,
			driver_license,
			license_exp_date,
			title,
			hir_date_compnay,
			credential_type,
			treatment_type,
			individual_npi,
			caqh_id,
			service_area_zip,
			terminated_date,
			language,
			taxonomy_code,
			back_color,
			gender,
		} = req.body;

		const checkExist = await Provider.findOne({
			where: {
				admin_id: req.user.id,
				office_email: office_email,
			},
		});

		if (checkExist) {
			res.json({
				status: "error",
				message: "provider already exist",
			});
			return false;
		}

		const lastRecord = await Provider.findOne({
			where: {
				admin_id: req.user.id,
			},
			order: [["id", "DESC"]],
		});

		const createProvider = await Provider.create({
			id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
			admin_id: req.user.id,
			is_active: 1,
			employee_type: employee_type,
			employee_id: "001",
			first_name: first_name,
			middle_name: middle_name,
			last_name: last_name,
			full_name: `${first_name} ${middle_name} ${last_name}`,
			nickname: nickname,
			staff_birthday: staff_birthday,
			ssn: ssn,
			office_phone: office_phone,
			office_fax: office_fax,
			office_email: office_email,
			driver_license: driver_license,
			license_exp_date: license_exp_date,
			title: title,
			hir_date_compnay: hir_date_compnay,
			credential_type: credential_type,
			treatment_type: treatment_type,
			individual_npi: individual_npi,
			caqh_id: caqh_id,
			service_area_zip: service_area_zip,
			terminated_date: terminated_date,
			language: language,
			taxonomy_code: taxonomy_code,
			back_color: back_color,
			gender: gender,
		});

		res.json({
			status: "success",
			message: "provider successfully created",
			data: createProvider,
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerList = async (req, res, next) => {
	try {
		const { page } = req.body;
		const { perPage, offset } = getPagination(page);

		const providers = await Provider.findAndCountAll({
			where: {
				admin_id: req.user.id,
			},
			order: [["full_name", "ASC"]],
			include: "employeeTypeAssign",
			limit: perPage,
			offset,
		});

		res.status(200).json({
			status: "success",
			message: "provider list",
			providerData: getPagingData(providers, page, perPage),
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const employeeStatusUpdate = async (req, res) => {
	try {
		const { employee_id, is_active } = req.body;
		const employee = await Provider.findByPk(employee_id);
		employee.is_active = is_active;
		await employee.save();

		return res.status(200).json({
			status: "success",
			message: "employee status updated",
		});
	} catch (err) {
		console.log(err);
		return res.status(500).json({ message: "Server error" });
	}
};

const providerBiographic = async (req, res, next) => {
	try {
		const provider = await Provider.findOne({
			where: {
				admin_id: req.user.id,
				id: req.params.providerid,
			},
		});

		res.status(200).json({
			status: "success",
			message: "provider biographic by provider ID",
			employee_info: provider,
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerBiographicUpdate = async (req, res, next) => {
	try {
		const {
			employee_id,
			employee_type,
			first_name,
			middle_name,
			last_name,
			nickname,
			staff_birthday,
			ssn,
			office_phone,
			office_fax,
			office_email,
			driver_license,
			license_exp_date,
			title,
			hir_date_compnay,
			credential_type,
			treatment_type,
			individual_npi,
			caqh_id,
			service_area_zip,
			terminated_date,
			language,
			taxonomy_code,
			back_color,
			gender,
			email_remainder,
			session_check,
			notes,
		} = req.body;

		const updateProvider = await Provider.findOne({
			where: {
				admin_id: req.user.id,
				id: employee_id,
			},
		});

		updateProvider.set({
			first_name: first_name,
			middle_name: middle_name,
			last_name: last_name,
			full_name: `${first_name} ${middle_name} ${last_name}`,
			nickname: nickname,
			staff_birthday: staff_birthday,
			ssn: ssn,
			office_phone: office_phone,
			office_fax: office_fax,
			office_email: office_email,
			driver_license: driver_license,
			license_exp_date: license_exp_date,
			title: title,
			hir_date_compnay: hir_date_compnay,
			credential_type: credential_type,
			treatment_type: treatment_type,
			individual_npi: individual_npi,
			caqh_id: caqh_id,
			service_area_zip: service_area_zip,
			terminated_date: terminated_date,
			language: language,
			taxonomy_code: taxonomy_code,
			back_color: back_color,
			gender: gender,
			employee_type,
			email_remainder,
			session_check,
			notes,
		});

		await updateProvider.save();

		res.json({
			status: "success",
			message: "provider biographic successfully update",
		});
	} catch (e) {
		res.status(500).send(e);
	}
};

const providerContactInfo = async (req, res, next) => {
	try {
		const employee_id = req.params.providerid;
		console.log(employee_id);
		const employeeName = await Provider.findOne({
			where: { id: employee_id },
		});
		const existEmployee = await ProviderContactDetail.findOne({
			where: { employee_id },
		});
		const existEmployeeEm = await ProviderEmgConDetail.findOne({
			where: { employee_id },
		});

		let employee, employeeEm;

		if (existEmployee) {
			employee = existEmployee;
		} else {
			let lastRecord = await ProviderContactDetail.findOne({
				order: [["id", "DESC"]],
			});

			employee = await ProviderContactDetail.create({
				id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
				employee_id: employee_id,
			});
		}

		if (existEmployeeEm) {
			employeeEm = existEmployeeEm;
		} else {
			let lastRecord = await ProviderEmgConDetail.findOne({
				order: [["id", "DESC"]],
			});

			employeeEm = await ProviderEmgConDetail.create({
				id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
				employee_id: employee_id,
			});
		}

		return res.status(200).json({
			status: "success",
			message: "provider contact info by provider ID",
			contact_details: employee,
			emergency_contact_details: employeeEm,
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerContactInfoUpdate = async (req, res, next) => {
	try {
		const employeContactUpdate = await ProviderContactDetail.findOne({
			where: { employee_id: req.body.employee_contact_edit },
		});
		employeContactUpdate.address_one = req.body.address_one;
		employeContactUpdate.address_two = req.body.address_two;
		employeContactUpdate.city = req.body.city;
		employeContactUpdate.state = req.body.state;
		employeContactUpdate.zip = req.body.zip;
		employeContactUpdate.mobile = req.body.mobile;
		employeContactUpdate.fax = req.body.fax;
		employeContactUpdate.main_phone = req.body.main_phone;
		employeContactUpdate.address_note = req.body.address_note;
		await employeContactUpdate.save();

		//Confused part
		// await ClientActivity.create({
		//   admin_id: req.user.id,
		//   title: "Staff Contact Details Updated",
		//   message: "Staff Contact Details Updated",
		//   act_date: new Date(),
		// });

		return res.status(200).json({
			status: "success",
			message: "Staff Contact Details Successfully Updated",
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};
const providerEmergencyContactDetailsUpdate = async (req, res) => {
	try {
		const {
			employee_contact_edit,
			em_contact_name,
			em_address_one,
			em_address_two,
			em_city,
			em_state,
			em_zip,
			em_mobile,
			em_fax,
			em_main_phone,
			em_address_note,
		} = req.body;

		const employeeEmergencyContactDetail = await ProviderEmgConDetail.findOne({
			where: { employee_id: employee_contact_edit },
		});

		if (!employeeEmergencyContactDetail) {
			return res.status(404).send({ message: "Employee emergency contact details not found." });
		}

		await employeeEmergencyContactDetail.update({
			contact_name: em_contact_name,
			address_one: em_address_one,
			address_two: em_address_two,
			city: em_city,
			state: em_state,
			zip: em_zip,
			mobile: em_mobile,
			fax: em_fax,
			main_phone: em_main_phone,
			address_note: em_address_note,
		});

		// await Client_activity.create({
		//   admin_id: req.user.id,
		//   title: "Staff Emergency Contact Details Updated",
		//   message: "Staff Emergency Contact Details Updated",
		//   act_date: new Date(),
		// });

		return res.status(200).json({
			status: "success",
			message: "Staff Emergency Contact Details Successfully Updated",
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

//-----------------Provider Credential-----------------//
const providerCredentialList = async (req, res, next) => {
	try {
		const { page, id } = req.body;
		const { perPage, offset } = getPagination(page);
		const employee = await Provider.findOne({
			where: {
				id,
				admin_id: req.user.id,
			},
		});
		const credentialList = await ProviderCredential.findAndCountAll({
			where: {
				employee_id: id,
			},
		});
		return res.status(200).json({
			status: "success",
			message: "Employee Credential List",
			employee: employee,
			credentialsList: getPagingData(credentialList, page, perPage),
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerCredentialSave = async (req, res, next) => {
	try {
		// if (req.file) {
		//   const fileName = `${Date.now()}${req.body.employee_id}${path.extname(
		//     req.file.originalname
		//   )}`;
		//   const uploadPath = path.join(
		//     __dirname,
		//     "../public/assets/dashboard/staffdocument"
		//   );
		//   const imageUrl = `${req.protocol}://${req.get(
		//     "host"
		//   )}/assets/dashboard/staffdocument/${fileName}`;
		//   await req.file.mv(`${uploadPath}/${fileName}`);
		//   employeeCredentialData.credential_file = imageUrl;
		// }
		const lastRecord = await ProviderCredential.findOne({
			order: [["id", "DESC"]],
		});

		const newEmployeeCredential = await ProviderCredential.create({
			id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
			employee_id: req.body.employee_id,
			credential_name: req.body.cred_type,
			credential_date_issue: req.body.date_issue,
			credential_date_expired: req.body.date_expire,
			credential_applicable: req.body.cred_apply,
		});
		// await ClientActivity.create({
		//   admin_id: req.user.id,
		//   title: "Staff Credential Created",
		//   message: "Staff Credential Created",
		//   act_date: new Date(),
		// });
		return res.status(200).json({
			status: "success",
			message: "Employee Credential Successfully Created",
			employeeCredential: newEmployeeCredential,
		});
	} catch (e) {
		res.status(500).send(e);
	}
};

const singleProviderCredential = async (req, res, next) => {
	try {
		const { cred_id } = req.params;
		const employeeCredential = await ProviderCredential.findOne({
			where: {
				id: cred_id,
			},
		});
		return res.status(200).json({
			status: "success",
			message: "Employee Credential",
			employeeCredential: employeeCredential,
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerCredentialUpdate = async (req, res, next) => {
	try {
		const { cred_id, cred_type, date_issue, date_expire, cred_apply, employee_id } = req.body;
		const data = await ProviderCredential.findByPk(cred_id);

		// if (req.file) {
		//   const image = req.file;
		//   const name = `${Date.now()}${employee_id}${image.originalname}`;
		//   const uploadPath = "assets/dashboard/staffdocument/";
		//   const imageUrl = uploadPath + name;

		//   await image.mv(imageUrl);
		//   data.credential_file = imageUrl;
		// }

		data.credential_name = cred_type;
		data.credential_date_issue = date_issue;
		data.credential_date_expired = date_expire;
		data.credential_applicable = cred_apply;

		await data.save();

		return res.status(200).json({
			status: "success",
			message: "Employee Credential Successfully Updated",
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerCredentialDelete = async (req, res, next) => {
	try {
		const result = await ProviderCredential.destroy({
			where: { id: req.body.cred_id },
		});
		if (!result) {
			return res.status(404).send("Employee Credential not found");
		}
		return res.status(200).json({
			status: "success",
			message: "Employee Credential Successfully Deleted",
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};


const providerClearenceList = async (req, res, next) => {
	try {
		const { page, id } = req.body;
		const { perPage, offset } = getPagination(page);
		const employee = await Provider.findOne({
			where: {
				id,
				admin_id: req.user.id,
			},
		});
		const clearenceList = await ProviderClearnce.findAndCountAll({
			where: {
				employee_id: id,
			},
		});
		return res.status(200).json({
			status: "success",
			message: "Employee Clearences List",
			employee: employee,
			clearences: getPagingData(clearenceList, page, perPage),
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerClearenceSave = async (req, res, next) => {
	try {
		// if (req.file) {
		//   const image = req.file;
		//   const name = `${Date.now()}${req.body.employee_id}${image.originalname}`;
		//   const uploadPath = path.join(
		//     __dirname,
		//     "..",
		//     "public",
		//     "assets",
		//     "dashboard",
		//     "staffdocument"
		//   );
		//   if (!fs.existsSync(uploadPath)) {
		//     fs.mkdirSync(uploadPath, { recursive: true });
		//   }
		//   await image.mv(path.join(uploadPath, name));
		//   const imageUrl = path.join(
		//     "/",
		//     "assets",
		//     "dashboard",
		//     "staffdocument",
		//     name
		//   );
		//   data.clearance_file = imageUrl;
		// }
		const lastRecord = await ProviderClearnce.findOne({
			order: [["id", "DESC"]],
		});

		const newProviderClearance = await ProviderClearnce.create({
			id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
			employee_id: req.body.employee_id,
			clearance_name: req.body.clear_type,
			clearance_date_issue: req.body.date_issue,
			clearance_date_exp: req.body.date_expire,
			clearance_applicable: req.body.clear_apply,
		});
		// await ClientActivity.create({
		//   admin_id: req.user.id,
		//   title: "Staff Clearance Created",
		//   message: "Staff Clearance Created",
		//   act_date: new Date(),
		// });

		return res.status(200).json({
			status: "success",
			message: "Employee Clearance Successfully Created",
			employeeClearance: newProviderClearance,
		});
	} catch (e) {
		res.status(500).send(e);
	}
};

const singleProviderClearance = async (req, res, next) => {
	try {
		const { clearance_id } = req.params;
		const employeeClearance = await ProviderClearnce.findOne({
			where: {
				id: clearance_id,
			},
		});
		return res.status(200).json({
			status: "success",
			message: "Employee Clearance Info",
			employeeClearance,
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerClearanceupdate = async (req, res, next) => {
	try {
		const data = await ProviderClearnce.findByPk(req.body.clear_id);

		// if (req.file) {
		//   const imageUrl = "assets/dashboard/staffdocument/" + req.file.filename;
		//   data.clearance_file = imageUrl;
		// }

		data.clearance_name = req.body.clear_type;
		data.clearance_date_issue = req.body.date_issue;
		data.clearance_date_exp = req.body.date_expire;
		data.clearance_applicable = req.body.clear_apply;
		await data.save();

		return res.status(200).json({
			status: "success",
			message: "Employee Clearance Successfully Updated",
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerClearanceDelete = async (req, res, next) => {
	try {
		const result = await ProviderClearnce.destroy({
			where: { id: req.body.clear_id },
		});
		if (!result) {
			return res.status(404).send("Employee Clearance not found");
		}
		return res.status(200).json({
			status: "success",
			message: "Employee Clearance Successfully Deleted",
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};


const providerQualificationList = async (req, res, next) => {
	try {
		const { page, id } = req.body;
		const { perPage, offset } = getPagination(page);
		const employee = await Provider.findOne({
			where: {
				id,
				admin_id: req.user.id,
			},
		});

		const qualificationList = await ProviderQualification.findAndCountAll({
			where: {
				employee_id: id,
			},
		});

		return res.status(200).json({
			status: "success",
			message: "Employee Qualification List",
			employee: employee,
			qualifications: getPagingData(qualificationList, page, perPage),
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerQualificationSave = async (req, res, next) => {
	try {
		const data = new ProviderQualification();

		// if (req.file) {
		//   const name = Date.now() + req.body.employee_id + req.file.originalname;
		//   const uploadPath = "assets/dashboard/staffdocument/";
		//   await req.file.move(uploadPath, { name });
		//   const imageUrl = uploadPath + name;

		//   data.qualification_file = imageUrl;
		// }

		const lastRecord = await ProviderQualification.findOne({
			order: [["id", "DESC"]],
		});

		data.id = lastRecord ? parseInt(lastRecord.id) + 1 : 1;
		data.employee_id = req.body.employee_id;
		data.qualification_name = req.body.qual_type;
		data.qualification_date_issue = req.body.date_issue;
		data.qualification_date_exp = req.body.date_expire;
		data.qualification_applicable = req.body.qual_apply;
		await data.save();

		// await ClientActivity.create({
		//   admin_id: req.user.id,
		//   title: "Staff Qualification Created",
		//   message: "Staff Qualification Created",
		//   act_date: new Date().toISOString(),
		// });

		res.status(200).json({
			success: true,
			message: "Staff Qualification Successfully Created",
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};
const providerSingleQualification = async (req, res, next) => {
	try {
		const { qual_id } = req.params;
		const qualification = await ProviderQualification.findOne({
			where: {
				id: qual_id,
			},
		});
		return res.status(200).json({
			status: "success",
			message: "Employee Qualification Info",
			qualification,
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};
const providerQualificationUpdate = async (req, res, next) => {
	try {
		const data = await ProviderQualification.findByPk(req.body.qual_id);

		// if (req.file) {
		//   const imageUrl = "assets/dashboard/staffdocument/" + req.file.filename;
		//   data.clearance_file = imageUrl;
		// }

		data.qualification_name = req.body.qual_type;
		data.qualification_date_issue = req.body.date_issue;
		data.qualification_date_exp = req.body.date_expire;
		data.qualification_applicable = req.body.qual_apply;
		await data.save();

		return res.status(200).json({
			status: "success",
			message: "Employee Qualification Successfully Updated",
		});
	} catch (e) {
		res.status(500).send("Server error");
	}
};

const providerQualificationDelete = async (req, res, next) => {
	try {
		const result = await ProviderQualification.destroy({
			where: { id: req.body.qual_id },
		});
		if (!result) {
			return res.status(404).send("Employee Qualification not found");
		}
		return res.status(200).json({
			status: "success",
			message: "Employee Qualification Successfully Deleted",
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send("Server error");
	}
};

//----------------------Provider Dept. Supervisor----------------------//
const providerDeptSupervisor = async (req, res, next) => {
	try {
		const { id } = req.params;
		const employee = await Provider.findOne({
			where: {
				id,
				admin_id: req.user.id,
			},
		});

		let exist_dep;
		const exist_dep_a = await ProviderDepartment.findOne({
			where: { employee_id: id },
		});
		if (exist_dep_a) {
			exist_dep = exist_dep_a;
		} else {
			exist_dep = await ProviderDepartment.create({
				admin_id: req.user.id,
				employee_id: id,
			});
		}

		const clients = await Provider.findAll({
			where: { admin_id: req.user.id },
		});

		res.status(200).json({
			status: "success",
			message: "Employee Department Supervisor",
			employee,
			exist_dep,
			clients,
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send("Server error");
	}
};

const providerDepartmentSupervisorUpdate = async (req, res, next) => {
	try {
		const { employee_id, is_supervisor, supervisor_id } = req.body;

		const updateEmployeeDepartment = await ProviderDepartment.findOne({
			where: { employee_id },
		});
		updateEmployeeDepartment.admin_id = req.user.id;
		updateEmployeeDepartment.is_supervisor = is_supervisor;
		updateEmployeeDepartment.supervisor_id = supervisor_id;
		await updateEmployeeDepartment.save();

		// await Client_activity.create({
		//   admin_id: req.user.id,
		//   title: "Staff Department Created",
		//   message: " Staff Department Created",
		//   act_date: new Date(),
		// });

		return res.status(200).json({
			status: "success",
			message: "Employee Department Successfully Updated",
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send("Server error");
	}
};

// ----------------------Provider Payroll Setup----------------------//
const providerPayroll = async (req, res, next) => {
	try {
		const { page, id } = req.body;
		const { perPage, offset } = getPagination(page);
		const provider = await Provider.findOne({
			where: {
				id,
				admin_id: req.user.id,
			},
		});

		const providerPayrolls = await ProviderPayroll.findAndCountAll({
			where: {
				employee_id: id,
			},
			limit: perPage,
			offset,
			order: [["id", "ASC"]],
		});

		const services = await SettingService.findAll({
			where: {
				admin_id: req.user.id,
			},
			order: [["id", "ASC"]],
			include: "service_treatment",
		});
		res.status(200).json({
			status: "success",
			message: "Employee Payroll Setup",
			provider,
			payrolls: getPagingData(providerPayrolls, page, perPage),
			services,
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send("Server error");
	}
};

const providerPayrollSave = async (req, res, next) => {
	const { employee_id, ser_id, hourly_rate, milage_rate } = req.body;

	if (!ser_id || ser_id.length === 0) {
		return res.status(200).json({
			status: "error",
			message: "Please select at least one service",
		});
	}
	try {
		for (let i = 0; i < ser_id.length; i++) {
			const exists = await ProviderPayroll.findOne({
				where: {
					employee_id,
					service_id: ser_id[i],
				},
			});

			if (exists) {
				return res.status(404).json({
					status: "error",
					message: "Service already exists",
				});
			}

			const lastRecord = await ProviderPayroll.findOne({
				order: [["id", "DESC"]],
			});
			// console.log("last record", parseInt(lastRecord.id));

			if (!exists) {
				await ProviderPayroll.create({
					id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
					employee_id,
					service_id: ser_id[i],
					hourly_rate,
					milage_rate,
				});
			}
		}

		// await Client_activity.create({
		//   admin_id: req.user.id,
		//   title: "Staff Payroll Created",
		//   message: "Staff Payroll Created",
		//   act_date: new Date(),
		// });

		res.status(200).json({
			status: "success",
			message: "Employee Payroll Successfully Created",
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send(e);
	}
};

const providerPayrollUpdate = async (req, res, next) => {
	try {
		const data = await ProviderPayroll.findOne({
			where: { id: req.body.edit_id },
		});
		data.employee_id = req.body.employee_id;
		data.service_id = req.body.service_id;
		data.hourly_rate = req.body.hourly;
		data.milage_rate = req.body.milage;
		// data.apply_all_activity = req.body.apply_all;
		await data.save();

		return res.status(200).json({
			status: "success",
			message: "Employee Payroll Successfully Updated",
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send("Server error");
	}
};

const providerPayrollDelete = async (req, res, next) => {
	try {
		const { id } = req.body;
		const data = await ProviderPayroll.findOne({
			where: { id },
		});
		await data.destroy();
		return res.status(200).json({
			status: "success",
			message: "Employee Payroll Successfully Deleted",
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send("Server error");
	}
};

const providerPayrollBulkEdit = async (req, res, next) => {
	try {
		let ids;
		if (req.body.ids?.length > 1) {
			ids = req.body.edit_ids?.split(",");
		} else {
			ids = req.body.edit_ids;
		}
		const check = req.body.check;
		const hourly_bulk = req.body.hourly_rate;
		const mileage_bulk = req.body.milage_rate;

		const datas = await ProviderPayroll.findAll({ where: { id: ids } });

		for (const data of datas) {
			const val = await ProviderPayroll.findByPk(data.id);

			if (check === 1) {
				val.hourly_rate = hourly_bulk;
				val.milage_rate = mileage_bulk;
			} else if (check === 2) {
				val.hourly_rate = hourly_bulk;
			} else if (check === 3) {
				val.milage_rate = mileage_bulk;
			}

			await val.save();
		}

		return res.status(200).json({
			status: "success",
			message: "Employee Payroll Successfully Updated",
			ids,
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send(e);
	}
};
// --------------------------leave tracking------------------

const get_provider_leave_tracking = async (req, res) => {
	const { employee_id } = req.body;
	try {
		const employee_leave = await ProviderLeave.findAll({
			where: {
				admin_id: req.user.id,
				employee_id: employee_id,
			},
		});
		return res.status(200).json({
			status: "success",
			message: "Staff get all leave tracking",
			leave_list: employee_leave,
		});
	} catch (err) {
		console.log(err);
		return res.status(500).json({
			status: "error",
			message: "Server error",
			e: err,
		});
	}
};

const providerLeaveTrackingSave = async (req, res) => {
	const leave_date = new Date(req.body.leave_date);
	const formatted_leave_date = leave_date.toISOString().slice(0, 10);

	const check1 = await ProviderLeave.findOne({
		where: {
			admin_id: req.user.id,
			employee_id: req.body.employee_id,
			leave_date: formatted_leave_date,
		},
	});

	const check2 = await HolidaySetup.findOne({
		where: {
			admin_id: req.user.id,
			holiday_date: formatted_leave_date,
		},
	});

	if (check1) {
		return res.status(400).json({
			status: "error",
			message: "Leave already exists",
		});
	} else if (check2) {
		return res.status(400).json({
			status: "error",
			message: "Leave is under holiday",
		});
	}

	const lastRecord = await ProviderLeave.findOne({
		order: [["id", "DESC"]],
	});

	const new_leave = await ProviderLeave.create({
		id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
		admin_id: req.user.id,
		employee_id: req.body.employee_id,
		leave_date: formatted_leave_date,
		description: req.body.desc,
	});

	return res.status(200).json({
		status: "success",
		message: "Staff leave successfully created",
		leave: new_leave,
	});
};

// providerLeaveTrackingDelete
const providerLeaveTrackingDelete = async (req, res) => {
	try {
		const delPayor = await ProviderLeave.findOne({
			where: { id: req.body.del_id, admin_id: req.user.id, employee_id: req.body.employee_id },
		});
		console.log(delPayor);

		if (delPayor) {
			await delPayor.destroy();
		}

		res.status(200).json({
			status: "success",
			message: "Staff payor exclusion successfully deleted",
		});
	} catch (err) {
		console.log(err);
		res.status(500).json({ status: "error", message: "Something went wrong" });
	}
};

// ------- insurance exclusion------------
const get_provider_get_all_payor = async (req, res, next) => {
	const { employee_id } = req.body;
	if (!employee_id) {
		return res.json({
			status: "error",
			message: "Please select staff",
		});
	}

	try {
		const assign_pyaor = await ProviderExcludePayor.findAll({
			where: {
				employee_id: employee_id,
			},
		});

		const excluded_payor_ids = assign_pyaor.map((ap) => ap.payor_id);

		const all_payor = await AllPayor.findAll({
			where: {
				id: {
					[Op.notIn]: excluded_payor_ids,
				},
			},
			attributes: ["id", "payor_name"],
			order: [["payor_name", "ASC"]],
		});
		// res.json({ e: all_payor })
		return res.json({
			status: "success",
			message: "Staff get all payor",
			all_payors: all_payor,
		});
	} catch (error) {
		console.log(error);
		return res.json({
			status: "error",
			message: "Error occurred while getting all payor",
		});
	}
};

// get all assign payor
const get_provider_get_assign_payor = async (req, res) => {
	try {
		const assignPayor = await ProviderExcludePayor.findAll({
			where: { employee_id: req.body.employee_id },
			include: "all_payor_name",
		});

		res.status(200).json({
			status: "success",
			message: "Staff get assign payor exclusion",
			assign_payors: assignPayor,
		});
	} catch (err) {
		console.log(err);
		res.status(500).json({ status: "error", message: "Something went wrong" });
	}
};

// delete payor

const provider_payor_exclution_delete = async (req, res) => {
	try {
		const delPayor = await ProviderExcludePayor.findOne({
			where: { id: req.body.del_id, employee_id: req.body.employee_id },
		});

		if (delPayor) {
			await delPayor.destroy();
		}

		res.status(200).json({
			status: "success",
			message: "Staff payor exclusion successfully deleted",
		});
	} catch (err) {
		console.log(err);
		res.status(500).json({ status: "error", message: "Something went wrong" });
	}
};

// add payor exclusion
const provider_payor_exclution_add = async (req, res) => {
	try {
		const payorIds = req.body.payor_ids;
		const employeeId = req.body.employee_id;

		const newPayorExs = await Promise.all(
			payorIds.map(async (payorId) => {
				return await ProviderExcludePayor.create({ employee_id: employeeId, admin_id: req.user.id, payor_id: payorId });
			})
		);

		res.status(200).json({
			status: "success",
			message: "Staff payor exclusion successfully created",
			new_data: newPayorExs,
		});
	} catch (err) {
		console.log(err);
		res.status(500).json({ status: "error", message: "Something went wrong" });
	}
};

// ----------------------Provider Other Setup-------------------------
const providerOtherSetup = async (req, res, next) => {
	try {
		const { id } = req.params;
		const employee = await Provider.findOne({
			where: { id, admin_id: req.user.id },
		});

		const treatmentFacility = await TreatmentFacility.findAll({
			where: { admin_id: req.user.id },
		});

		for (const treatment of treatmentFacility) {
			const checking = await ProviderDetailTxType.findOne({
				where: { admin_id: req.user.id, employee_id: id, treatment_id: treatment.treatment_id },
			});

			const lastRecord = await ProviderDetailTxType.findOne({
				order: [["id", "DESC"]],
			});
			if (!checking) {
				await ProviderDetailTxType.create({
					id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
					admin_id: req.user.id,
					employee_id: id,
					treatment_id: treatment.treatment_id,
					treatment_name: treatment.treatment_name,
					box_24j: "",
					id_qualifire: "",
				});
			}
		}

		const getAllTxType = await ProviderDetailTxType.findAll({
			where: { employee_id: id },
			order: [["treatment_id", "ASC"]],
		});

		const existsSetup = await ProviderOtherSetup.findOne({
			where: { employee_id: id },
		});

		let providerOtherSetup;
		const lastRecord = await ProviderOtherSetup.findOne({
			order: [["id", "DESC"]],
		});
		if (existsSetup) {
			providerOtherSetup = existsSetup;
		} else {
			providerOtherSetup = await ProviderOtherSetup.create({
				id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
				employee_id: id,
			});
		}

		res.status(200).json({
			status: "success",
			message: "Employee Other Setup Successfully Fetched",
			employee,
			treatmentFacility,
			getAllTxType,
			providerOtherSetup,
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send(e);
	}
};

const providerOtherSetupUpdate = async (req, res, next) => {
	try {
		const employee_id = req.body.employee_id;
		const employeeOtherSetupUpdate = await ProviderOtherSetup.findOne({ where: { employee_id: employee_id } });
		employeeOtherSetupUpdate.max_hour_per_day = req.body.max_hour_per_day;
		employeeOtherSetupUpdate.max_hour_per_week = req.body.max_hour_per_week;
		employeeOtherSetupUpdate.adp_employee_id = req.body.adp_employee_id;
		employeeOtherSetupUpdate.provider_level = req.body.provider_level;
		employeeOtherSetupUpdate.custom_two = req.body.custom_two;
		employeeOtherSetupUpdate.custom_three = req.body.custom_three;
		employeeOtherSetupUpdate.custom_four = req.body.custom_four;
		employeeOtherSetupUpdate.custom_five = req.body.custom_five;
		employeeOtherSetupUpdate.custom_six = req.body.custom_six;
		employeeOtherSetupUpdate.heigh_degree = req.body.heigh_degree;
		employeeOtherSetupUpdate.degree_level = req.body.degree_level;
		employeeOtherSetupUpdate.external_software_id = req.body.external_software_id;
		employeeOtherSetupUpdate.paid_time_off = req.body.paid_time_off;
		employeeOtherSetupUpdate.exemt_staff = req.body.exemt_staff;
		employeeOtherSetupUpdate.gets_paid_holiday = req.body.gets_paid_holiday;
		employeeOtherSetupUpdate.is_parttime = req.body.is_parttime;
		employeeOtherSetupUpdate.is_contractor = req.body.is_contractor;
		employeeOtherSetupUpdate.provider_render_without = req.body.provider_render_without;
		employeeOtherSetupUpdate.signature_valid_form = req.body.signature_valid_form;
		employeeOtherSetupUpdate.signature_valid_to = req.body.signature_valid_to;

		await employeeOtherSetupUpdate.save();

		const editTxId = req.body.edit_tx_id;
		const box24j = req.body.box_24j;
		const idQualifire = req.body.id_qualifire;
		if (editTxId) {
			for (let i = 0; i < editTxId.length; i++) {
				const updateTx = await ProviderDetailTxType.findOne({
					where: {
						employee_id: employee_id,
						id: editTxId[i],
					},
				});
				if (updateTx) {
					updateTx.box_24j = box24j[i];
					updateTx.id_qualifire = idQualifire[i];
					await updateTx.save();
				}
			}
		}

		// await Client_activity.create({
		//   admin_id: req.user.id,
		//   title: "Staff Other Setup Updated",
		//   message: "Staff Other Setup Updated",
		//   act_date: new Date().toISOString(),
		// });

		return res.status(200).json({ success: true, message: "Staff Other Setup Successfully Updated" });
	} catch (e) {
		console.log(e.message);
		res.status(500).send(e);
	}
};

// ----------------------Provider Service Subtype Exclusion-------------------------
const providerAllServiceSubtype = async (req, res, next) => {
	try {
		const employeeId = req.body.employee_id;

		const employee = await Provider.findOne({ where: { id: employeeId } });

		const employeeSubActivity = await ProviderSubActExclusion.findAll({
			where: { employee_id: employeeId },
		});

		const array = [];
		employeeSubActivity.forEach((emacts) => {
			array.push(emacts.sub_activity_id);
		});

		const allServiceSubtype = await AllSubActivity.findAll({
			where: {
				id: { [Sequelize.Op.notIn]: array },
				admin_id: employee.admin_id,
			},
		});

		return res.status(200).json({
			status: "success",
			message: "Employee Service Subtype Successfully Fetched",
			allSubtype: allServiceSubtype,
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send(e.message);
	}
};

const providerAssignedSubtype = async (req, res, next) => {
	try {
		const id = req.body.employee_id;

		// const employee = await Provider.findOne({
		//   where: { id, admin_id: req.user.id },
		// });
		const allAssignedSubtype = await ProviderSubActExclusion.findAll({
			where: { admin_id: req.user.id, employee_id: id },
			order: [["id", "ASC"]],
			include: "subactivity",
		});
		const totalExcluded = await ProviderSubActExclusion.count({
			where: { admin_id: req.user.id, employee_id: id },
		});

		res.status(200).json({
			allAssignedSubtype,
			totalExcluded,
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send(e.message);
	}
};

const providerSubActExclusionSave = async (req, res, next) => {
	try {
		const { employee_id, sub_activity_id } = req.body;
		for (let i = 0; i < sub_activity_id.length; i++) {
			const lastRecord = await ProviderSubActExclusion.findOne({
				order: [["id", "DESC"]],
			});
			const subactivityAdded = await ProviderSubActExclusion.create({
				id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
				admin_id: req.user.id,
				employee_id,
				sub_activity_id: sub_activity_id[i],
			});
		}
		res.status(200).json({
			status: "success",
			message: "Employee Service Subtype Successfully Saved",
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send(e.message);
	}
};

const providerSubtActExclusionDelete = async (req, res, next) => {
	try {
		const { del_id, employee_id } = req.body;
		const data = await ProviderSubActExclusion.findOne({
			where: { id: del_id, employee_id },
		});
		await data.destroy();
		return res.status(200).json({
			status: "success",
			message: "Employee Service Subtype Successfully Deleted",
		});
	} catch (e) {
		console.log(e.message);
		res.status(500).send(e.message);
	}
};

//----------------------Provider Patient Exclusion-------------------------
const providerGetAllPatient = async (req, res, next) => {
	try {
		const { employee_id } = req.body;
		const employee = await Provider.findOne({
			where: {
				id: employee_id,
			},
		});

		const assingedPatient = await ProviderClientExclusion.findAll({
			where: {
				employee_id,
			},
		});
		const array = assingedPatient.map((eachPatient) => eachPatient?.client_id);

		const patients = await Patient.findAll({
			where: {
				id: {
					[Sequelize.Op.notIn]: array,
				},
				admin_id: employee.admin_id,
			},
			order: [["client_full_name", "ASC"]],
		});
		res.status(200).json({
			status: "success",
			message: "Employee Patient Successfully Fetched",
			allPatients: patients,
		});
	} catch (error) {
		console.log(error);
		res.status(500).send("Server Error");
	}
};

const providerAllAssignedPatient = async (req, res, next) => {
	try {
		const { employee_id } = req.body;
		const assign_clients = await ProviderClientExclusion.findAll({
			where: {
				employee_id,
			},
			include: "clientInfo",
		});
		res.status(200).json({
			status: "success",
			message: "Employee Assigned Patient Successfully Fetched",
			assignedPatients: assign_clients,
		});
	} catch (error) {
		console.log(error);
		res.status(500).send("Server Error");
	}
};

const providerPatientExclusionSave = async (req, res, next) => {
	const { patient_ids, employee_id } = req.body;

	try {
		for (let i = 0; i < patient_ids.length; i++) {
			const lastRecord = await ProviderClientExclusion.findOne({
				order: [["id", "DESC"]],
			});
			const new_payor_ex = await ProviderClientExclusion.create({
				id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
				admin_id: req.user.id,
				employee_id: employee_id,
				client_id: patient_ids[i],
			});
		}

		res.status(200).json({
			status: "success",
			message: "Provider Assigned Patient Successfully Saved",
		});
	} catch (error) {
		console.log(error);
		res.status(500).send(error);
	}
};

const providerPatientExclusionDelete = async (req, res, next) => {
	try {
		const { del_id, employee_id } = req.body;
		const deleteAssignedPatient = await ProviderClientExclusion.findOne({
			where: { id: del_id, employee_id },
		});
		await deleteAssignedPatient.destroy();

		res.status(200).json({
			status: "success",
			message: "provider Assigned Patient Successfully Deleted",
		});
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "Server Error" });
	}
};

//----------------------Provider Work Schedule-------------------------
const getWorkingSchedule = async (req, res, next) => {
	try {
		const { id } = req.params;
		console.log(id);

		let working_hour = await ProviderWorkSchedule.findOne({
			where: { admin_id: req.user.id, employee_id: id },
		});

		const lastRecord = await ProviderWorkSchedule.findOne({
			order: [["id", "DESC"]],
		});

		if (!working_hour) {
			working_hour = await ProviderWorkSchedule.create({
				id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
				admin_id: req.user.id,
				employee_id: id,
			});
		}

		return res.status(200).json(working_hour);
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "Server Error" });
	}
};

const createWorkingSchedule = async (req, res, next) => {
	try {
		const {
			employee_id,
			mon_start,
			mon_end,
			tue_start,
			tue_end,
			wed_start,
			wed_end,
			thu_start,
			thu_end,
			fri_start,
			fri_end,
			sat_start,
			sat_end,
			sun_start,
			sun_end,
		} = req.body;

		let working_hour = await ProviderWorkSchedule.findOne({
			where: {
				admin_id: req.user.id,
				employee_id: employee_id,
			},
		});

		const lastRecord = await ProviderWorkSchedule.findOne({
			order: [["id", "DESC"]],
		});
		if (!working_hour) {
			working_hour = await ProviderWorkSchedule.create({
				id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
				admin_id: req.user.id,
				employee_id: employee_id,
			});
		}

		const date = moment(); // Today's date
		//Time saved to DB in UTC format(UTC is Global time)
		working_hour.mon_start = mon_start ? moment.utc(`${date.format("YYYY-MM-DD")} ${mon_start}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.mon_end = mon_end ? moment.utc(`${date.format("YYYY-MM-DD")} ${mon_end}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.tue_start = tue_start ? moment.utc(`${date.format("YYYY-MM-DD")} ${tue_start}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.tue_end = tue_end ? moment.utc(`${date.format("YYYY-MM-DD")} ${tue_end}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.wed_start = wed_start ? moment.utc(`${date.format("YYYY-MM-DD")} ${wed_start}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.wed_end = wed_end ? moment.utc(`${date.format("YYYY-MM-DD")} ${wed_end}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.thu_start = thu_start ? moment.utc(`${date.format("YYYY-MM-DD")} ${thu_start}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.thu_end = thu_end ? moment.utc(`${date.format("YYYY-MM-DD")} ${thu_end}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.fri_start = fri_start ? moment.utc(`${date.format("YYYY-MM-DD")} ${fri_start}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.fri_end = fri_end ? moment.utc(`${date.format("YYYY-MM-DD")} ${fri_end}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.sat_start = sat_start ? moment.utc(`${date.format("YYYY-MM-DD")} ${sat_start}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.sat_end = sat_end ? moment.utc(`${date.format("YYYY-MM-DD")} ${sat_end}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.sun_start = sun_start ? moment.utc(`${date.format("YYYY-MM-DD")} ${sun_start}:00`, "YYYY-MM-DD HH:mm:ss") : null;
		working_hour.sun_end = sun_end ? moment.utc(`${date.format("YYYY-MM-DD")} ${sun_end}:00`, "YYYY-MM-DD HH:mm:ss") : null;

		await working_hour.save();

		return res.status(200).json({
			status: "success",
			message: "Provider Working Schedule Successfully Saved",
		});
	} catch (error) {
		console.log(error);
		res.status(500).json(error);
	}
};

const bypassWorkScheduleValidation = async (req, res, next) => {
	try {
		const { id, val } = request;

		const foundEmployee = await Provider.findOne({
			where: {
				id,
				admin_id: req.user.id,
			},
		});

		if (foundEmployee) {
			foundEmployee.bypass = val;
			await foundEmployee.save();
		}
	} catch (error) {
		console.log(error);
		res.status(500).json(error);
	}
};

const getAllBlockOffTTime = async (req, res, next) => {
	try {
		const listBlockOffTime = await ProviderBlockOffTime.findAll({
			where: {
				admin_id: req.user.id,
				staff_id: req.body.staff_id,
			},
		});
		return res.status(200).json({
			status: "success",
			blockOffTime: listBlockOffTime,
		});
	} catch (error) {
		console.log(error);
		res.status(500).json(error);
	}
};

const createBlockOffTime = async (req, res, next) => {
	try {
		const { staff_id, type, specific_date, week_days, start_time, end_time, description } = req.body;

		console.log("week-days", week_days);
		const lastRecord = await ProviderBlockOffTime.findOne({
			order: [["id", "DESC"]],
		});
		const data = await ProviderBlockOffTime.create({
			id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
			admin_id: req.user.id,
			staff_id,
			type: type,
			date: specific_date || null,
			days: JSON.stringify(week_days) || null,
			start_time: start_time,
			end_time: end_time,
			description: description,
		});

		res.status(200).json({
			status: "success",
			message: "Provider Block Off Time Successfully Saved",
			data,
		});
	} catch (error) {
		console.log(error);
		res.status(500).json(error);
	}
};

const deleteBlockOffTime = async (req, res, next) => {
	try {
		const { id } = req.body;
		const data = await ProviderBlockOffTime.destroy({
			where: { id },
		});
		if (data) {
			return res.status(200).send({ status: "success", message: "Block off time deleted successfully" });
		} else {
			return res.status(200).send({ status: "success", message: "Block off time not found" });
		}
	} catch (error) {
		console.log(error);
		res.status(500).json(error);
	}
};

export default {
	createProvider,
	get_provider_get_all_payor,
	get_provider_get_assign_payor,
	provider_payor_exclution_add,
	provider_payor_exclution_delete,
	providerList,
	get_provider_leave_tracking,
	providerLeaveTrackingSave,
	providerLeaveTrackingDelete,
	employeeStatusUpdate,
	providerBiographic,
	providerBiographicUpdate,
	providerContactInfo,
	providerContactInfoUpdate,
	providerEmergencyContactDetailsUpdate,
	providerCredentialList,
	providerCredentialSave,
	singleProviderCredential,
	providerCredentialUpdate,
	providerCredentialDelete,
	providerClearenceList,
	providerClearenceSave,
	singleProviderClearance,
	providerClearanceupdate,
	providerClearanceDelete,
	providerQualificationList,
	providerQualificationSave,
	providerSingleQualification,
	providerQualificationUpdate,
	providerQualificationDelete,
	providerDeptSupervisor,
	providerDepartmentSupervisorUpdate,
	providerPayroll,
	providerPayrollSave,
	providerPayrollUpdate,
	providerPayrollDelete,
	providerPayrollBulkEdit,
	providerOtherSetup,
	providerOtherSetupUpdate,
	providerAllServiceSubtype,
	providerAssignedSubtype,
	providerSubActExclusionSave,
	providerSubtActExclusionDelete,
	providerGetAllPatient,
	providerAllAssignedPatient,
	providerPatientExclusionSave,
	providerPatientExclusionDelete,
	getWorkingSchedule,
	createWorkingSchedule,
	getAllBlockOffTTime,
	createBlockOffTime,
	deleteBlockOffTime,
};
