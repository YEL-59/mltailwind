import Deposit from "../../../models/Payment/deposit.js";
import DepositApply from "../../../models/Payment/depositApply.js";
import Patient from "../../../models/Patient/Patient.js";
import PriManageClaimTransaction from "../../../models/PrimaryBilling/ManageClaimTransaction.js";
import { Op } from "sequelize";
import { getProcessClaims, updateDepositData } from "../../../helpers/payment/depositHelper.js";

const cashPostingList = async (req, res) => {
  try {
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const cashPostingCreate = async (req, res) => {
  try {
    const { payor_type, payor_id, client_id, deposit_date, payment_method, instrument, instrument_date, amount, unapplied_amount, notes } = req.body;

    const check_exists = await Deposit.findOne({
      where: {
        admin_id: req.user.id,
        instrument: instrument,
      },
    });

    if (check_exists) {
      res.json({
        status: "error",
        message: "check already exists.",
      });
      return false;
    }

    await Deposit.create({
      admin_id: req.user.id,
      payor_type: payor_type,
      payor_id: payor_id,
      client_id: client_id,
      deposit_date: deposit_date,
      payment_method: payment_method,
      instrument: instrument,
      instrument_date: instrument_date,
      amount: amount,
      unapplied_amount: unapplied_amount,
      notes: notes,
    });

    res.json({
      status: "success",
      message: "deposit successfully created",
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const cashPostingEdit = async (req, res) => {
  try {
    const { dep_edit_id } = req.body;
    const deposit = await Deposit.findOne({
      where: {
        admin_id: req.user.id,
        id: dep_edit_id,
      },
    });

    res.json({
      status: "success",
      message: "deposit single data",
      data: deposit,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const cashPostingUpdate = async (req, res) => {
  try {
    const { dep_id, payor_id, client_id, deposit_date, payment_method, instrument, instrument_date, amount, unapplied_amount, notes } = req.body;

    const update_deposit = await Deposit.findOne(
      {
        payor_type: payor_type,
        payor_id: payor_id,
        client_id: client_id,
        deposit_date: deposit_date,
        payment_method: payment_method,
        instrument: instrument,
        instrument_date: instrument_date,
        amount: amount,
        unapplied_amount: unapplied_amount,
        notes: notes,
      },
      {
        where: {
          admin_id: req.user.id,
          id: dep_id,
        },
      }
    );

    res.json({
      status: "success",
      message: "deposit successfully updated",
      data: update_deposit,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const cashPostingDelete = async (req, res) => {
  try {
    const { dep_id } = req.body;

    const check_exist_dep = await DepositApply.findAndCountAll({
      where: {
        admin_id: req.user.id,
        deopsit_id: dep_id,
      },
    });

    if (check_exist_dep.count > 0) {
      res.json({
        status: "error",
        message: "selected deposits have active payments",
      });
      return false;
    }

    await Deposit.destroy({
      where: {
        admin_id: req.user.id,
        id: dep_id,
      },
    });

    res.json({
      status: "success",
      message: "deposit successfully deleted",
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const depApplyById = async (req, res) => {
  try {
    const { dep_id, payee_type } = req.body;
    if (payee_type == 1) {
      const patient_list = await Patient.findAll({
        where: {
          admin_id: req.user.id,
        },
      });

      res.json({
        status: "success",
        message: "deposit apply patient based on payee type patient",
        patient_list: patient_list,
      });
    } else {
      const dep_apply_list = DepositApply.findAll({
        attributes: ["admin_id", "client_id"],
        group: ["admin_id", "client_id"],
        where: {
          admin_id: req.user.id,
        },
      });

      let cl_ids = [];
      await Promise.all(
        dep_apply_list.map(async (i) => {
          cl_ids.push(i.client_id);
        })
      );

      const patient_lists = Patient.findAll({
        where: {
          admin_id: req.user.id,
          id: {
            [Op.in]: cl_ids,
          },
        },
      });

      res.json({
        status: "success",
        message: "deposit apply patient based on payee type payor",
        patient_list: patient_lists,
      });
    }
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const depAppShowAdjPayTop = async (req, res) => {
  try {
    // const {dep_id}
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const depApplyGetData = async (req, res) => {
  try {
    const { post_by, claim_no } = req.body;
    if (post_by === 1) {
      const procc_claim_datas = await getProcessClaims(req.user.id, claim_no);
      const update_dep_datas = await updateDepositData(req.user.id, procc_claim_datas);
      res.json({
        status: "success",
        message: "deposit apply patient based on payee type patient",
      });
    } else if (post_by === 2) {
      res.json({
        status: "success",
        message: "deposit apply patient based on payee type patient",
      });
    } else {
      res.json({
        status: "error",
        message: "something goes wrong",
      });
    }
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const depApplySaveData = async (req, res) => {};
const depGetTransactions = async (req, res) => {};
const depDataRevert = async (req, res) => {};

export default {
  cashPostingList,
  cashPostingCreate,
  cashPostingEdit,
  cashPostingUpdate,
  cashPostingDelete,
  depApplyById,
  depAppShowAdjPayTop,
  depApplyGetData,
  depApplySaveData,
  depGetTransactions,
  depDataRevert,
};
