import Patient from "../../../models/Patient/Patient.js";
import Provider from "../../../models/Provider/Provider.js";
import AllSubActivity from "../../../models/Setting/AllSubActivity.js";
import PayorFacility from "../../../models/Setting/PayorFacility.js";
import SettingService from "../../../models/Setting/SettingService.js";
import TreatmentFacility from "../../../models/Setting/TreatmentFacility.js";

const globalPatientList = async (req, res, next) => {
  try {
    const patients = await Patient.findAll({
      attributes: ["id", "admin_id", "client_full_name"],
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "get patient list",
      data: patients,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};
const globalProviderList = async (req, res, next) => {
  try {
    const providers = await Provider.findAll({
      attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "global provider list",
      data: providers,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const globalSelectedFacility = async (req, res, next) => {
  try {
    const selectedInsurance = await PayorFacility.findAll({
      attributes: ["id", "admin_id", "payor_name", "payor_id"],
      where: {
        admin_id: req.user.id,
      },
    });
    res.json({
      status: "success",
      message: "global facility insurance list",
      data: selectedInsurance,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const globalSettingService = async (req, res) => {
  try {
    const setting_service = await SettingService.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "global setting service list",
      data: setting_service,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send("Server error");
  }
};

const globalSelectedTreatment = async (req, res) => {
  try {
    const selected_treatment = await TreatmentFacility.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "global selected treatment facility list",
      data: selected_treatment,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

const globalAllSubActivity = async (req, res) => {
  try {
    const all_sub_act = await AllSubActivity.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "global all sub activity list",
      data: all_sub_act,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

export default {
  globalPatientList,
  globalProviderList,
  globalSelectedFacility,
  globalSettingService,
  globalSelectedTreatment,
  globalAllSubActivity,
};
