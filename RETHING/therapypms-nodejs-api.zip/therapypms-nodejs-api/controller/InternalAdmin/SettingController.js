import moment from "moment";
import SettingNameLocation from "../../models/Setting/SettingNameLocation.js";
import AllPayor from "../../models/Setting/AllPayor.js";
import PayorFacility from "../../models/Setting/PayorFacility.js";
import PayorFacilityDetails from "../../models/Setting/PayorFacilityDetails.js";
import AllTreatment from "../../models/Setting/AllTreatment.js";
import TreatmentFacility from "../../models/Setting/TreatmentFacility.js";
import SettingService from "../../models/Setting/SettingService.js";
import SettingCptCode from "../../models/Setting/SettingCptCode.js";
import SettingWorkingHour from "../../models/Setting/SettingWorkingHour.js";
import SettingNameLocationBoxTwo from "../../models/Setting/SettingNameLocationBoxTwo.js";
import SettingPos from "../../models/Setting/PointOfService.js";
import ReferringProvider from "../../models/Setting/RenderingProvider.js";
import CptCodeExclusions from "../../models/Setting/CptCodeExclusions.js";
import AllSubActivity from "../../models/Setting/AllSubActivity.js";
import EmployeeTypeAssign from "../../models/Setting/EmployeeTypeAssign.js";
import AllEmployeeTypes from "../../models/Setting/AllEmployeeType.js";
import VendorNumber from "../../models/Setting/VendorNumber.js";
import HolidaySetup from "../../models/Setting/HolidaySetup.js";
import AllPayorDetail from "../../models/Setting/AllPayorDetail.js";
import PayorDetailsTxType from "../../models/Setting/PayorDetailsTxTypes.js";
import PayPeriod from "../../models/Setting/PayPeriod.js";

//pagination
import { getPagination, getPagingData } from "../../helpers/pagination.js";
import { checkDateFunction, firstDate } from "../../helpers/common/Common.js";
import { Op, Sequelize } from "sequelize";
import PatientAuthorization from "../../models/Patient/PatientAuthorization.js";

// getNameLocation
const getNameLocation = async (req, res, next) => {
  try {
    const getNameLocationData = await SettingNameLocation.findOne({
      where: {
        admin_id: req.user.id,
      },
    });

    const nameLocationBoxTwo = await SettingNameLocationBoxTwo.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    const setWorkingHour = await SettingWorkingHour.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    // const result = [];

    // const externalData = nameLocationBoxTwo?.map((item, index) => {

    //   if (index != 0) {
    //     result.push(item)
    //   }

    //   return {
    //     nameLocationBoxTwo[0],
    //     item
    //   }

    // })

    // console.log(externalData);

    // let dm = []

    // const primaryData = dm.push(nameLocationBoxTwo[0])

    // // const customdata = primaryData.push(result);

    // const hl = { ...dm, result }

    // dm.result = result;
    // console.log(dm);

    //  const d =  data.primaryData.externalData.forEach((box) => {
    //     const newObj = { ...data.box_32main };
    //     delete newObj.box_32;
    //     result.push({ ...newObj, ...box });
    //   });

    // const data = {
    //   ...primaryData,
    //   externalData
    // }

    res.json({
      status: "success",
      message: "facility setting name & location",
      setting_name_location: getNameLocationData,
      setting_working_hour: setWorkingHour,
      box_32: nameLocationBoxTwo?.filter((item, index) => index !== 0),
      box_32main: nameLocationBoxTwo[0],
      // box_32: nameLocationBoxTwo

      // box_32: {...primaryData, x: {=...externalData}}
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// updateNameLocation
const updateNameLocation = async (req, res, next) => {
  try {
    const nameLocation = await SettingNameLocation.findOne({
      where: {
        admin_id: req.user.id,
      },
    });

    nameLocation.set({
      facility_name: req.body.facility_name,
      address: req.body.address,
      address_two: req.body.address_two,
      city: req.body.city,
      state: req.body.state,
      zip: req.body.zip,
      phone_one: req.body.phone_one,
      short_code: req.body.short_code,
      email: req.body.email,
      ein: req.body.ein,
      npi: req.body.npi,
      taxonomy: req.body.taxonomy,
      taxonomy_code: req.body.taxonomy_code,
      contact_person: req.body.contact_person,
      is_deafilt_facility: req.body.is_deafilt_facility,
      start_time: req.body.start_time,
      end_time: req.body.end_time,
      service_area_miles: req.body.service_area_miles,
      user_default_password: req.body.user_default_password,
      default_pos: req.body.default_pos,
      timezone: req.body.timezone,
      ftp_username: req.body.ftp_username,
      ftp_password: req.body.ftp_password,
      is_combo: req.body.is_combo,
      email_reminder: req.body.email_reminder,
    });

    await nameLocation.save();

    const working_hour = await SettingWorkingHour.findOne({
      where: {
        admin_id: req.user.id,
      },
    });

    // working_hour.set({
    //   mon_start_time: req.body.mon_start,
    //   mon_end_time: req.body.mon_end,
    //   tus_start: req.body.tues_start,
    //   tus_end: req.body.tues_end,
    //   wed_start: req.body.wed_start,
    //   wed_end: req.body.wed_end,
    //   thur_start: req.body.thur_start,
    //   thur_end: req.body.thur_end,
    //   fri_start: req.body.fri_start,
    //   fri_end: req.body.fri_end,
    //   sat_start: req.body.sat_start,
    //   sat_end: req.body.sat_end,
    //   sun_start: req.body.sun_start,
    //   sun_end: req.body.sun_end,
    // });

    // const inputDateTimeStr = "2023-05-08T12:09:31+03:00";
    // const inputDateTime = moment(inputDateTimeStr);
    // const utcDateTime = inputDateTime.utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");

    console.log("monent mon ------start", req.body.mon_start_time);

    // working_hour.set({
    //   // mon_start_time: req.body.mon_start,
    //   mon_end_time: moment(req.body.mon_end),
    //   tus_start: moment(req.body.tues_start),
    //   tus_end: moment(req.body.tues_end),
    //   wed_start: moment(req.body.wed_start),
    //   wed_end: moment(req.body.wed_end),
    //   thur_start: moment(req.body.thur_start),
    //   thur_end: moment(req.body.thur_end),
    //   fri_start: moment(req.body.fri_start),
    //   fri_end: moment(req.body.fri_end),
    //   sat_start: moment(req.body.sat_start),
    //   sat_end: moment(req.body.sat_end),
    //   sun_start: moment(req.body.sun_start),
    //   sun_end: moment(req.body.sun_end),
    // })

    // const momentObj = moment(req.body?.mon_start, 'HH:mm').set({ year: moment().year(), month: moment().month(), date: moment().date() });

    // // Convert moment object to UTC and format it as string
    // const formattedTimemon = momentObj.utc().format('YYYY-MM-DD HH:mm:ss.SSS [UTC] (Z)');
    // console.log("formattedTimemon------", formattedTimemon);

    const timeformter = (x) => {
      const timeString = x;
      const date = moment.utc().format("YYYY-MM-DD");
      const time = moment.utc(`${date} ${timeString}:00.0`).format("HH:mm:ss.SSS [UTC] (Z)");
      return moment.utc(`${date} ${timeString}:00.0`).format("YYYY-MM-DD HH:mm:ss.SSS [UTC] (Z)");
    };

    // console.log("--------", dateTimeString);

    working_hour.set({
      mon_start_time: timeformter(req.body.mon_start_time),
      mon_end_time: timeformter(req.body.mon_end_time),
      tus_start: timeformter(req.body.tus_start),
      tus_end: timeformter(req.body.tus_end),
      wed_start: timeformter(req.body.wed_start),
      wed_end: timeformter(req.body.wed_end),
      thur_start: timeformter(req.body.thur_start),
      thur_end: timeformter(req.body.thur_end),
      fri_start: timeformter(req.body.fri_start),
      fri_end: timeformter(req.body.fri_end),
      sat_start: timeformter(req.body.sat_start),
      sat_end: timeformter(req.body.sat_end),
      sun_start: timeformter(req.body.sun_start),
      sun_end: timeformter(req.body.sun_end),
      // mon_end_time: moment(req.body.mon_end).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // tus_start: moment(req.body.tues_start).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // tus_end: moment(req.body.tues_end).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // wed_start: moment(req.body.wed_start).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // wed_end: moment(req.body.wed_end).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // thur_start: moment(req.body.thur_start).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // thur_end: moment(req.body.thur_end).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // fri_start: moment(req.body.fri_start).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // fri_end: moment(req.body.fri_end).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // sat_start: moment(req.body.sat_start).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // sat_end: moment(req.body.sat_end).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // sun_start: moment(req.body.sun_start).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
      // sun_end: moment(req.body.sun_end).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]')
    });

    await working_hour.save();

    res.json({
      status: "success",
      message: "facility setting name & location successfully updated",
      setting_name_location: nameLocation,
      setting_working_hour: working_hour,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// const setting_name_location_box_two = require('../models/setting_name_location_box_two');

const name_location_box_32_save = async (req, res) => {
  const { admin_id } = req.user.id;
  const { box_32_id, zone_name, facility_name_two, address, city, state, zip, phone_one, npi } = req.body;

  await setting_name_location_box_two.update(
    {
      zone_name,
      facility_name_two,
      address,
      city,
      state,
      zip,
      phone_one,
      npi,
    },
    {
      where: {
        admin_id,
        id: box_32_id,
      },
    }
  );

  if (req.body.new_zone_name) {
    const newBoxData = req.body.new_zone_name.map((newZoneName, i) => {
      return {
        id: req.body.edit_box_id[i],
        admin_id,
        zone_name: newZoneName || null,
        facility_name_two: req.body.new_facility_name_two[i] || null,
        address: req.body.new_address[i] || null,
        city: req.body.new_city[i] || null,
        state: req.body.new_state[i] || null,
        zip: req.body.new_zip[i] || null,
        phone_one: req.body.new_phone_one[i] || null,
        npi: req.body.new_npi[i] || null,
        admin_create: 0,
      };
    });

    await Promise.all(
      newBoxData.map((data) => {
        return setting_name_location_box_two.upsert(data, { where: { id: data.id } });
      })
    );
  }

  return res.redirect("back").with("success", "Box No 32 updated");
};

// ----------------------- Add INSURANCE  --------------------------------

// searchInsurance
const searchInsurance = async ({ body: { searchItem }, user: { id } }, res) => {
  try {
    const facilityInsuranceIds = await PayorFacility.findAll({
      where: { admin_id: id },
    });
    const facIds = facilityInsuranceIds.map(({ payor_id }) => payor_id);
    const getAllInsurance = await AllPayor.findAll({
      where: {
        id: { [Op.notIn]: facIds },
        ...(searchItem && { payor_name: { [Op.iLike]: `%${searchItem}%` } }),
      },
      order: [["payor_name", "ASC"]],
    });
    res.json({
      status: "success",
      message: "facility setting get all insurance",
      all_insurance: getAllInsurance,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

// const facilitySearchInsurance = async ({ body: { searchItem }, user: { id } }, res) => {
//   try {
//     const allTreatments = await PayorFacility.findAll({
//       where: {
//         ...(searchItem && { payor_name: { [Op.iLike]: `%${searchItem}%` } }),
//       },
//       order: [['payor_name', 'ASC']]
//     });
//     res.json({
//       status: "success",
//       message: "facility setting get all insurance",
//       length: allTreatments.length,
//       selectedInsurance: allTreatments,

//     });
//   } catch (error) {
//     console.error(error.message);
//     res.status(500).send("Server error");
//   }

// };

// checking code

const facilitySearchInsurance = async (req, res, next) => {
  try {
    const { searchItem } = req.body;
    let whereClause = { admin_id: req.user.id };

    if (searchItem) {
      whereClause = {
        ...whereClause,
        payor_name: { [Op.iLike]: `%${searchItem}%` },
      };
    }

    const selectedInsurance = await PayorFacility.findAll({
      where: whereClause,
    });

    res.json({
      status: "success",
      message: "facility selected insurance get",
      length: selectedInsurance.length,
      facility_selected_insurance: selectedInsurance,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const getAllInsurance = async (req, res, next) => {
  try {
    let facIds = [];
    let facilityInsuranceIds = await PayorFacility.findAll({
      where: {
        admin_id: req.user.id,
      },
    });
    // res.send(facilityInsuranceIds);
    await Promise.all(
      facilityInsuranceIds.map(async (i) => {
        facIds.push(i.payor_id);
        return i + 1;
      })
    );

    const getAllInsurance = await AllPayor.findAll({
      where: {
        id: {
          [Op.notIn]: facIds,
        },
      },
    });

    res.json({
      status: "success",
      message: "facility setting get all insurance",
      all_insurance: getAllInsurance,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// getFacilitySelectedInsurance
const getFacilitySelectedInsurance = async (req, res, next) => {
  try {
    const selectedInsurance = await PayorFacility.findAll({
      where: {
        admin_id: req.user.id,
      },
    });
    res.json({
      status: "success",
      message: "facility selected insurance get",
      length: selectedInsurance.length,
      facility_selected_insurance: selectedInsurance,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// addInsuranceToFacility
const addInsuranceToFacility = async (req, res, next) => {
  try {
    let insurance_id = req.body.insurance_ids;
    for (let i = 0; i < insurance_id.length; i++) {
      let singlePayor = await AllPayor.findOne({
        where: {
          id: insurance_id[i],
        },
      });
      let insuranceFacilityDetails = await PayorFacilityDetails.findOne({
        where: {
          id: singlePayor.facility_payor_id,
        },
      });

      const lastRecord = await PayorFacility.findOne({
        order: [["id", "DESC"]],
      });

      await PayorFacility.create({
        id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
        admin_id: req.user.id,
        payor_id: singlePayor.id,
        facility_payor_id: singlePayor.facility_payor_id,
        payor_name: singlePayor.payor_name,
        address: insuranceFacilityDetails.address,
        city: insuranceFacilityDetails.city,
        state: insuranceFacilityDetails.state,
        zip: insuranceFacilityDetails.zip,
        contact_one: insuranceFacilityDetails.contact_one,
        contact_two: insuranceFacilityDetails.contact_two,
        phone_one: insuranceFacilityDetails.phone_one,
        phone_two: insuranceFacilityDetails.phone_two,
        fpayor_id: insuranceFacilityDetails.payor_id,
        is_regional_center: insuranceFacilityDetails.is_regional_center,
        regional_center_name: insuranceFacilityDetails.regional_center_name,
        billing_aber: insuranceFacilityDetails.billing_aber,
        ele_payor_id: insuranceFacilityDetails.ele_payor_id,
        create_by: insuranceFacilityDetails.create_by,
        plain_medicare: insuranceFacilityDetails.plain_medicare,
        plan_medicalid: insuranceFacilityDetails.plan_medicalid,
        plan_campus: insuranceFacilityDetails.plan_campus,
        plan_champva: insuranceFacilityDetails.plan_champva,
        plan_group_health: insuranceFacilityDetails.plan_group_health,
        plan_feca: insuranceFacilityDetails.plan_feca,
        plan_others: insuranceFacilityDetails.plan_others,
        claim_filing_indicator: insuranceFacilityDetails.claim_filing_indicator,
      });
    }
    res.json({
      status: "success",
      message: "insurance successfully added to facility",
    });
  } catch (e) {
    console.error(e.message);

    // res.status(500).send("Server error");
    res.json({
      error: e.message,
    });
  }
};

// deleteInsuranceFacility
const deleteInsuranceFacility = async (req, res, next) => {
  try {
    let insurance_id = req.body.insurance_ids;
    await Promise.all(
      insurance_id.map((insuranceId) => {
        return PayorFacility.destroy({
          where: {
            [Op.and]: [{ admin_id: req.user.id }, { id: insuranceId }],
          },
        });
      })
    );

    res.json({
      status: "success",
      message: "insurance successfully deleted from facility",
    });
  } catch (e) {
    console.error(e.message);
    res.json({
      error: e.message,
    });

    // res.status(500).send("Server error");
  }
};

// updateInsuranceFacility
const updateInsuranceFacility = async (req, res, next) => {
  try {
    const {
      f_edit_id,
      Payor_id,
      address,
      billing_aber,
      payor_id_eligibility,
      city,
      contact_one,
      contact_two,
      ele_payor_id,
      payor_name,
      phone_one,
      phone_two,
      state,
      zip,
      is_regional_center,
    } = req.body;

    const selectedInsuranceDetils = await PayorFacility.findOne({
      where: {
        [Op.and]: [{ id: f_edit_id }, { admin_id: req.user.id }],
      },
    });

    selectedInsuranceDetils.set({
      Payor_id,
      address,
      billing_aber,
      payor_id_eligibility,
      city,
      contact_one,
      contact_two,
      ele_payor_id,
      payor_name,
      phone_one,
      phone_two,
      state,
      zip,
      is_regional_center,
    });

    await selectedInsuranceDetils.save();

    res.status(200).json({
      status: "success",
      message: "InsuranceFacility updated",
      "setting_facilaty-details-updated": selectedInsuranceDetils,
    });
  } catch (error) {
    console.error(error.message);
    res.json({ error: error.message });
    // res.status(500).send("Server error");
  }
};

// allInsuranceDetails
const allInsuranceDetails = async (req, res, next) => {
  try {
    let insurance_id = req.body.insurance_id[0];
    const selectedInsuranceDetails = await PayorFacilityDetails.findOne({
      where: {
        id: insurance_id,
      },
    });
    res.status(200).send({
      status: "success",
      message: "insurance details",
      all_insurance_details: selectedInsuranceDetails,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// facilitySelectedInsuranceDetails
const facilitySelectedInsuranceDetails = async (req, res, next) => {
  try {
    let insurance_id = req.body.insurance_id;
    const selectedInsuranceDetails = await PayorFacility.findOne({
      where: {
        id: insurance_id[0],
      },
    });
    res.status(200).send({
      status: "success",
      message: "facility selected insurance details",
      selected_insurance_details: selectedInsuranceDetails,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// ----------------------- SETTING INSURANCE SETUP -----------------------
const payorSetup = async (req, res, next) => {
  try {
    const { page } = req.body;
    const { perPage, offset } = getPagination(page);

    const allPayorDetails = await AllPayorDetail.findAndCountAll({
      where: {
        admin_id: req.user.id,
      },
      order: [["id", "ASC"]],
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "setting payor details",
      data: getPagingData(allPayorDetails, page, perPage),
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: "Server error",
    });
  }
};
const payorSetupDetailsGet = async (req, res, next) => {
  try {
    const payorDetails = await AllPayorDetail.findOne({
      where: { id: req.body.edit_id, admin_id: req.user.id },
    });

    const treatmentFacilities = await TreatmentFacility.findAll({
      where: { admin_id: req.user.id },
    });

    for (const treatmentFacility of treatmentFacilities) {
      const checkTx = await PayorDetailsTxType.findOne({
        where: {
          admin_id: req.user.id,
          payor_id: payorDetails.payor_id,
          treatment_id: treatmentFacility.treatment_id,
        },
      });

      if (!checkTx) {
        await PayorDetailsTxType.create({
          admin_id: req.user.id,
          payor_id: payorDetails.payor_id,
          treatment_id: treatmentFacility.treatment_id,
          treatment_name: treatmentFacility.treatment_name,
          box_24j: "",
          id_qualifire: "",
        });
      }
    }
    const txTypes = await PayorDetailsTxType.findAll({
      where: { admin_id: req.user.id, payor_id: payorDetails.payor_id },
      order: [["treatment_name", "ASC"]],
    });

    res.status(200).json({
      success: true,
      message: "Payor setup details",
      payor_details: payorDetails,
      tx_types: txTypes,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: "Server error",
    });
  }
};
const payorSetupDetailsUpdate = async (req, res, next) => {
  console.log(req.body);
  try {
    const payor = await AllPayorDetail.findOne({
      where: { id: req.body.payor_up_id, admin_id: req.user.id },
    });
    if (payor) {
      payor.is_electronic = req.body.is_elec;
      payor.is_active = req.body.is_active;
      payor.box_17 = req.body.box_17;
      payor.day_pay_cpt = req.body.day_pay_cpt;

      if (req.body.insurance_type) {
        payor.insurance_type = req.body.insurance_type;
      }

      await payor.save();
    }

    if (req.body.edit_details_id) {
      for (let i = 0; i < req.body.edit_details_id.length; i++) {
        const update_data = await PayorDetailsTxType.findOne({
          where: { id: req.body.edit_details_id[i] },
        });

        if (update_data) {
          update_data.payor_id = payor.payor_id;
          update_data.box_24j = req.body.box_24j[i] || "";
          update_data.id_qualifire = req.body.id_qualifire[i] || "";
          await update_data.save();
        }
      }
    }
    res.status(200).send({ status: true, message: "Payor details updated successfully" });
  } catch (e) {
    console.error(e.message);
    // res.status(500).send({
    //   message: "Server error",
    // });
    res.json({ error: e.message });
  }
};

const payorSetupBox33Update = async (req, res, next) => {
  try {
    const payor = await AllPayorDetail.findOne({
      where: { id: req.body.payor_up_id, admin_id: req.user.id },
    });
    if (payor) {
      payor.facility_33 = req.body.facility_33;
      payor.cms1500_33address = req.body.cms1500_33address;
      payor.cms1500_33city = req.body.cms1500_33city;
      payor.cms1500_33state = req.body.cms1500_33state;
      payor.cms1500_33zip = req.body.cms1500_33zip;
      payor.cms_1500_33a = req.body.cms_1500_33a;
      payor.cms_1500_33b = req.body.cms_1500_33b;

      await payor.save();
      res.status(200).send({
        message: "Payor box 33 details updated successfully",
        data: payor,
      });
    } else {
      res.status(404).send({ message: "Payor not found" });
    }
  } catch (e) {
    console.error(e.message);
    // res.status(500).send({
    //   message: "Server error",
    // });

    res.json({
      error: e.message,
    });
  }
};
const payorSetupBox32Update = async (req, res, next) => {
  try {
    const payor = await AllPayorDetail.findOne({
      where: { id: req.body.payor_up_id, admin_id: req.user.id },
    });
    if (payor) {
      payor.facility_32 = req.body.facility_32;
      payor.cms1500_32address = req.body.cms1500_32address;
      payor.cms1500_32city = req.body.cms1500_32city;
      payor.cms1500_32state = req.body.cms1500_32state;
      payor.cms1500_32zip = req.body.cms1500_32zip;
      payor.cms_1500_32a = req.body.cms_1500_32a;
      payor.cms_1500_32b = req.body.cms_1500_32b;

      await payor.save();
    }

    res.status(200).send({ message: "Payor box 32 details updated successfully" });
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: "Server error",
    });
  }
};

const payorSetupUpdateTable = async (req, res, next) => {
  try {
    const data = req.body;
    console.log(data);

    if (data) {
      for (let i = 0; i < data.edit_id.length; i++) {
        const payorDetails = await AllPayorDetail.findOne({
          where: {
            id: data.edit_id[i],
            admin_id: req.user.id,
          },
        });
        //console.log(payorDetails);
        if (payorDetails) {
          payorDetails.is_electronic = data.is_electonic_data[i] || "";
          payorDetails.cms_1500_31 = data.cms_1500_31[i] || "";
          payorDetails.cms_1500_32a = data.cms_1500_32a[i] || "";
          payorDetails.cms_1500_32b = data.cms_1500_32b[i] || "";
          payorDetails.cms_1500_33a = data.cms_1500_33a[i] || "";
          payorDetails.cms_1500_33b = data.cms_1500_33b[i] || "";
          payorDetails.is_active = data.is_active_data[i] || 0;

          await payorDetails.save();
        }
      }
    }

    res.status(200).send({
      status: "success",
      message: "payor details updated",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: "Server error",
    });
  }
};

// ----------------------- SETTING TREATMENT -----------------------

// searchInsurance
const searchTreatment = async ({ body: { searchItem }, user: { id } }, res) => {
  try {
    const facilityInsuranceIds = await TreatmentFacility.findAll({
      where: { admin_id: id },
    });

    const facIds = facilityInsuranceIds.map(({ treatment_id }) => treatment_id);

    const allTreatments = await AllTreatment.findAll({
      where: {
        id: { [Op.notIn]: facIds },
        ...(searchItem && {
          treatment_name: { [Op.iLike]: `%${searchItem}%` },
        }),
      },
      order: [["treatment_name", "ASC"]],
    });
    res.json({
      status: "success",
      message: "facility setting get all insurance",
      all_Tretmanet: allTreatments,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const getAllTreatment = async (req, res, next) => {
  try {
    let treatIds = [];
    const facilityTreatment = await TreatmentFacility.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    await Promise.all(
      facilityTreatment.map(async (i) => {
        treatIds.push(i.treatment_id);
        return i + 1;
      })
    );

    const allTreatments = await AllTreatment.findAll({
      where: {
        id: {
          [Op.notIn]: treatIds,
        },
      },
    });

    res.json({
      status: "success",
      message: "Setting get all treatment",
      all_insurance: allTreatments,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
// searchSelectedTreatment
const searchSelectedTreatment = async ({ body: { searchItem }, user: { id } }, res) => {
  try {
    const allTreatments = await TreatmentFacility.findAll({
      where: {
        ...(searchItem && {
          treatment_name: { [Op.iLike]: `%${searchItem}%` },
        }),
      },
      order: [["treatment_name", "ASC"]],
    });
    res.json({
      status: "success",
      message: "facility setting get all insurance",
      all_Tretmanet: allTreatments,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const getFacilityTreatment = async (req, res, next) => {
  try {
    const facilityTreatment = await TreatmentFacility.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "Setting get facility treatment",
      data: facilityTreatment,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const addTreatmentToFacility = async (req, res, next) => {
  try {
    const { treatment_ids } = req.body;

    await Promise.all(
      treatment_ids.map(async (i) => {
        let findTreat = await AllTreatment.findOne({
          where: {
            id: i,
          },
        });

        const creatNewFac = await TreatmentFacility.create({
          admin_id: req.user.id,
          treatment_id: i,
          treatment_name: findTreat.treatment_name,
        });
      })
    );

    res.json({
      status: "success",
      message: "Setting treatment successfully added to facility",
      data: treatment_ids,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const removeFacilityTreatment = async (req, res, next) => {
  try {
    const { del_id } = req.body;
    for (const p of del_id) {
      const tretment = await TreatmentFacility.findOne({
        where: {
          admin_id: req.user.id,
          id: p,
        },
      });

      //If the treatment is used by any patient authorization then it will not be deleted
      const auth = await PatientAuthorization.count({
        where: {
          admin_id: req.user.id,
          treatment_type: tretment.treatment_name,
        },
      });

      await PayorDetailsTxType.destroy({
        where: {
          admin_id: req.user.id,
          treatment_id: tretment.treatment_id,
        },
      });

      if (auth <= 0) {
        await tretment.destroy();
      }
    }

    res.status(200).send({
      status: "success",
      message: "Setting treatment successfully removed from facility",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// ----------------------- SETTING SERVICE -----------------------
const listSettingService = async (req, res, next) => {
  try {
    const { page } = req.body;
    const { perPage, offset } = getPagination(page);

    const settingServices = await SettingService.findAndCountAll({
      where: {
        admin_id: req.user.id,
      },
      order: [["id", "ASC"]],
      include: "service_treatment",
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "Setting service list",
      data: getPagingData(settingServices, page, perPage),
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const addSettingService = async (req, res, next) => {
  try {
    const { treatment_id, service, description, duration, mileage, type } = req.body;

    // To insert the new record at the last position in the table we need to find the last record
    const lastRecord = await SettingService.findOne({
      order: [["id", "DESC"]],
    });

    const check_exists = await SettingService.findOne({
      where: {
        admin_id: req.user.id,
        facility_treatment_id: treatment_id,
        description: description,
      },
    });
    if (check_exists) {
      res.json({
        status: "error",
        message: "Setting service already exists",
      });
    } else {
      const new_service = await SettingService.create({
        id: lastRecord ? parseInt(lastRecord.id) + 1 : 1, // To insert the new record at the last position in the table
        admin_id: req.user.id,
        facility_treatment_id: treatment_id,
        service: service,
        description: description,
        duration: duration,
        mileage: mileage,
        type: type,
      });

      res.json({
        status: "success",
        message: "Setting service successfully created",
        new_service,
      });
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const singleSettingService = async (req, res, next) => {
  try {
    const { service_id } = req.body;

    const get_single_service = await SettingService.findOne({
      where: {
        admin_id: req.user.id,
        id: service_id,
      },
      include: "service_treatment",
    });

    res.json({
      status: "success",
      message: "Setting service single data",
      data: get_single_service,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const updateSettingService = async (req, res, next) => {
  try {
    const { service_id, treatment_id, service, description, duration, mileage, type } = req.body;

    const get_single_service = await SettingService.update(
      {
        facility_treatment_id: treatment_id,
        service: service,
        description: description,
        duration: duration,
        mileage: mileage,
        type: type,
      },
      {
        where: {
          admin_id: req.user.id,
          id: service_id,
        },
      }
    );

    res.json({
      status: "success",
      message: "Setting service successfully updated",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const deleteSettingService = async (req, res, next) => {
  try {
    const { service_id } = req.body;

    const get_single_service = await SettingService.destroy({
      where: {
        admin_id: req.user.id,
        id: service_id,
      },
    });

    res.json({
      status: "success",
      message: "Setting service successfully deleted",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
//=============================Settings/CPT code=============================
const listCptCode = async (req, res, next) => {
  try {
    const { page } = req.body;
    const { perPage, offset } = getPagination(page);

    const allCptCode = await SettingCptCode.findAndCountAll({
      where: {
        admin_id: req.user.id,
      },
      order: [["id", "ASC"]],
      include: "treatment_details",
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "Setting cpt code get all",
      data: getPagingData(allCptCode, page, perPage),
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const addCptCode = async (req, res, next) => {
  // console.log(req.body);
  try {
    const { treatment_id, cptcode } = req.body;

    const checkExist = await SettingCptCode.findOne({
      where: {
        admin_id: req.user.id,
        cpt_code: String(cptcode),
      },
    });

    if (checkExist) {
      res.json({
        status: "error",
        message: "Setting cpt code already exists",
      });
      return false;
    }

    // To insert the new record at the last position in the table we need to find the last record
    const lastRecord = await SettingCptCode.findOne({
      order: [["id", "DESC"]],
    });

    await SettingCptCode.create({
      id: lastRecord ? parseInt(lastRecord.id) + 1 : 1, // To insert the new record at the last position in the table
      admin_id: parseInt(req.user.id),
      cpt_id: parseInt(1),
      facility_treatment_id: parseInt(treatment_id),
      cpt_code: String(cptcode),
    });
    res.json({
      status: "success",
      message: "Setting cpt code successfully created",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const singleCptCode = async (req, res, next) => {
  try {
    const { cptid } = req.body;

    const singleCptCode = await SettingCptCode.findOne({
      where: {
        admin_id: req.user.id,
        id: cptid,
      },
    });

    res.json({
      status: "success",
      message: "Setting cpt code get single",
      data: singleCptCode,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const updateCptCode = async (req, res, next) => {
  try {
    const { cptid, treatment_id, cpt_code } = req.body;

    const getCpt = await SettingCptCode.findOne({
      where: {
        admin_id: req.user.id,
        id: cptid,
      },
    });

    getCpt.set({
      facility_treatment_id: treatment_id,
      cpt_code: cpt_code,
    });

    await getCpt.save();

    res.json({
      status: "success",
      message: "Setting cpt code successfully updated",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const deleteCptCode = async (req, res, next) => {
  // try {
  //   const { cptid } = req.body;

  //   const delCptCode = await SettingCptCode.destroy({
  //     where: {
  //       admin_id: req.user.id,
  //       id: cptid,
  //     },
  //   });

  //   res.json({
  //     status: "success",
  //     message: "Setting cpt code successfully deleted",
  //   });
  // }
  try {
    const { cptid } = req.body;

    const deleteCptCode = await SettingCptCode.findOne({
      where: {
        id: cptid,
        admin_id: req.user.id,
      },
    });

    if (deleteCptCode) {
      const checkPatientAuth = await PatientAuthorization.findOne({
        where: {
          cpt_code: deleteCptCode.cpt_id,
          admin_id: req.user.id,
        },
      });

      if (checkPatientAuth) {
        return res.status(200).json({
          status: "error",
          message: "Cpt Code Already Used",
        });
      } else {
        await deleteCptCode.destroy();
        return res.status(200).json({
          status: "success",
          message: "Cpt Code Deleted Successfully",
        });
      }
    } else {
      return res.redirect("back").with("alert", "Cpt Code Not Found");
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// =================== Add CPT Exclusion =======================
const availableCptCodes = async (req, res, next) => {
  try {
    let cptIds = [];
    let getExcludedCptCodes = await CptCodeExclusions.findAll({
      where: {
        admin_id: req.user.id,
      },
    });
    console.log(getExcludedCptCodes);
    // res.send(facilityInsuranceIds);
    await Promise.all(
      getExcludedCptCodes.map(async (i) => {
        cptIds.push(i.cpt_code_id);
        return i + 1;
      })
    );

    const allCptCodes = await SettingCptCode.findAll({
      /*
	SELECT
	...
	FROM "SettingCptCode"
	WHERE (
	  admin_id: req.user.id
	  AND
	  id: NOT IN [excluded cpt codes ids array]
	);
	*/
      where: {
        [Op.and]: [
          { admin_id: req.user.id },
          {
            id: {
              [Op.notIn]: cptIds,
            },
          },
        ],
      },
    });

    res.json({
      status: "success",
      message: "facility setting get all available cpt codes",
      all_insurance: allCptCodes,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
const getExcludedCptCodes = async (req, res, next) => {
  try {
    const getExcludedCptCodes = await CptCodeExclusions.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "facility setting get all excluded cpt codes",
      all_excluded_cpt: getExcludedCptCodes,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const addCptExclusion = async (req, res, next) => {
  try {
    const cptIds = req.body.cpt_ids;
    for (const cp of cptIds) {
      const code = await SettingCptCode.findOne({ where: { id: cp } });

      //CptCodeExclusions=>table a cpt code add kora
      await CptCodeExclusions.create({
        admin_id: req.user.id,
        cpt_code_id: cp,
        cpt_code: code.cpt_code,
      });
    }
    res.json({
      status: "success",
      message: "cpt code successfully added to excluded cpt codes",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const removeCptExclusion = async (req, res, next) => {
  try {
    const cptIds = req.body.cpt_ids;
    await Promise.all(
      cptIds?.map((cpt_id) => {
        return CptCodeExclusions.destroy({
          where: {
            [Op.and]: [{ admin_id: req.user.id }, { id: cpt_id }],
          },
        });
      })
    );

    res.json({
      status: "success",
      message: "cpt code successfully removed from exclusion",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

// =================== Add Service Sub Type =======================
const subActivityTreatmentBillableType = async (req, res, next) => {
  const { treatment_id } = req.body;
  try {
    const sub_act_bill_type = await SettingService.findAll({
      attributes: [[Sequelize.fn("DISTINCT", Sequelize.col("type")), "type"]],
      where: {
        facility_treatment_id: treatment_id,
      },
    });
    return res.status(200).json({
      status: "success",
      message: "sub activity treatment billable type",
      sub_act_bill_type,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const subActivityTreatmentServiceGet = async (req, res, next) => {
  const { treatment_id, bill_type } = req.body;
  try {
    const all_service_get = await SettingService.findAll({
      where: {
        facility_treatment_id: treatment_id,
        type: bill_type,
      },
      order: [["description", "ASC"]],
    });
    res.status(200).json({
      status: "success",
      message: "sub activity service get",
      all_service: all_service_get,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const subActivityGetData = async (req, res, next) => {
  try {
    const treatment_id = req.body.treatment_id;
    const bill_type = req.body.bill_type;
    const ser_id = req.body.ser_id;
    const admin_id = req.user.id;

    //raw query
    const query = `SELECT * FROM all_sub_activities WHERE admin_id IS NOT NULL AND admin_id=${admin_id} AND facility_treatment_id=${treatment_id} AND service_id=${ser_id} AND is_billable=${bill_type} ORDER BY id ASC`;

    const result = await AllSubActivity.sequelize.query(query, {
      type: AllSubActivity.sequelize.QueryTypes.SELECT,
    });

    res.status(200).json({
      status: "success",
      message: "sub activity data get",
      sub_activity_data: result,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const subActivitySetupSave = async (req, res, next) => {
  const { treatment_id, bill_type, ser_id, new_desc } = req.body;
  try {
    // To insert the new record at the last position in the table we need to find the last record
    const lastRecord = await AllSubActivity.findOne({
      order: [["id", "DESC"]],
    });

    const check = await AllSubActivity.findOne({
      where: {
        admin_id: req.user.id,
        service_id: ser_id,
        facility_treatment_id: treatment_id,
        sub_activity: new_desc,
      },
    });
    if (!check) {
      const newSubActivity = await AllSubActivity.create({
        id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
        admin_id: req.user.id,
        is_billable: bill_type,
        facility_treatment_id: treatment_id,
        service_id: ser_id,
        is_active: 1,
        sub_activity: new_desc,
      });

      res.status(200).json({
        status: "success",
        message: "sub activity setup save",
        newSubActivity,
      });
    } else {
      res.status(200).send({ message: "sub activity already exists" });
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const singleSubActivity = async (req, res, next) => {
  try {
    const singleSubType = await AllSubActivity.findOne({
      where: {
        admin_id: req.user.id,
        id: req.body.id,
      },
    });

    res.status(200).json({
      status: "success",
      message: "single sub activity",
      singleSubType,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const subActivityUpdate = async (req, res, next) => {
  try {
    const { edit_id, desc } = req.body;

    const single_act_update = await AllSubActivity.findOne({
      where: { id: edit_id, admin_id: req.user.id },
    });

    if (single_act_update) {
      single_act_update.sub_activity = desc;

      await single_act_update.save();

      return res.status(200).json({
        status: "success",
        message: "service Sub type updated successfully",
        data: single_act_update,
      });
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const subActivityStatusChange = async (req, res, next) => {
  try {
    const { id, status } = req.body;

    const data = await AllSubActivity.findOne({
      where: { id, admin_id: req.user.id },
    });

    if (data) {
      data.is_active = status;

      await data.save();

      res.status(200).send({
        status: "success",
        message: "service Sub type status changed successfully",
      });
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const subActivityDelete = async (req, res, next) => {
  try {
    const { id } = req.body;
    console.log(id);

    const single_act_delete = await AllSubActivity.findOne({
      where: { id, admin_id: req.user.id },
    });

    if (single_act_delete) {
      // checking needs to be done but the ClientAuthorizationActivities model is not created yet
      // const check = await ClientAuthorizationActivities.findOne({
      //   where: {
      //     activity_two: single_act_delete.sub_activity,
      //     admin_id: req.user.id,
      //   },
      //   attributes: ["id", "admin_id", "activity_two"],
      // });

      // if (check) {
      //   return res.status(200).send({
      //     status: "success",
      //     message: "already in use can't delete it",
      //   });
      // } else {
      //   await single_act_delete.destroy();
      // }
      await single_act_delete.destroy();

      return res.status(200).send({
        status: "success",
        message: "successfully deleted",
      });
    } else {
      return res.status(404).send({
        status: "failed",
        message: "Error while deleting",
      });
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

// =================== Add Staff Type =======================

const employeeGetAll = async (req, res, next) => {
  try {
    let assignedId = [];
    let selectedEmployeeIds = await EmployeeTypeAssign.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    await Promise.all(
      selectedEmployeeIds.map(async (i) => {
        assignedId.push(i.type_id);
        return i + 1;
      })
    );

    const getAllStaffType = await AllEmployeeTypes.findAll({
      where: {
        id: {
          [Op.notIn]: assignedId,
        },
      },
    });

    res.json({
      status: "success",
      message: "get all staff type",
      all_insurance: getAllStaffType,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const allSelectedEmployee = async (req, res, next) => {
  try {
    const selectedEmployees = await EmployeeTypeAssign.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.status(200).json({
      status: "success",
      message: "get all selected staff type",
      data: selectedEmployees,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const addEmployeeToFacilitySelected = async (req, res, next) => {
  try {
    const types = req.body.staffTypeIds;
    // Don't use for-each or map for async operations/loop
    for (let i = 0; i < types.length; i++) {
      let typeName = await AllEmployeeTypes.findOne({
        where: {
          id: types[i],
        },
      });
      const lastRecord = await EmployeeTypeAssign.findOne({
        order: [["id", "DESC"]],
      });
      console.log(lastRecord);
      await EmployeeTypeAssign.create({
        id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
        admin_id: req.user.id,
        type_id: typeName.id,
        type_name: typeName.type_name,
      });
    }
    res.json({
      status: "success",
      message: "staff type successfully added to facility",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const removeStaffFromFacility = async (req, res, next) => {
  try {
    const assign_type = req.body.assignIds;

    for (const typ of assign_type) {
      const del_assign_type = await EmployeeTypeAssign.findOne({
        where: {
          admin_id: req.user.id,
          id: typ,
        },
      });

      // Employee Modal is not created yet
      if (del_assign_type) {
        const sing_em = await Employee.count({
          where: {
            admin_id: req.user.id,
            credential_type: del_assign_type.id,
          },
        });

        //If the selected staff type is not assigned to any employee then delete it
        if (sing_em <= 0) {
          await del_assign_type.destroy();
        }
      }
    }
    res.status(200).send({
      status: "success",
      message: "staff type successfully removed from facility",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

// =================== Place of services =======================
const posListWithPagination = async (req, res, next) => {
  try {
    const { page } = req.body;
    const { perPage, offset } = getPagination(page);

    const allPos = await SettingPos.findAndCountAll({
      where: {
        admin_id: req.user.id,
      },
      order: [["id", "ASC"]],
      limit: perPage,
      offset,
    });

    res.status(200).json({
      status: "success",
      message: "Setting Place of Service list",
      data: getPagingData(allPos, page, perPage),
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const listPOS = async (req, res, next) => {
  try {
    const allPos = await SettingPos.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.status(200).json({
      status: "success",
      message: "Setting pos get all",
      pos: allPos,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const singlePOS = async (req, res, next) => {
  try {
    const { pos_id } = req.body;

    const singlePos = await SettingPos.findOne({
      where: {
        admin_id: req.user.id,
        id: pos_id,
      },
    });

    res.status(200).json({
      status: "success",
      message: "Setting Single Pos Data",
      data: singlePos,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const addPOS = async (req, res, next) => {
  try {
    const { pos_name, pos_code } = req.body;

    const checkExist = await SettingPos.findOne({
      where: {
        admin_id: req.user.id,
        pos_code: pos_code,
      },
    });

    if (checkExist) {
      res.status(200).json({
        status: "error",
        message: "Setting pos already exists",
      });
      return false;
    }

    const lastRecord = await SettingPos.findOne({
      order: [["id", "DESC"]],
    });
    await SettingPos.create({
      id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
      admin_id: parseInt(req.user.id),
      pos_code: pos_code,
      pos_name: pos_name,
    });
    res.status(200).json({
      status: "success",
      message: "Setting pos successfully created",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const updatePOS = async (req, res, next) => {
  try {
    const { pos_id, pos_name, pos_code } = req.body;

    const getPos = await SettingPos.findOne({
      where: {
        admin_id: req.user.id,
        id: pos_id,
      },
    });

    getPos.set({
      pos_name: pos_name,
      pos_code: pos_code,
    });

    await getPos.save();

    res.status(200).json({
      status: "success",
      message: "Setting pos successfully updated",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: "Server error",
    });
  }
};

const deletePOS = async (req, res, next) => {
  try {
    const { pos_id } = req.body;

    const delPos = await SettingPos.destroy({
      where: {
        admin_id: req.user.id,
        id: pos_id,
      },
    });

    res.json({
      status: "success",
      message: "Setting pos successfully deleted",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
// =================== Pay Periods =======================
const allPayperiods = async (req, res, next) => {
  try {
    const { page } = req.body;
    const { perPage, offset } = getPagination(page);

    const allPayPeriod = await PayPeriod.findAndCountAll({
      where: {
        admin_id: req.user.id,
      },
      order: [["id", "ASC"]],
      limit: perPage,
      offset,
    });

    res.status(200).json({
      status: "success",
      message: "Setting Pay Period List",
      listPayPeriods: getPagingData(allPayPeriod, page, perPage),
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const payPeriodSave = async (req, res, next) => {
  try {
    const admin_id = req.user.id;
    const { year, period_length, end_date, week_day_name, check_date, time_sheet } = req.body;

    const check = await PayPeriod.findOne({
      where: {
        admin_id: admin_id,
        end_date: {
          [Op.between]: [`${req.body.year}-01-01`, `${req.body.year}-12-31`],
        },
      },
      order: [["end_date", "DESC"]],
    });

    // let start_date;
    // if (check) {
    //   start_date = check.end_date;
    // } else {
    //   start_date = `${req.body.year}-01-01`;
    // }
    // console.log("start_date", start_date);
    let start_date;
    if (check) {
      start_date = moment(check.end_date).format("YYYY-MM-DD");
    } else {
      start_date = moment(`${req.body.year}-01-01`).format("YYYY-MM-DD");
    }

    if (req.body.period_length == 1) {
      const end_date = moment(req.body.end_date).format("YYYY-MM-DD");

      let start = new Date(start_date);
      let end = new Date(end_date);
      console.log(start);

      while (start <= end) {
        const time_stamp = moment(start).valueOf();
        const date_time_data = moment(time_stamp).format("YYYY-MM-DD");
        const week = moment(time_stamp).format("dddd");
        console.log("tell me the ", date_time_data);

        const last_end_date = moment(date_time_data).add(6, "days").format("YYYY-MM-DD"); //6 silo

        console.log("last_end_date ", last_end_date);

        if (end_date <= date_time_data) {
          return res.status(200).json({ message: "Pay Period Successfully Created" });
        }

        if (last_end_date <= end_date) {
          if (week.toLowerCase() === req.body.week_day_name.toLowerCase()) {
            const check_date = await checkDateFunction(moment(last_end_date).format("YYYY-MM-DD"), req.body.check_date);

            const s_date = moment(date_time_data).add(1, "days").format("YYYY-MM-DD");

            const lastRecord = await PayPeriod.findOne({
              order: [["id", "DESC"]],
            });
            const new_pay_period = await PayPeriod.create({
              id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
              admin_id: admin_id,
              period_length: req.body.period_length,
              year: req.body.year,
              start_date: s_date,
              end_date: last_end_date,
              show_start_date: new Date(time_stamp).toLocaleDateString("en-US"),
              show_end_date: moment(date_time_data).add(6, "days").format("MM/DD/YYYY"),
              check_date: check_date,
              time_sheet: req.body.time_sheet,
              time_sheet_date:
                req.body.time_sheet >= 1
                  ? moment(last_end_date).add(req.body.time_sheet, "days").format("YYYY-MM-DD")
                  : moment(last_end_date).format("YYYY-MM-DD"),
              week_day_name: week,
            });
            start.setDate(start.getDate() + 1);
          } else {
            start.setDate(start.getDate() + 1);
          }
        } else {
          start.setDate(start.getDate() + 1);
        }
      }
      return res.status(200).json({ message: "Pay Period Successfully Created" });
    } else if (req.body.period_length === 2) {
      const end_date = moment(req.body.end_date);

      let start = moment(start_date);
      while (start <= end_date) {
        const time_stamp = start.unix();
        const day = start.date();
        const week = start.format("dddd");
        const date_time_data = start.format("YYYY-MM-DD");
        const last_end_date = moment(date_time_data).add(14, "days");

        if (end_date <= start) {
          return res.status(200).json({ message: "Pay Period Successfully Created" });
        }

        if (day === 1) {
          const s_date = await firstDate(date_time_data, req.body.week_day_name);
          const check_date = await checkDateFunction(last_end_date.format("YYYY-MM-DD"), req.body.check_date);

          const new_pay_period = await PayPeriod.create({
            admin_id,
            period_length,
            year,
            start_date: s_date,
            end_date: last_end_date.format("YYYY-MM-DD"),
            show_start_date: date_time_data,
            show_end_date: last_end_date.format("YYYY-MM-DD"),
            check_date: check_date,
            time_sheet,
            time_sheet_date: time_sheet >= 1 ? moment(last_end_date).add(time_sheet, "days").toDate() : last_end_date.toDate(),
            week_day_name,
          });

          start.add(14, "days");
        } else if (day === 15) {
          const date_time_data_1 = moment(time_stamp * 1000).format("YYYY-MM-DD");
          const last_date_mon1 = moment(date_time_data_1).endOf("month");
          const last_date_mon2 = last_date_mon1.format("YYYY-MM-DD");

          const check_last_day_exists = await PayPeriod.findOne({
            where: {
              start_date: date_time_data_1,
              end_date: last_date_mon2,
              admin_id,
            },
          });
          const check_date = moment(last_date_mon2).diff(moment(), "days") >= 3 ? moment().format("YYYY-MM-DD") : last_date_mon2;

          const s_date = await firstDate(date_time_data_1, req.body.week_day_name);

          const new_pay_period = await PayPeriod.create({
            admin_id,
            period_length: req.body.period_length,
            year: req.body.year,
            start_date: s_date,
            end_date: last_date_mon2,
            show_start_date: moment(time_stamp * 1000).format("MM/DD/YYYY"),
            show_end_date: moment(last_date_mon2).format("MM/DD/YYYY"),
            check_date: check_date,
            time_sheet: req.body.time_sheet,
            time_sheet_date: moment(last_date_mon2).add(req.body.time_sheet, "days").format("YYYY-MM-DD"),
            week_day_name: req.body.week_day_name,
          });

          start.add(1, "day");
        } else {
          start.add(1, "day");
        }
      }
      return res.status(200).json({ message: "Pay Period Successfully Created" });
    } else if (req.body.period_length === 3) {
      const end_date = moment(req.body.end_date).format("YYYY-MM-DD");
      let start = moment(start_date);
      let end = moment(end_date);
      while (start <= end) {
        const time_stamp = moment(start).unix();
        const date_time_data_3 = moment.unix(time_stamp).format("YYYY-MM-DD");
        const week = moment.unix(time_stamp).format("dddd");

        if (end_date <= date_time_data_3) {
          return res.status(200).json({ message: "Pay Period Already Exists" });
        }

        const first_date = moment(date_time_data_3).startOf("month");
        const first_date_get = first_date.format("YYYY-MM-DD");

        const last_date = moment(date_time_data_3).endOf("month");
        const last_date_get = last_date.format("YYYY-MM-DD");

        console.log(last_date_get, first_date_get);
        const check_last_day_exists = await PayPeriod.findOne({
          where: {
            start_date: first_date_get,
            end_date: last_date_get,
            admin_id: req.user.id,
          },
        });
        console.log("check_last_day_exists", check_last_day_exists);
        if (check_last_day_exists) {
          return res.status(400).json({ message: "Pay Period Already Exists" });
        }

        const check_date = await checkDateFunction(moment(last_date_get).format("YYYY-MM-DD"), req.body.check_date);
        const s_date = await firstDate(first_date_get, req.body.week_day_name);
        const lastRecord = await PayPeriod.findOne({
          order: [["id", "DESC"]],
        });

        const new_pay_period = await PayPeriod.create({
          id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
          admin_id: req.user.id,
          period_length: req.body.period_length,
          year: req.body.year,
          start_date: s_date,
          end_date: last_date_get,
          show_start_date: moment(first_date_get).format("MM/DD/YYYY"),
          show_end_date: moment(last_date_get).format("MM/DD/YYYY"),
          check_date: check_date,
          time_sheet: req.body.time_sheet,
          time_sheet_date:
            req.body.time_sheet >= 1 ? moment(last_date_get).add(req.body.time_sheet, "days").format("YYYY-MM-DD") : moment(last_date_get).format("YYYY-MM-DD"),
          week_day_name: req.body.week_day_name,
        });

        start = start.add(1, "month");
      }
      return res.status(200).json({ message: "Pay Period Successfully Created" });
    } else if (req.body.period_length === 5) {
      const end_date_iso = moment(req.body.end_date).format("YYYY-MM-DD");
      let start = new Date(start_date);
      let end = new Date(end_date_iso);

      while (start <= end) {
        const time_stamp = start.getTime();
        const day = start.getDate();
        const dateTimeData = moment(start).format("YYYY-MM-DD");
        const last_end_date = moment(dateTimeData).add(14, "days").format("YYYY-MM-DD");

        if (end_date_iso <= dateTimeData) {
          return res.status(200).json("success", "Pay Period Successfully Created");
        }

        if (day === 5) {
          console.log("enter here");
          const check_date_new = await checkDateFunction(moment(last_end_date).format("YYYY-MM-DD"), req.body.check_date);
          console.log("check_date_new", check_date_new);
          const s_date = await firstDate(dateTimeData, req.body.week_day_name);

          const new_pay_period = await PayPeriod.create({
            admin_id,
            period_length: req.body.period_length,
            year: req.body.year,
            start_date: s_date,
            end_date: moment(last_end_date).format("YYYY-MM-DD"),
            show_start_date: dateTimeData,
            show_end_date: moment(last_end_date).add(14, "days").format("YYYY-MM-DD"),
            check_date: check_date_new,
            time_sheet: req.body.time_sheet,
            time_sheet_date:
              req.body.time_sheet > 1 ? moment(last_end_date).add(time_sheet, "days").format("YYYY-MM-DD") : moment(last_end_date).format("YYYY-MM-DD"),
            week_day_name: req.body.week_day_name,
          });
          start.setDate(start.getDate() + 14);
        } else if (day === 20) {
          let date_time_data_1 = dateTimeData;

          let last_date_mon1 = new Date(date_time_data_1);
          last_date_mon1.setMonth(last_date_mon1.getMonth() + 1);
          last_date_mon1.setDate(0);
          let last_date_mon2 = moment(last_date_mon1).format("YYYY-MM-DD");

          let check_date = await checkDateFunction(last_date_mon2, req.body.check_date);

          let s_date = await firstDate(dateTimeData, req.body.week_day_name);

          let new_pay_period = await PayPeriod.create({
            admin_id,
            period_length: req.body.period_length,
            year: req.body.year,
            start_date: s_date,
            end_date: last_date_mon2,
            show_start_date: dateTimeData,
            show_end_date: new Date(last_date_mon2).toLocaleDateString(),
            check_date: check_date,
            time_sheet: req.body.time_sheet,
            time_sheet_date:
              req.body.time_sheet > 1
                ? moment(last_date_mon2).add(req.body.time_sheet, "days").format("YYYY-MM-DD")
                : moment(last_date_mon2).format("YYYY-MM-DD"),
            week_day_name: req.body.week_day_name,
          });

          start.setDate(start.getDate() + 1);
        } else {
          start.setDate(start.getDate() + 1);
        }
      }
      return res.status(200).json({
        message: "Pay Period Successfully Created",
        status: "success",
      });
    } else if (req.body.period_length === 6) {
      const end_date = moment(req.body.end_date).format("YYYY-MM-DD");
      let start = moment(start_date);
      const end = moment(end_date);

      while (start <= end) {
        const time_stamp = moment(start.format("YYYY-MM-DDTHH:mm:ss.SSSZ")).unix();
        const day = moment(time_stamp * 1000).format("DD");
        const date_time_data = moment(time_stamp * 1000).format("YYYY-MM-DD");
        const last_end_date = moment(date_time_data).add(14, "days").format("YYYY-MM-DD");

        if (end_date <= date_time_data) {
          return res.status(200).json({
            success: true,
            message: "Pay Period Successfully Created",
          });
        }
        if (day === "15") {
          const check_date_res = await checkDateFunction(moment(last_end_date).format("YYYY-MM-DD"), req.body.week_day_name);

          const s_date = await firstDate(date_time_data, week_day_name);

          const new_pay_period = await PayPeriod.create({
            admin_id,
            period_length,
            year,
            start_date: s_date,
            end_date: last_end_date,
            show_start_date: date_time_data,
            show_end_date: new Date(last_end_date).toISOString().split("T")[0],
            check_date: check_date_res,
            time_sheet,
            time_sheet_date: time_sheet > 1 ? moment(last_end_date).add(time_sheet, "days").toDate() : moment(last_end_date).toDate(),
            week_day_name,
          });

          start.add(15, "day");
        } else if (day === "30") {
          const date_time_data_1 = moment(time_stamp * 1000).format("YYYY-MM-DD");
          const last_date_mon1 = moment(date_time_data_1);
          last_date_mon1.endOf("month");
          const last_date_mon2 = last_date_mon1.format("YYYY-MM-DD");
          const check_date = await checkDateFunction(moment(last_date_mon2).format("YYYY-MM-DD"), req.body.check_date);
          const s_date = await firstDate(date_time_data, req.body.week_day_name);

          await PayPeriod.create({
            admin_id,
            period_length: req.body.period_length,
            year: req.body.year,
            start_date: s_date,
            end_date: last_date_mon2,
            show_start_date: moment.unix(time_stamp).format("MM/DD/YYYY"),
            show_end_date: moment(last_date_mon2).format("MM/DD/YYYY"),
            check_date: check_date,
            time_sheet: req.body.time_sheet,
            time_sheet_date:
              req.body.time_sheet > 1
                ? moment(last_date_mon2).add(req.body.time_sheet, "days").format("YYYY-MM-DD")
                : moment(last_date_mon2).format("YYYY-MM-DD"),
            week_day_name: req.body.week_day_name,
          });
          start.add(1, "day");
        } else {
          start.add(1, "day");
        }
      }

      return res.status(200).json({
        success: true,
        message: "Pay Period Successfully Created",
      });
    } else {
      res.status(500).json({
        status: "error",
        message: "period length is not valid",
      });
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send(e);
  }
};

const payPeriodUpdate = async (req, res, next) => {
  try {
    const ts_date = moment(req.body.end_date).add(req.body.time_sheet, "days").format("YYYY-MM-DD");

    const update_pay_period = await PayPeriod.findOne({
      where: {
        admin_id: req.user.id,
        id: req.body.period_edit_id,
      },
    });
    update_pay_period.start_date = req.body.start_date;
    update_pay_period.end_date = req.body.end_date;
    update_pay_period.check_date = req.body.check_date;
    update_pay_period.time_sheet = req.body.time_sheet;
    update_pay_period.time_sheet_date = ts_date;
    await update_pay_period.save();

    res.status(200).json({
      status: "success",
      message: "update pay period successfully",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const deletePayPeriod = async (req, res, next) => {
  try {
    const delete_pay_period = await PayPeriod.findOne({
      where: {
        id: req.body.id,
        admin_id: req.user.id,
      },
    });

    await delete_pay_period.destroy();

    res.status(200).json({
      status: "success",
      message: "successfully delete pay period",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const bulkDeletePayPeriod = async (req, res, next) => {
  try {
    const arr = req.body.ids;
    console.log(arr);

    while (arr.length > 0) {
      const delete_pay_period = await PayPeriod.findOne({
        where: {
          id: arr.pop(),
          admin_id: req.user.id,
        },
      });

      await delete_pay_period.destroy();
    }

    res.status(200).json({
      status: "success",
      message: "successfully delete pay periods",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
// =================== Vendor Number Setup =======================

const vendorNumber = async (req, res, next) => {
  try {
    const service = await SettingService.findAll({
      where: { admin_id: req.user.id },
    });

    const tx_types = await TreatmentFacility.findAll({
      where: { admin_id: req.user.id },
    });

    const payors = await PayorFacility.findAll({
      where: { admin_id: req.user.id, is_regional_center: 1 },
    });
    res.status(200).json({
      status: "success",
      message: "Setting Vendor Number",
      data: {
        service: service,
        tx_types: tx_types,
        payors: payors,
      },
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const vendorNumberRegionalCenter = async (req, res, next) => {
  try {
    const payorFac = await PayorFacilityDetails.findAll({
      where: { is_regional_center: 1 },
    });

    console.log(payorFac);

    const payorFacIds = payorFac.map((p) => p.id);
    const getAllPay = await PayorFacility.findAll({
      where: {
        payor_id: { [Sequelize.Op.in]: payorFacIds },
        admin_id: req.user.id,
      },
    });

    return res.status(200).json({
      status: "success",
      message: "setting vendor number region center",
      data: getAllPay,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const getVendorNumberList = async (req, res, next) => {
  try {
    const { page, tx_id, region_id } = req.body;
    const { perPage, offset } = getPagination(page);

    if (tx_id && !region_id) {
      const allVendorNumber = await VendorNumber.findAndCountAll({
        where: {
          admin_id: req.user.id,
          treatment_id: tx_id,
        },
        order: [["id", "ASC"]],
        limit: perPage,
        offset,
      });

      return res.status(200).json({
        status: "success",
        message: "setting vendor number list",
        data: getPagingData(allVendorNumber, page, perPage),
      });
    }
    if (!tx_id && region_id) {
      const allVendorNumber = await VendorNumber.findAndCountAll({
        where: {
          admin_id: req.user.id,
          regional_center_id: region_id,
        },
        order: [["id", "ASC"]],
        limit: perPage,
        offset,
      });

      return res.status(200).json({
        status: "success",
        message: "setting vendor number list",
        data: getPagingData(allVendorNumber, page, perPage),
      });
    }
    if (tx_id && region_id) {
      const allVendorNumber = await VendorNumber.findAndCountAll({
        where: {
          admin_id: req.user.id,
          treatment_id: tx_id,
          regional_center_id: region_id,
        },
        order: [["id", "ASC"]],
        limit: perPage,
        offset,
      });

      return res.status(200).json({
        status: "success",
        message: "setting vendor number list",
        data: getPagingData(allVendorNumber, page, perPage),
      });
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const addVendorNumber = async (req, res, next) => {
  try {
    const { vendor_no, service_code, service_id, treatment_id, regional_center_id } = req.body;

    // To insert the new record at the last position in the table we need to find the last record
    const lastRecord = await VendorNumber.findOne({
      order: [["id", "DESC"]],
    });

    const newVendor = await VendorNumber.create({
      id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
      admin_id: req.user.id,
      service_id: service_id,
      treatment_id: treatment_id,
      regional_center_id: regional_center_id,
      vendor_no: vendor_no,
      service_code: service_code,
    });
    res.status(200).json({
      status: "success",
      message: "Setting Vendor Number successfully created",
      newVendor,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: e.message,
    });
  }
};

const vendorNumberUpdate = async (req, res, next) => {
  try {
    const { edit_vendor_id, vendor_no, service_code, service_id, treatment_id, regional_center_id } = req.body;
    const getVendor = await VendorNumber.findOne({
      where: {
        admin_id: req.user.id,
        id: edit_vendor_id,
      },
    });

    getVendor.set({
      service_id,
      treatment_id,
      regional_center_id,
      vendor_no,
      service_code,
    });

    await getVendor.save();

    res.json({
      status: "success",
      message: "Setting vendor number successfully updated",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: e.message,
    });
  }
};

const deleteVendorNumber = async (req, res, next) => {
  try {
    const { vendor_id } = req.body;
    await VendorNumber.destroy({
      where: {
        admin_id: req.user.id,
        id: vendor_id,
      },
    });

    res.json({
      status: "success",
      message: "Setting vendor number successfully deleted",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("server error");
  }
};

// =================== Holiday Setup ===========================

const holidaySetup = async (req, res, next) => {
  try {
    const holidaySetups = await HolidaySetup.findAll({
      where: {
        admin_id: req.user.id,
      },
      order: [["holiday_date", "ASC"]],
    });

    const jan1 = await HolidaySetup.findOne({
      where: {
        holiday_name: "jan1",
        admin_id: req.user.id,
      },
    });

    const jan17 = await HolidaySetup.findOne({
      where: {
        holiday_name: "jan17",
        admin_id: req.user.id,
      },
    });

    const feb21 = await HolidaySetup.findOne({
      where: {
        holiday_name: "feb21",
        admin_id: req.user.id,
      },
    });

    const may30 = await HolidaySetup.findOne({
      where: {
        holiday_name: "may30",
        admin_id: req.user.id,
      },
    });

    const jun20 = await HolidaySetup.findOne({
      where: {
        holiday_name: "jun20",
        admin_id: req.user.id,
      },
    });

    const july4 = await HolidaySetup.findOne({
      where: {
        holiday_name: "july4",
        admin_id: req.user.id,
      },
    });

    const sep5 = await HolidaySetup.findOne({
      where: {
        holiday_name: "sep5",
        admin_id: req.user.id,
      },
    });

    const oct10 = await HolidaySetup.findOne({
      where: {
        holiday_name: "oct10",
        admin_id: req.user.id,
      },
    });

    const nov11 = await HolidaySetup.findOne({
      where: {
        holiday_name: "nov11",
        admin_id: req.user.id,
      },
    });

    const nov24 = await HolidaySetup.findOne({
      where: {
        holiday_name: "nov24",
        admin_id: req.user.id,
      },
    });

    const dec25 = await HolidaySetup.findOne({
      where: {
        holiday_name: "dec25",
        admin_id: req.user.id,
      },
    });

    res.status(200).json({
      status: "success",
      message: "Holiday setup successfully fetched",
      holidaySetups,
      jan1,
      jan17,
      feb21,
      may30,
      jun20,
      july4,
      sep5,
      oct10,
      nov11,
      nov24,
      dec25,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: "server error",
    });
  }
};
const holidaySetupSave = async (req, res, next) => {
  try {
    const h_date = new Date(req.body.holiday_date).toISOString().slice(0, 10);
    const check_date = await HolidaySetup.findOne({
      where: { holiday_date: h_date, admin_id: req.user.id },
    });
    if (check_date) {
      return res.status(200).json({
        status: "success",
        message: "Holiday already exists",
      });
    }
    const newHoliday = await HolidaySetup.create({
      admin_id: req.user.id,
      holiday_date: h_date,
      holiday_name: req.body.holiday_name,
      description: req.body.description,
    });

    res.status(200).json({
      status: "success",
      message: "Holiday successfully created",
      newHoliday,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("server error");
  }
};

const federalHolidaySave = async (req, res, next) => {
  try {
    const { jan_1, jan_17, feb_21, may_30, jun_20, july_4, sep_5, oct_10 } = req.body;
    const adminId = req.user.id;

    if (jan_1) {
      const date = new Date().getFullYear() + "-01-01";
      console.log(date);
      const checkJan1 = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (!checkJan1) {
        await HolidaySetup.create({
          admin_id: adminId,
          holiday_date: date,
          description: "New Year's Day (January 1)",
          is_fed: 1,
          holiday_name: "jan1",
        });
      }
    } else {
      const date = new Date().getFullYear() + "-01-01";
      const holi = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (holi) {
        await holi.destroy();
      }
    }

    if (jan_17) {
      const dateJan17 = new Date().getFullYear() + "-01-17";
      const checkJan17 = await HolidaySetup.findOne({
        where: { holiday_date: dateJan17, admin_id: adminId },
      });

      if (!checkJan17) {
        await HolidaySetup.create({
          admin_id: adminId,
          holiday_date: dateJan17,
          description: "Martin Luther King Jr. Day (January 17)",
          is_fed: 1,
          holiday_name: "jan17",
        });
      }
    } else {
      const date = new Date().getFullYear() + "-01-17";
      const holi = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (holi) {
        await holi.destroy();
      }
    }

    if (feb_21) {
      const dateFeb21 = new Date().getFullYear() + "-02-21";
      const checkFeb21 = await HolidaySetup.findOne({
        where: { holiday_date: dateFeb21, admin_id: adminId },
      });

      if (!checkFeb21) {
        await HolidaySetup.create({
          admin_id: adminId,
          holiday_date: dateFeb21,
          description: "George Washington's Birthday (February 21)",
          is_fed: 1,
          holiday_name: "feb21",
        });
      }
    } else {
      const date = new Date().getFullYear() + "-02-21";
      const holi = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (holi) {
        await holi.destroy();
      }
    }

    if (may_30) {
      const dateMay30 = new Date().getFullYear() + "-05-30";
      const checkMay30 = await HolidaySetup.findOne({
        where: { holiday_date: dateMay30, admin_id: adminId },
      });

      if (!checkMay30) {
        await HolidaySetup.create({
          admin_id: adminId,
          holiday_date: dateMay30,
          description: "Memorial Day (May 30)",
          is_fed: 1,
          holiday_name: "may30",
        });
      }
    } else {
      const date = new Date().getFullYear() + "-05-30";
      const holi = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (holi) {
        await holi.destroy();
      }
    }

    if (jun_20) {
      const dateJun20 = new Date().getFullYear() + "-06-20";
      const checkJun20 = await HolidaySetup.findOne({
        where: { holiday_date: dateJun20, admin_id: adminId },
      });

      if (!checkJun20) {
        await HolidaySetup.create({
          admin_id: adminId,
          holiday_date: dateJun20,
          description: "Juneteenth (June 20)",
          is_fed: 1,
          holiday_name: "jun20",
        });
      }
    } else {
      const date = new Date().getFullYear() + "-06-20";
      const holi = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (holi) {
        await holi.destroy();
      }
    }

    if (july_4) {
      const dateJuly4 = new Date().getFullYear() + "-07-04";
      const checkJuly4 = await HolidaySetup.findOne({
        where: { holiday_date: dateJuly4, admin_id: adminId },
      });

      if (!checkJuly4) {
        await HolidaySetup.create({
          admin_id: adminId,
          holiday_date: dateJuly4,
          description: "Independence Day (July 4)",
          is_fed: 1,
          holiday_name: "july4",
        });
      }
    } else {
      const date = new Date().getFullYear() + "-07-04";
      const holi = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (holi) {
        await holi.destroy();
      }
    }

    if (sep_5) {
      const dateSep5 = new Date().getFullYear() + "-09-05";
      const checkSep5 = await HolidaySetup.findOne({
        where: { holiday_date: dateSep5, admin_id: adminId },
      });

      if (!checkSep5) {
        await HolidaySetup.create({
          admin_id: adminId,
          holiday_date: dateSep5,
          description: "Labor Day (September 5)",
          is_fed: 1,
          holiday_name: "sep5",
        });
      }
    } else {
      const date = new Date().getFullYear() + "-09-05";
      const holi = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (holi) {
        await holi.destroy();
      }
    }

    if (oct_10) {
      const dateOct10 = new Date().getFullYear() + "-10-10";
      const checkOct10 = await HolidaySetup.findOne({
        where: { holiday_date: dateOct10, admin_id: adminId },
      });

      if (!checkOct10) {
        await HolidaySetup.create({
          admin_id: adminId,
          holiday_date: dateOct10,
          description: "Columbus Day (October 10)",
          is_fed: 1,
          holiday_name: "oct10",
        });
      }
    } else {
      const date = new Date().getFullYear() + "-10-10";
      const holi = await HolidaySetup.findOne({
        where: { holiday_date: date, admin_id: adminId },
      });

      if (holi) {
        await holi.destroy();
      }
    }

    return res.status(200).json({
      status: "success",
      message: "Federal holiday successfully updated",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("server error");
  }
};

const holidayDelete = async (req, res, next) => {
  try {
    const { holiday_id } = req.body;
    const delete_holiday_setup = await HolidaySetup.findOne({
      where: {
        id: holiday_id,
        admin_id: req.user.id,
      },
    });
    if (delete_holiday_setup) {
      await delete_holiday_setup.destroy();
      return res.status(200).send({
        status: "success",
        message: "Holiday Setup successfully deleted",
      });
    } else {
      return res.status(200).send({
        status: "success",
        message: "Holiday Setup not found",
      });
    }
  } catch (e) {
    console.error(e.message);
    res.status(500).send({
      message: "server error",
    });
  }
};
// =================== referring provider =======================
const referringProviderWithPagination = async (req, res, next) => {
  try {
    const { page } = req.body;
    const { perPage, offset } = getPagination(page);

    const allReferringProviders = await ReferringProvider.findAndCountAll({
      where: {
        admin_id: req.user.id,
      },
      order: [["id", "DESC"]],
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "Setting Referring Provider List",
      referringProvider: getPagingData(allReferringProviders, page, perPage),
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
const referringProviderList = async (req, res, next) => {
  try {
    const allReferringProviders = await ReferringProvider.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "Setting Referring Provider List",
      data: allReferringProviders,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const addReferringProvider = async (req, res, next) => {
  try {
    const { provider_name, provider_last_name, npi, upin, id_qual } = req.body;

    await ReferringProvider.create({
      admin_id: req.user.id,
      provider_name,
      provider_last_name,
      npi,
      upin,
      id_qual,
    });
    res.json({
      status: "success",
      message: "Setting referring provider successfully created",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const singleReferringProvider = async (req, res, next) => {
  try {
    const { referring_id } = req.body;

    const singleReferringProvider = await ReferringProvider.findOne({
      where: {
        admin_id: req.user.id,
        id: referring_id,
      },
    });

    res.json({
      status: "success",
      message: "Setting single referring provider Data",
      data: singleReferringProvider,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const updateReferringProvider = async (req, res, next) => {
  try {
    const { referring_id, provider_name, provider_last_name, npi, upin, id_qual } = req.body;

    const getReferringProvider = await ReferringProvider.findOne({
      where: {
        admin_id: req.user.id,
        id: referring_id,
      },
    });

    getReferringProvider.set({
      provider_name,
      provider_last_name,
      npi,
      upin,
      id_qual,
    });

    await getReferringProvider.save();

    res.json({
      status: "success",
      message: "Setting referring provider successfully updated",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const deleteReferringProvider = async (req, res, next) => {
  try {
    const { referring_id } = req.body;

    const delPos = await ReferringProvider.destroy({
      where: {
        admin_id: req.user.id,
        id: referring_id,
      },
    });

    res.json({
      status: "success",
      message: "Setting referring provider successfully deleted",
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

export default {
  getNameLocation,
  updateNameLocation,
  getAllInsurance,
  getFacilitySelectedInsurance,
  addInsuranceToFacility,
  deleteInsuranceFacility,
  updateInsuranceFacility,
  allInsuranceDetails,
  facilitySelectedInsuranceDetails,
  payorSetup,
  payorSetupDetailsGet,
  payorSetupDetailsUpdate,
  payorSetupBox33Update,
  payorSetupBox32Update,
  payorSetupUpdateTable,
  getAllTreatment,
  searchTreatment,
  searchSelectedTreatment,
  getFacilityTreatment,
  addTreatmentToFacility,
  removeFacilityTreatment,
  listSettingService,
  addSettingService,
  singleSettingService,
  updateSettingService,
  deleteSettingService,
  listCptCode,
  addCptCode,
  searchInsurance,
  facilitySearchInsurance,
  singleCptCode,
  updateCptCode,
  deleteCptCode,
  availableCptCodes,
  getExcludedCptCodes,
  addCptExclusion,
  removeCptExclusion,
  subActivityTreatmentBillableType,
  subActivityTreatmentServiceGet,
  subActivityGetData,
  subActivitySetupSave,
  singleSubActivity,
  subActivityUpdate,
  subActivityStatusChange,
  subActivityDelete,
  employeeGetAll,
  allSelectedEmployee,
  addEmployeeToFacilitySelected,
  removeStaffFromFacility,
  listPOS,
  posListWithPagination,
  singlePOS,
  addPOS,
  updatePOS,
  deletePOS,
  allPayperiods,
  payPeriodSave,
  payPeriodUpdate,
  deletePayPeriod,
  bulkDeletePayPeriod,
  vendorNumber,
  vendorNumberRegionalCenter,
  getVendorNumberList,
  addVendorNumber,
  vendorNumberUpdate,
  deleteVendorNumber,
  referringProviderWithPagination,
  referringProviderList,
  addReferringProvider,
  deleteReferringProvider,
  updateReferringProvider,
  singleReferringProvider,
  holidaySetup,
  federalHolidaySave,
  holidaySetupSave,
  holidayDelete,
};
