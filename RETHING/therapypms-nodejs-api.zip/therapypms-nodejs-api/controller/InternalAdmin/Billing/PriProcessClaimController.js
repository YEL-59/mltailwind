import { Op, json } from "sequelize";
import { Sequelize, DataTypes } from "sequelize";

import Appointment from "../../../models/Appointment/Appointment.js";
import SettingNameLocation from "../../../models/Setting/SettingNameLocation.js";

import { getPagination, getPagingData } from "../../../helpers/pagination.js";

import {
  getAppointmentData,
  processWithoutComboCode,
  processWithComboCode,
  getPayorNames,
  updateStatus,
  updateStatusClarificationPending,
  retractSession,
  nonBillableServ,
  update24jProvider,
  updateIdQualifires,
  updateModifires,
  updateChargeAmount,
  addCptCode,
  updateTxProvider,
  updatePos,
  updateTelMod,
} from "../../../helpers/billing/processClaimHelper.js";

import { isQueryParam, isQueryParamArray } from "../../../helpers/queryValidation.js";

import { getNameLocation } from "../../../helpers/common/Common.js";
import Patient from "../../../models/Patient/Patient.js";
import ProcessClaim from "../../../models/PrimaryBilling/ProcessClaim.js";
import Provider from "../../../models/Provider/Provider.js";
import ProviderDepartment from "../../../models/Provider/ProviderDepartment.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import SettingCptCode from "../../../models/Setting/SettingCptCode.js";

const getAppointmentByDate = async (req, res, next) => {
  try {
    const { to_date } = req.body;

    const app_data = await getAppointmentData(req.user.id, to_date);

    const name_location = await getNameLocation(req.user.id);

    if (name_location.is_combo === 1) {
      await processWithComboCode(req.user.id, app_data);
    } else {
      await processWithoutComboCode(req.user.id, app_data);
    }

    const payor_name = await getPayorNames(req.user.id, to_date);

    res.json({
      status: "success",
      message: "process claim insurance list",
      data: payor_name,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const shortByPatient = async (req, res, next) => {
  try {
    const { to_date, insurance_ids } = req.body;

    let patient_array = [];

    const prc_patient_list = await ProcessClaim.findAll({
      attributes: ["admin_id", "client_id"],
      group: ["admin_id", "client_id"],
      where: {
        admin_id: req.user.id,
        schedule_date: {
          [Op.lt]: to_date,
        },
        payor_id: {
          [Op.in]: insurance_ids,
        },
      },
    });

    await Promise.all(
      prc_patient_list.map(async (i) => {
        patient_array.push(i.client_id);
      })
    );

    const patient_list = await Patient.findAll({
      attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
      where: {
        admin_id: req.user.id,
        id: {
          [Op.in]: patient_array,
        },
      },
    });

    res.json({
      status: "success",
      message: "process claim patient list",
      data: patient_list,
    });
  } catch (e) {
    res.json(e.message);
    res.status(500).send("Server error");
  }
};

const shortByTreatingTherapist = async (req, res, next) => {
  try {
    const { to_date, insurance_ids } = req.body;

    let provider_array = [];

    const prc_provider_list = await ProcessClaim.findAll({
      attributes: ["admin_id", "provider_id"],
      group: ["admin_id", "provider_id"],
      where: {
        admin_id: req.user.id,
        schedule_date: {
          [Op.lt]: to_date,
        },
        payor_id: {
          [Op.in]: insurance_ids,
        },
      },
    });

    await Promise.all(
      prc_provider_list.map(async (i) => {
        provider_array.push(i.provider_id);
      })
    );

    const provider_list = await Provider.findAll({
      attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
      where: {
        admin_id: req.user.id,
        id: {
          [Op.in]: provider_array,
        },
      },
    });

    res.json({
      status: "success",
      message: "process claim treating therapist list",
      data: provider_list,
    });
  } catch (e) {
    res.json(e.message);
    res.status(500).send("Server error");
  }
};

const shortByCmsTherapist = async (req, res, next) => {
  try {
    const { to_date } = req.body;

    let cms_provider_array = [];

    const prc_cms_provider_list = await ProviderDepartment.findAll({
      where: {
        admin_id: req.user.id,
        is_supervisor: 1,
      },
    });

    await Promise.all(
      prc_cms_provider_list.map(async (i) => {
        cms_provider_array.push(i.id);
      })
    );

    const cms_provider_list = await Provider.findAll({
      attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
      where: {
        admin_id: req.user.id,
        id: {
          [Op.in]: cms_provider_array,
        },
      },
    });

    res.json({
      status: "success",
      message: "process claim cms therapist list",
      data: cms_provider_list,
    });
  } catch (e) {
    res.json(e.message);
    res.status(500).send("Server error");
  }
};

const shortByActivityType = async (req, res, next) => {
  try {
    const { to_date, insurance_ids } = req.body;

    let activity_array = [];

    const activity_type_list = await ProcessClaim.findAll({
      attributes: ["admin_id", "activity_id"],
      group: ["admin_id", "activity_id"],
      where: {
        admin_id: req.user.id,
        schedule_date: {
          [Op.lt]: to_date,
        },
        payor_id: {
          [Op.in]: insurance_ids,
        },
      },
    });

    await Promise.all(
      activity_type_list.map(async (i) => {
        activity_array.push(i.activity_id);
      })
    );

    const activity_list = await PatientAuthActivity.findAll({
      attributes: ["id", "admin_id", "activity_one"],
      where: {
        admin_id: req.user.id,
        id: {
          [Op.in]: activity_array,
        },
      },
    });

    res.json({
      status: "success",
      message: "process claim activity type list",
      data: activity_list,
    });
  } catch (e) {
    res.json(e.message);
    res.status(500).send("Server error");
  }
};

const shortByCpt = async (req, res, next) => {
  try {
    const { to_date, insurance_ids } = req.body;

    let cpt_array = [];

    const cpt_code_list = await ProcessClaim.findAll({
      attributes: ["admin_id", "cpt"],
      group: ["admin_id", "cpt"],
      where: {
        admin_id: req.user.id,
        schedule_date: {
          [Op.lt]: to_date,
        },
        payor_id: {
          [Op.in]: insurance_ids,
        },
      },
    });

    await Promise.all(
      cpt_code_list.map(async (i) => {
        cpt_array.push(i.cpt);
      })
    );

    const cpt_list = await SettingCptCode.findAll({
      attributes: ["id", "admin_id", "service"],
      where: {
        admin_id: req.user.id,
        id: {
          [Op.in]: cpt_array,
        },
      },
    });

    res.json({
      status: "success",
      message: "process claim cpt list",
      data: cpt_list,
    });
  } catch (e) {
    res.json(e.message);
    res.status(500).send("Server error");
  }
};

const shortByModifire = async (req, res, next) => {
  try {
    const { to_date, insurance_ids } = req.body;

    const modifire_array = [];

    const modifire_data = await ProcessClaim.findAll({
      attributes: ["admin_id", "m1", "m2", "m3", "m4"],
      group: ["admin_id", "m1", "m2", "m3", "m4"],
      where: {
        admin_id: req.user.id,
        schedule_date: {
          [Op.lt]: to_date,
        },
        [Op.and]: [
          {
            m1: {
              [Op.ne]: null,
            },
          },
          {
            m2: {
              [Op.ne]: null,
            },
          },
          {
            m3: {
              [Op.ne]: null,
            },
          },
          {
            m4: {
              [Op.ne]: null,
            },
          },
        ],
        payor_id: {
          [Op.in]: insurance_ids,
        },
      },
    });

    await Promise.all(
      modifire_data.map(async (i) => {
        modifire_array.includes(i.m1) ? "" : modifire_array.push(i.m1);
        modifire_array.includes(i.m2) ? "" : modifire_array.push(i.m2);
        modifire_array.includes(i.m3) ? "" : modifire_array.push(i.m3);
        modifire_array.includes(i.m4) ? "" : modifire_array.push(i.m4);
      })
    );

    res.json({
      status: "success",
      message: "process claim modifire list",
      data: modifire_array,
    });
  } catch (error) {
    res.json(error.message);
    res.status(500).send("Server error");
  }
};

const getBillingData = async (req, res, next) => {
  try {
    const {
      page,
      to_date,
      payor_ids,
      client1,
      treating_therapist,
      cms_therapist,
      activitytype,
      ready_to_bill_status,
      degree_level,
      zone,
      cptcode,
      modifire,
      pos,
      zero_units,
      client2,
      treating_therapist1,
      cms_therapist1,
      activitytype1,
      ready_to_bill_status1,
      reportrange1,
      degree_level1,
      zone1,
      cptcode1,
      modifire1,
      pos1,
      zero_units_one,
    } = req.body;

    const { perPage, offset } = getPagination(page);

    let searchBilling = {};
    searchBilling.admin_id = req.user.id;
    searchBilling.is_mark_gen = 0;

    searchBilling.status = {
      [Op.ne]: "Unbillable Activity",
    };

    searchBilling.schedule_date = {
      [Op.lte]: to_date,
    };

    if (await isQueryParam(client1)) {
      searchBilling.client_id = {
        [Op.eq]: client1,
      };
    }

    if (await isQueryParamArray(payor_ids)) {
      searchBilling.payor_id = {
        [Op.in]: payor_ids,
      };
    }

    if (await isQueryParam(treating_therapist)) {
      searchBilling.provider_id = {
        [Op.eq]: treating_therapist,
      };
    }

    if (await isQueryParam(cms_therapist)) {
      searchBilling.provider_id = {
        [Op.eq]: cms_therapist,
      };
    }

    if (await isQueryParam(activitytype)) {
      searchBilling.activity_id = {
        [Op.eq]: activitytype,
      };
    }

    if (await isQueryParam(ready_to_bill_status)) {
      searchBilling.status = {
        [Op.eq]: ready_to_bill_status,
      };
    }

    if (await isQueryParam(degree_level)) {
      searchBilling.degree_level = {
        [Op.eq]: degree_level,
      };
    }

    if (await isQueryParam(zone)) {
      searchBilling.zone = {
        [Op.eq]: zone,
      };
    }

    if (await isQueryParam(cptcode)) {
      searchBilling.cpt = {
        [Op.eq]: cptcode,
      };
    }

    if (await isQueryParam(pos)) {
      searchBilling.location = {
        [Op.eq]: pos,
      };
    }

    console.log("searchBilling ====>", searchBilling);
    // const process_claim_data = await ProcessClaim.findAndCountAll({
    //   where: searchBilling,
    //   order: [["id", "DESC"]],
    //   limit: perPage,
    //   offset: offset,
    // });

    const process_claim_data = await ProcessClaim.findAndCountAll({
      where: searchBilling,
      order: [["id", "ASC"]],
      // include: ["procc_patient", "procc_provider"],
      include: [
        {
          model: Patient,
          as: "procc_patient",
          attributes: ["id", "admin_id", "client_full_name", "client_first_name", "client_middle", "client_last_name"],
        },
        {
          model: Provider,
          as: "procc_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
        {
          model: Provider,
          as: "procc_provider_cms",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
        {
          model: PatientAuthActivity,
          as: "procc_patient_auth_act",
          attributes: ["id", "admin_id", "activity_name"],
        },
      ],
      limit: perPage,
      offset,
    });
    res.json({
      status: "success",
      message: "process claim billing data",
      processClaims: getPagingData(process_claim_data, page, perPage),
    });
    return false;
  } catch (error) {
    res.json(error.message);
    res.status(500).send("Server error");
  }
};

const getBillingDataUpdate = async (req, res, next) => {
  try {
    const {
      action_type,
      prc_claim_ids,
      cms_provider_id,
      m1_val,
      m2_val,
      m3_val,
      m4_val,
      rate_val,
      cpt_val,
      unit_val,
      provider_id,
      pos_val,
      tele_mod_value,
      id_qualifiers_val,
    } = req.body;

    if (action_type == 1) {
      await updateStatus(req.user.id, prc_claim_ids);
    } else if (action_type == 2) {
      await updateStatusClarificationPending(req.user.id, prc_claim_ids);
    } else if (action_type == 3) {
      await retractSession(req.user.id, prc_claim_ids);
    } else if (action_type == 4) {
      await nonBillableServ(req.user.id, prc_claim_ids);
    } else if (action_type == 5) {
      await update24jProvider(req.user.id, prc_claim_ids, cms_provider_id);
    } else if (action_type == 6) {
      await updateIdQualifires(req.user.id, prc_claim_ids, id_qualifiers_val);
    } else if (action_type == 7) {
      await updateModifires(req.user.id, prc_claim_ids, m1_val, m2_val, m3_val, m4_val);
    } else if (action_type == 9) {
      await updateChargeAmount(req.user.id, prc_claim_ids, rate_val);
    } else if (action_type == 10) {
      await updateChargeAmount(req.user.id, prc_claim_ids, rate_val);
    } else if (action_type == 11) {
      await addCptCode(req.user.id, prc_claim_ids, cpt_val, unit_val);
    } else if (action_type == 12) {
      await updateTxProvider(req.user.id, prc_claim_ids, provider_id);
    } else if (action_type == 14) {
      await updatePos(req.user.id, prc_claim_ids, pos_val);
    } else if (action_type == 15) {
      await updateTelMod(req.user.id, prc_claim_ids, tele_mod_value);
    } else if (action_type == 16) {
      await updateTelMod(req.user.id, prc_claim_ids);
    }

    res.json({
      status: "success",
      message: "process claim billing data",
    });
    return false;
  } catch (error) {
    res.json(error.message);
    res.status(500).send("Server error");
  }
};

export default {
  getAppointmentByDate,
  shortByPatient,
  shortByTreatingTherapist,
  shortByCmsTherapist,
  shortByActivityType,
  shortByCpt,
  shortByModifire,
  getBillingData,
  getBillingDataUpdate,
};
