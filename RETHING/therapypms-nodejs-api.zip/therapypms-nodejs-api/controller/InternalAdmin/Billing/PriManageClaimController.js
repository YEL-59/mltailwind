import Patient from "../../../models/Patient/Patient.js";
import PriManageClaim from "../../../models/PrimaryBilling/ManageClaim.js";
import PriManageClaimTransaction from "../../../models/PrimaryBilling/ManageClaimTransaction.js";
import Provider from "../../../models/Provider/Provider.js";
import { isQueryParam, isQueryParamArray } from "../../../helpers/queryValidation.js";
import { Op, Sequelize } from "sequelize";
import ProcessClaim from "../../../models/PrimaryBilling/ProcessClaim.js";
import { sequelize } from "../../../config/db.js";
import PayorFacility from "../../../models/Setting/PayorFacility.js";

const getBatchId = async (req, res) => {
  try {
    const get_batch_id = await PriManageClaimTransaction.findAll({
      attributes: ["admin_id", "batch_id"],
      group: ["admin_id", "batch_id"],
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "manage claim batch id list",
      data: get_batch_id,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const getClaimId = async (req, res) => {
  try {
    const get_claim_id = await PriManageClaimTransaction.findAll({
      attributes: ["admin_id", "claim_id"],
      group: ["admin_id", "claim_id"],
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "manage claim claim id list",
      data: get_claim_id,
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

const getPatientList = async (req, res) => {
  try {
    const get_patient_list = await PriManageClaimTransaction.findAll({
      attributes: ["admin_id", "client_id"],
      // group: ["admin_id", "client_id"],
      where: {
        admin_id: req.user.id,
      },
      include: [
        {
          model: Patient,
          as: "pri_mngclm_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
      ],
    });

    res.json({
      status: "success",
      message: "manage claim patient list",
      data: get_patient_list,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const getTxProvider = async (req, res) => {
  try {
    const get_tx_provider = Provider.findAll({
      attributes: ["id", "admin_id", "full_name"],
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "manage claim tx privider list",
      data: get_tx_provider,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const getCmsProvider = async (req, res) => {
  try {
    const get_tx_provider = await PriManageClaimTransaction.findAll({
      attributes: ["id", "admin_id", "cms_24j"],
      where: {
        admin_id: req.user.id,
      },
      include: [
        {
          model: Provider,
          as: "pri_mngclm_cms_provider",
          attributes: ["id", "admin_id", "full_name"],
        },
      ],
    });

    res.json({
      status: "success",
      message: "manage claim tx provider list",
      data: get_tx_provider,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const manageClaimList = async (req, res) => {
  try {
    const { page, batch_no, claim_id } = req.body;

    let searchAppointment = {};
    searchAppointment.admin_id = req.user.id;
    searchAppointment.is_primary = 1;
    if (await isQueryParam(batch_no)) {
      searchAppointment.batch_id = {
        [Op.eq]: batch_no,
      };
    }

    if (await isQueryParam(claim_id)) {
      searchAppointment.claim_id = {
        [Op.eq]: claim_id,
      };
    }

    const manage_claim_data = await PriManageClaim.findAll({
      attributes: [
        "id",
        "admin_id",
        "batch_id",
        "claim_id",
        "resubmit_date",
        "box_19",
        "resubmit_code",
        "orginal_ref_number",
        "auth_no",
        "is_primary",
        "schedule_date",
      ],

      where: searchAppointment,
      include: [
        {
          model: PriManageClaimTransaction,
          as: "mngclam_tran",
          attributes: ["admin_id", "processing_claim_id", "claim_id", "batch_id", "schedule_date"],

          where: {
            admin_id: req.user.id,
          },
          include: [
            {
              model: ProcessClaim,
              as: "pri_mngclmtrn_prcclm",

              where: {
                admin_id: req.user.id,
              },
            },
          ],
        },
        {
          model: PriManageClaimTransaction,
          as: "mngclam_tran_asc",
          attributes: ["id", "admin_id", "claim_id", "batch_id", "schedule_date"],
          where: {
            admin_id: req.user.id,
          },
          order: [["schedule_date", "ASC"]],
          limit: 1,
        },
        {
          model: PriManageClaimTransaction,
          as: "mngclam_tran_desc",
          attributes: ["id", "admin_id", "claim_id", "batch_id", "schedule_date"],
          where: {
            admin_id: req.user.id,
          },
          order: [["schedule_date", "DESC"]],
          limit: 1,
        },
        {
          model: Patient,
          as: "mngclam_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
          where: {
            admin_id: req.user.id,
          },
        },
      ],
    });

    res.json({
      status: "success",
      message: "manage claim list",
      data: manage_claim_data,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const manageClaimListTransaction = async (req, res) => {
  try {
    const { claim_id } = req.body;

    const mng_clm_transaction = await PriManageClaimTransaction.findAll({
      attributes: [
        "id",
        "admin_id",
        "processing_claim_id",
        "claim_id",
        "batch_id",
        "appointment_id",
        "client_id",
        "provider_id",
        "authorization_id",
        "payor_id",
        "schedule_date",
        "is_primary",
        "cms_24j",
        "createdAt",
        "updatedAt",
      ],
      where: {
        admin_id: req.user.id,
        claim_id: {
          [Op.in]: claim_id,
        },
      },
      include: [
        {
          model: Patient,
          as: "pri_mngclmtrn_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
          where: {
            admin_id: req.user.id,
          },
        },
        {
          model: ProcessClaim,
          as: "pri_mngclmtrn_prcclm",

          where: {
            admin_id: req.user.id,
          },
        },
        {
          model: PayorFacility,
          as: "pri_mngclmtrn_payor",
          attributes: ["admin_id", "payor_name"],
          where: {
            admin_id: req.user.id,
          },
        },
      ],
    });

    res.json({
      status: "success",
      message: "manage claim transaction list",
      data: mng_clm_transaction,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

export default {
  getBatchId,
  getClaimId,
  getPatientList,
  getTxProvider,
  getCmsProvider,
  manageClaimList,
  manageClaimListTransaction,
};
