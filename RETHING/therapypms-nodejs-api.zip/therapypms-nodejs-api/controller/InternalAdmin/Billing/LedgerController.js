import Ledger from "../../../models/Ledger/Ledger.js";
import Patient from "../../../models/Patient/Patient.js";
import PayorFacility from "../../../models/Setting/PayorFacility.js";
import SettingCptCode from "../../../models/Setting/SettingCptCode.js";

import { clmWiseClaimNo, clmWisePatientData } from "../../../helpers/billing/ledgerHelper.js";
import { QueryTypes, Sequelize } from "sequelize";
import { sequelize } from "../../../config/db.js";

const patientList = async (req, res) => {
  try {
    const dis_patient = await sequelize.query("SELECT DISTINCT client_id FROM ledger_lists;", {
      type: QueryTypes.SELECT,
    });

    // let pt_ids = Patient.

    await Promise.all(
      prc_ap_data.map(async (i) => {
        p_array.push(i.payor_id);
      })
    );

    return res.json({
      data: dis_patient,
    });
    return false;
    const patient_list = await Ledger.findAll({
      attributes: ["admin_id", "client_id"],
      where: {
        admin_id: req.user.id,
      },
      include: [
        {
          model: Patient,
          as: "ledger_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
      ],
    });

    res.json({
      status: "success",
      message: "ledger patient list",
      data: patient_list,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const insuranceList = async (req, res) => {
  try {
    const payor_list = await Ledger.findAll({
      attributes: ["id", "admin_id", "payor_id"],
      where: {
        admin_id: req.user.id,
      },
      include: [
        {
          model: PayorFacility,
          as: "ledger_payor",
          attributes: ["id", "admin_id", "payor_id", "payor_name"],
        },
      ],
    });

    res.json({
      status: "success",
      message: "ledger payor facility list",
      data: payor_list,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const cptList = async (req, res) => {
  try {
    const cpt_list = await SettingCptCode.findAll({
      where: {
        admin_id: req.user.id,
      },
    });

    res.json({
      status: "success",
      message: "ledger cpt list",
      data: cpt_list,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const ledgerListClaimWise = async (req, res) => {
  try {
    const { page, sort_by, claim_no, patient_ids, insurance_ids, start_date, end_date } = req.body;

    let ledger_data;
    if (sort_by === 1) {
      ledger_data = await clmWiseClaimNo(req.user.id, claim_no, page);
    } else if (sort_by === 2) {
      ledger_data = await clmWisePatientData(req.user.id, patient_ids, start_date, end_date);
    } else if (sort_by == 3) {
      ledger_data = await clmWiseInsData(req.user.id, insurance_ids);
    } else {
      res.json({
        status: "error",
        message: "please slect sort by",
      });
      return false;
    }

    res.json({
      status: "success",
      message: "ledger data get",
      process_claims: ledger_data,
      claim_id: claim_no,
    });
    return false;
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const ledgerListCptWise = async (req, res) => {
  try {
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

export default {
  patientList,
  insuranceList,
  cptList,
  ledgerListClaimWise,
  ledgerListCptWise,
};
