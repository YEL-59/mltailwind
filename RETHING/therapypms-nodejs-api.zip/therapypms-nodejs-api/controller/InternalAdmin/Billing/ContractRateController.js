import ContractRate from "../../../models/ContractRate/ContractRate.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import PayorFacility from "../../../models/Setting/PayorFacility.js";

const billingRateList = async (req, res, next) => {
  try {
    const { payorId } = req.body;
    const adminId = req.user.id;

    const whereCondition = { admin_id: adminId };

    if (payorId) {
      whereCondition.payor_id = payorId;
    }
    const rateLists = await ContractRate.findAll({
      where: whereCondition,
      order: [["id", "DESC"]],
    });

    return res.status(200).json({
      status: "success",
      message: "billing rate list",
      data: rateLists,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server error");
  }
};

const contractRateAdd = async (req, res) => {};

const contractRateCreate = async (req, res) => {
  try {
    const {
      payor_id,
      treatment_type,
      activity_type,
      sub_activity,
      cpt_code,
      m1,
      m2,
      m3,
      m4,
      rate_type,
      rate_per,
      contracted_rate,
      billed_rate,
      increasing_percentage,
      active,
      add_auth,
      degree_level,
    } = req.body;

    const create_contract_rate = await ContractRate.create({
      admin_id: req.user.id,
      payor_id: payor_id,
      treatment_type: treatment_type,
      activity_type: activity_type,
      activity_type: activity_type,
      sub_activity: sub_activity,
      cpt_code: cpt_code,
      m1: m1,
      m2: m2,
      m3: m3,
      m4: m4,
      rate_type: rate_type,
      rate_per: rate_per,
      contracted_rate: contracted_rate,
      billed_rate: billed_rate,
      increasing_percentage: increasing_percentage,
      active: active,
      add_auth: add_auth,
      degree_level: degree_level,
    });

    res.json({
      status: "success",
      message: "contract rate successfully created",
    });
  } catch (error) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
const contractRateEdit = async (req, res) => {
  try {
    const { contract_rate_id } = req.body;
    const single_contract_rate = await ContractRate.findOne({
      where: {
        admin_id: req.user.id,
        id: contract_rate_id,
      },
    });

    res.json({
      status: "success",
      message: "contract rate single",
      data: single_contract_rate,
    });
  } catch (error) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
const contractRateUpdate = async (req, res) => {
  try {
    const {
      contract_rate_id,
      payor_id,
      treatment_type,
      activity_type,
      sub_activity,
      cpt_code,
      m1,
      m2,
      m3,
      m4,
      rate_type,
      rate_per,
      contracted_rate,
      billed_rate,
      increasing_percentage,
      active,
      add_auth,
      degree_level,
    } = req.body;

    const create_contract_rate = await ContractRate.findOne({
      where: {
        admin_id: req.user.id,
        id: contract_rate_id,
      },
    });
    create_contract_rate.set({
      payor_id: payor_id,
      treatment_type: treatment_type,
      activity_type: activity_type,
      activity_type: activity_type,
      sub_activity: sub_activity,
      cpt_code: cpt_code,
      m1: m1,
      m2: m2,
      m3: m3,
      m4: m4,
      rate_type: rate_type,
      rate_per: rate_per,
      contracted_rate: contracted_rate,
      billed_rate: billed_rate,
      increasing_percentage: increasing_percentage,
      active: active,
      add_auth: add_auth,
      degree_level: degree_level,
    });

    await create_contract_rate.save();

    res.json({
      status: "success",
      message: "contract rate successfully updated",
      data: single_contract_rate,
    });
  } catch (error) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};
const contractRateDelete = async (req, res) => {
  try {
    const { contract_rate_id } = req.body;

    const patient_activity = PatientAuthActivity.findOne({
      where: {
        admin_id: req.user.id,
        rate_id: contract_rate_id,
      },
    });

    if (patient_activity) {
      res.json({
        status: "error",
        message: "Rate List already active in activity",
      });
      return false;
    }

    const contract_rate = await ContractRate.destroy({
      where: {
        admin_id: req.user.id,
        id: contract_rate_id,
      },
    });

    res.json({
      status: "success",
      message: "contract rate successfully deleted",
    });
  } catch (error) {
    console.error(e.message);
    res.status(500).send("Server error");
  }
};

export default {
  billingRateList,
  contractRateAdd,
  contractRateCreate,
  contractRateEdit,
  contractRateUpdate,
  contractRateDelete,
};
