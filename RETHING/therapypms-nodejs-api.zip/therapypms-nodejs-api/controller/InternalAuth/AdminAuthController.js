import { validationResult } from "express-validator";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import config from "config";

import Admin from "../../models/Setting/Admin.js";
import ApiUser from "../../models/Setting/ApiUsers.js";
import Patient from "../../models/Patient/Patient.js";
import Provider from "../../models/Provider/Provider.js";

export const adminAuth = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ status: errors.array() });
  }
  const { email, password } = req.body;

  try {
    res.setHeader("Content-Type", "application/json");
    let admin = await Admin.findOne({
      where: { email: email },
    });

    let patient = await Patient.findOne({
      where: { login_email: email },
    });

    let provider = await Provider.findOne({
      where: { login_email: email },
    });

    if (admin) {
      //for first time password encryption
      // const salt = await bcrypt.genSalt(10);
      // admin.password = await bcrypt.hash(password, salt);
      // await admin.save();
      // res.json("done");

      let user_admin_id;
      const isMatch = await bcrypt.compare(password, admin.password);

      if (!isMatch) {
        return res.status(400).json({ errors: [{ msg: "Invalid Credentials" }] });
        return false;
      }

      if (admin.is_up_admin == 1) {
        user_admin_id = admin.id;
      } else {
        user_admin_id = admin.up_admin_id;
      }

      const payload = {
        user: {
          id: user_admin_id,
          admin_id: user_admin_id,
          type: "InternalAdmin",
        },
      };

      jwt.sign(payload, config.get("jwtSecret"), { expiresIn: 36000 }, (err, token) => {
        if (err) throw err;
        res.json({
          status: "success",
          message: "InternalAdmin Successfully logged In",
          access_token: token,
          exp_in: 3600,
        });
      });
    } else if (patient) {
      //for first time password encryption
      // const salt = await bcrypt.genSalt(10);
      // patient.password = await bcrypt.hash(password, salt);
      // await patient.save();
      // res.json("done");

      const isMatch = await bcrypt.compare(password, patient.password);

      if (!isMatch) {
        return res.status(400).json({ errors: [{ msg: "Invalid Credentials" }] });
        return false;
      }

      const payload = {
        user: {
          id: patient.id,
          admin_id: patient.admin_id,
          type: "InternalPatient",
        },
      };

      jwt.sign(payload, config.get("jwtSecret"), { expiresIn: 36000 }, (err, token) => {
        if (err) throw err;
        res.json({
          status: "success",
          message: "InternalPatient Successfully logged In",
          access_token: token,
          exp_in: 3600,
        });
      });
    } else if (provider) {
      //for first time password encryption
      // const salt = await bcrypt.genSalt(10);
      // provider.password = await bcrypt.hash(password, salt);
      // await provider.save();
      // res.json("done");

      const isMatch = await bcrypt.compare(password, provider.password);

      if (!isMatch) {
        return res.status(400).json({ errors: [{ msg: "Invalid Credentials" }] });
        return false;
      }

      const payload = {
        user: {
          id: provider.id,
          admin_id: provider.admin_id,
          type: "InternalProvider",
        },
      };

      jwt.sign(payload, config.get("jwtSecret"), { expiresIn: 36000 }, (err, token) => {
        if (err) throw err;
        res.json({
          status: "success",
          message: "InternalProvider Successfully logged In",
          access_token: token,
          exp_in: 3600,
          user: {
            providerName: provider.full_name,
            providerEmail: provider.login_email,
          },
        });
      });
    } else {
      return res.json({
        status: "error",
        message: "Credentials not match",
      });
    }

    // if (!admin) {
    //   return res.status(400).json({ errors: [{ msg: "Invalid Credentials" }] });
    // }

    // const salt = await bcrypt.genSalt(10);
    // admin.password = await bcrypt.hash(password, salt);
    // await admin.save();
    //
    // res.json('done');
  } catch (err) {
    res.setHeader("Content-Type", "application/json");
    console.error(err.message);
    res.status(500).send("server error");
  }
};
