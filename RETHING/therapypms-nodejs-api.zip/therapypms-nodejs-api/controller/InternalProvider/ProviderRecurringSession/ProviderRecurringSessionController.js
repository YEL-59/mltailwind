import { Op } from "sequelize";
import Patient from "../../../models/Patient/Patient.js";
import Provider from "../../../models/Provider/Provider.js";
import RecurringSession from "../../../models/Appointment/RecurringSession.js";
import SettingPos from "../../../models/Setting/PointOfService.js";
import Appointment from "../../../models/Appointment/Appointment.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";

const settingpos = async (req, res, next) => {
  try {
    const result = await SettingPos.findAll({
      where: { admin_id: req.user.admin_id },
    });
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const recurringSessionGetSortedInfo = async (req, res, next) => {
  const { sortBy } = req.body;

  if (sortBy === 2) {
    try {
      const result = await Patient.findAll({
        attributes: ["id", "admin_id", "client_full_name"],
        where: { admin_id: req.user.admin_id },
        order: [["client_full_name", "ASC"]],
      });
      res.status(200).json({
        message: "Success",
        allClients: result,
      });
    } catch (error) {
      res.status(500).json({ error: "Internal Server Error" });
    }
  } else if (sortBy === 3) {
    try {
      const employees = await Provider.findAll({
        attributes: ["id", "admin_id", "full_name"],
        where: { admin_id: req.user.admin_id, id: req.user.id },
        order: [["full_name", "ASC"]],
      });
      res.status(200).json({
        message: "Success",
        allEmployees: employees,
      });
    } catch (error) {
      res.status(500).json({ error: "Internal Server Error" });
    }
  } else {
    res.status(400).json({ error: "Invalid sort_by parameter" });
  }
};

const recurringSessionDataGet = async (req, res, next) => {
  const { sort_by, patient_ids, provider_ids } = req.body;
  const admin_id = req.user.admin_id;

  const options = {
    where: { admin_id: admin_id },
    order: [["id", "DESC"]],
  };

  if (sort_by == 2 && patient_ids) {
    options.where.client_id = { [Op.in]: patient_ids };
  }

  if (sort_by == 3 && provider_ids) {
    options.where.provider_id = { [Op.in]: provider_ids };
  }

  try {
    const recurring_sessions = await RecurringSession.findAll(options);

    res.json({
      message: "Success",
      recurring_sessions: recurring_sessions,
    });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const recurringSessionEdit = async (req, res, next) => {
  try {
    const { id } = req.params;
    console.log(typeof id);
    const recurringSession = await RecurringSession.findOne({
      where: { id: id },
    });

    const sessionData = await Appointment.findOne({
      where: {
        recurring_id: id,
      },
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
        {
          model: PatientAuthorization,
          as: "app_auth",
          attributes: ["id", "admin_id", "authorization_name"],
        },
        {
          model: PatientAuthActivity,
          as: "app_activity",
          attributes: ["id", "admin_id", "activity_name"],
        },
        {
          model: Provider,
          as: "app_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
        {
          model: SettingPos,
          as: "app_pos",
          attributes: ["id", "pos_code", "pos_name"],
        },
      ],
    });

    if (!sessionData) {
      return res.status(200).json("Sessions for this recurring pattern have been deleted.");
    }

    let patientAuth = [];
    let patientActivity = [];
    let allLocations = [];
    let allProviders = [];
    if (recurringSession?.client_id) {
      patientAuth = await PatientAuthorization.findAll({
        attributes: ["id", "admin_id", "authorization_name"],
        where: {
          admin_id: req.user.admin_id,
          client_id: recurringSession?.client_id,
        },
      });
      patientActivity = await PatientAuthActivity.findAll({
        where: {
          admin_id: req.user.admin_id,
          client_id: recurringSession?.client_id,
        },
      });
      allLocations = await SettingPos.findAll({
        where: {
          admin_id: req.user.admin_id,
        },
      });
      allProviders = await Provider.findAll({
        where: {
          admin_id: req.user.admin_id,
        },
        attributes: ["id", "first_name", "middle_name", "last_name", "full_name"],
      });
    }

    const sessionScheduled = await Appointment.findAll({
      where: {
        recurring_id: id,
        is_locked: 0,
      },
    });
    const sessionRendered = await Appointment.findAll({
      where: {
        recurring_id: id,
        is_locked: 1,
      },
    });

    return res.status(200).json({
      recurringSession,
      sessionData,
      patientAuth,
      patientActivity,
      allLocations,
      allProviders,
      sessionRendered,
      sessionScheduled,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export default {
  recurringSessionGetSortedInfo,
  recurringSessionDataGet,
  settingpos,
  recurringSessionEdit,
};
