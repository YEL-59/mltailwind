import Provider from "../../../models/Provider/Provider.js";
import ProviderContactDetail from "../../../models/Provider/ProviderContactDetail.js";
import ProviderEmgConDetail from "../../../models/Provider/ProviderEmgConDetail.js";

const providerContactInfo = async (req, res) => {
    try {
        const employeeName = await Provider.findOne({
            where: {
                id: req.user.id,
                admin_id: req.user.admin_id,
            },
        });

        const existEmployee = await ProviderContactDetail.findOne({
            where: {
                employee_id: req.user.id,
            },
        });

        const existEmployeeEm = await ProviderEmgConDetail.findOne({
            where: {
                employee_id: req.user.id,
            },
        });

        let employee;
        if (existEmployee) {
            employee = existEmployee;
        } else {
            employee = await ProviderContactDetail.create({
                employee_id: req.user.id,
            });
        }

        let employeeEm;
        if (existEmployeeEm) {
            employeeEm = existEmployeeEm;
        } else {
            employeeEm = await ProviderEmgConDetail.create({
                employee_id: req.user.id,
            });
        }

        return res.json({ employee, employee_em: employeeEm, employee_name: employeeName });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};




const providerContactDetailsUpdate = async (req, res) => {
    try {
        const employeContactUpdate = await ProviderContactDetail.findOne({
            where: {
                employee_id: req.user.id,
            },
        });

        employeContactUpdate.address_one = req.body.address_one;
        employeContactUpdate.address_two = req.body.address_two;
        employeContactUpdate.city = req.body.city;
        employeContactUpdate.state = req.body.state;
        employeContactUpdate.zip = req.body.zip;
        employeContactUpdate.mobile = req.body.mobile;
        employeContactUpdate.fax = req.body.fax;
        employeContactUpdate.main_phone = req.body.main_phone;
        employeContactUpdate.address_note = req.body.address_note;
        await employeContactUpdate.save();

        return res.json({ success: true, message: 'Contact Details Successfully Updated' });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

const providerEmergencyContactUpdate = async (req, res) => {
    try {
        const employeEmContactUpdate = await ProviderEmgConDetail.findOne({
            where: {
                employee_id: req.user.id,
            },
        });

        employeEmContactUpdate.contact_name = req.body.em_contact_name;
        employeEmContactUpdate.address_one = req.body.em_address_one;
        employeEmContactUpdate.address_two = req.body.em_address_two;
        employeEmContactUpdate.city = req.body.em_city;
        employeEmContactUpdate.state = req.body.em_state;
        employeEmContactUpdate.zip = req.body.em_zip;
        employeEmContactUpdate.mobile = req.body.em_mobile;
        employeEmContactUpdate.fax = req.body.em_fax;
        employeEmContactUpdate.main_phone = req.body.em_main_phone;
        employeEmContactUpdate.address_note = req.body.em_address_note;
        await employeEmContactUpdate.save();

        return res.json({ success: true, message: 'Emergency Contact Details Successfully Updated' });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

export default { providerContactInfo, providerContactDetailsUpdate, providerEmergencyContactUpdate }