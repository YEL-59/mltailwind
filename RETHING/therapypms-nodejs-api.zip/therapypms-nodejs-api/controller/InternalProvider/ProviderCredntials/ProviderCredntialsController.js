
import { getPagination, getPagingData } from '../../../helpers/pagination.js';
import Provider from '../../../models/Provider/Provider.js';
import ProviderClearnce from '../../../models/Provider/ProviderClearnces.js';
import ProviderCredential from '../../../models/Provider/ProviderCredential.js';
import ProviderLeave from '../../../models/Provider/ProviderLeave.js';
import ProviderQualification from '../../../models/Provider/ProviderQualification.js';
import HolidaySetup from '../../../models/Setting/HolidaySetup.js';

const credentials = async (req, res) => {
    try {
        const { page } = req.body;
        const { perPage, offset } = getPagination(page);
        const employee = await Provider.findOne({
            where: {
                id: req.user.id,
                admin_id: req.user.admin_id,
            },
        });
        const credentialList = await ProviderCredential.findAndCountAll({
            where: {
                employee_id: req.user.id,
            },
        });
        return res.status(200).json({
            status: "success",
            message: "Employee Credential List",
            employee: employee,
            credentialsList: getPagingData(credentialList, page, perPage),
        });
    } catch (e) {
        // res.status(500).send("Server error");
        res.json({
            error: e.message
        })
    }
};
//cred save
const credentials_save = async (req, res) => {
    try {
        const lastRecord = await ProviderCredential.findOne({
            order: [["id", "DESC"]],
        });

        const newEmployeeCredential = await ProviderCredential.create({
            id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
            employee_id: req.user.id,
            credential_name: req.body.cred_type,
            credential_date_issue: req.body.date_issue,
            credential_date_expired: req.body.date_expire,
            credential_applicable: req.body.cred_apply,
        });
        return res.status(200).json({
            status: "success",
            message: "Employee Credential Successfully Created",
            employeeCredential: newEmployeeCredential,
        });
    } catch (e) {
        res.status(500).send(e);
    }
};

// single credntials

const singleCredentials = async (req, res, next) => {
    try {
        const { cred_id } = req.params;
        const employeeCredential = await ProviderCredential.findOne({
            where: {
                id: cred_id,
            },
        });
        return res.status(200).json({
            status: "success",
            message: "Employee Credential",
            employeeCredential: employeeCredential,
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};


const credentials_Update = async (req, res, next) => {
    try {
        const { cred_id, cred_type, date_issue, date_expire, cred_apply, employee_id } = req.body;
        const data = await ProviderCredential.findByPk(cred_id);

        // if (req.file) {
        //   const image = req.file;
        //   const name = `${Date.now()}${employee_id}${image.originalname}`;
        //   const uploadPath = "assets/dashboard/staffdocument/";
        //   const imageUrl = uploadPath + name;

        //   await image.mv(imageUrl);
        //   data.credential_file = imageUrl;
        // }

        data.credential_name = cred_type;
        data.credential_date_issue = date_issue;
        data.credential_date_expired = date_expire;
        data.credential_applicable = cred_apply;

        await data.save();

        return res.status(200).json({
            status: "success",
            message: "Employee Credential Successfully Updated",
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};


const credentials_delete = async (req, res, next) => {
    try {
        const result = await ProviderCredential.destroy({
            where: { id: req.body.cred_id },
        });
        if (!result) {
            return res.status(404).send("Employee Credential not found");
        }
        return res.status(200).json({
            status: "success",
            message: "Employee Credential Successfully Deleted",
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};


const clearance = async (req, res, next) => {
    try {
        const { page } = req.body;
        const { perPage, offset } = getPagination(page);
        const employee = await Provider.findOne({
            where: {
                id: req.user.id,
                admin_id: req.user.admin_id,
            },
        });
        const clearenceList = await ProviderClearnce.findAndCountAll({
            where: {
                employee_id: req.user.id,
            },
        });
        return res.status(200).json({
            status: "success",
            message: "Employee Clearences List",
            employee: employee,
            clearences: getPagingData(clearenceList, page, perPage),
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};

const clearanceSave = async (req, res, next) => {
    try {
        // if (req.file) {
        //   const image = req.file;
        //   const name = `${Date.now()}${req.body.employee_id}${image.originalname}`;
        //   const uploadPath = path.join(
        //     __dirname,
        //     "..",
        //     "public",
        //     "assets",
        //     "dashboard",
        //     "staffdocument"
        //   );
        //   if (!fs.existsSync(uploadPath)) {
        //     fs.mkdirSync(uploadPath, { recursive: true });
        //   }
        //   await image.mv(path.join(uploadPath, name));
        //   const imageUrl = path.join(
        //     "/",
        //     "assets",
        //     "dashboard",
        //     "staffdocument",
        //     name
        //   );
        //   data.clearance_file = imageUrl;
        // }
        const lastRecord = await ProviderClearnce.findOne({
            order: [["id", "DESC"]],
        });

        const newProviderClearance = await ProviderClearnce.create({
            id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
            employee_id: req.user.id,
            clearance_name: req.body.clear_type,
            clearance_date_issue: req.body.date_issue,
            clearance_date_exp: req.body.date_expire,
            clearance_applicable: req.body.clear_apply,
        });
        // await ClientActivity.create({
        //   admin_id: req.user.id,
        //   title: "Staff Clearance Created",
        //   message: "Staff Clearance Created",
        //   act_date: new Date(),
        // });

        return res.status(200).json({
            status: "success",
            message: "Employee Clearance Successfully Created",
            employeeClearance: newProviderClearance,
        });
    } catch (e) {
        res.status(500).send(e);
    }
};

const singleClearance = async (req, res, next) => {
    try {
        const { clearance_id } = req.params;
        const employeeClearance = await ProviderClearnce.findOne({
            where: {
                id: clearance_id,
            },
        });
        return res.status(200).json({
            status: "success",
            message: "Employee Clearance Info",
            employeeClearance,
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};

const clearanceUpdate = async (req, res, next) => {
    try {
        const data = await ProviderClearnce.findByPk(req.body.clear_id);

        // if (req.file) {
        //   const imageUrl = "assets/dashboard/staffdocument/" + req.file.filename;
        //   data.clearance_file = imageUrl;
        // }

        data.clearance_name = req.body.clear_type;
        data.clearance_date_issue = req.body.date_issue;
        data.clearance_date_exp = req.body.date_expire;
        data.clearance_applicable = req.body.clear_apply;
        await data.save();

        return res.status(200).json({
            status: "success",
            message: "Employee Clearance Successfully Updated",
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};

const clearanceDelete = async (req, res, next) => {
    try {
        const result = await ProviderClearnce.destroy({
            where: { id: req.body.clear_id },
        });
        if (!result) {
            return res.status(404).send("Employee Clearance not found");
        }
        return res.status(200).json({
            status: "success",
            message: "Employee Clearance Successfully Deleted",
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};

// qualification

const providerQualificationList = async (req, res, next) => {
    try {
        const { page } = req.body;
        const { perPage, offset } = getPagination(page);
        const employee = await Provider.findOne({
            where: {
                id: req.user.id,
                admin_id: req.user.admin_id,
            },
        });

        const qualificationList = await ProviderQualification.findAndCountAll({
            where: {
                employee_id: req.user.id,
            },
        });

        return res.status(200).json({
            status: "success",
            message: "Employee Qualification List",
            employee: employee,
            qualifications: getPagingData(qualificationList, page, perPage),
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};

const providerQualificationSave = async (req, res, next) => {
    try {
        const data = new ProviderQualification();

        // if (req.file) {
        //   const name = Date.now() + req.body.employee_id + req.file.originalname;
        //   const uploadPath = "assets/dashboard/staffdocument/";
        //   await req.file.move(uploadPath, { name });
        //   const imageUrl = uploadPath + name;

        //   data.qualification_file = imageUrl;
        // }

        const lastRecord = await ProviderQualification.findOne({
            order: [["id", "DESC"]],
        });

        data.id = lastRecord ? parseInt(lastRecord.id) + 1 : 1;
        data.employee_id = req.user.id;
        data.qualification_name = req.body.qual_type;
        data.qualification_date_issue = req.body.date_issue;
        data.qualification_date_exp = req.body.date_expire;
        data.qualification_applicable = req.body.qual_apply;
        await data.save();

        // await ClientActivity.create({
        //   admin_id: req.user.id,
        //   title: "Staff Qualification Created",
        //   message: "Staff Qualification Created",
        //   act_date: new Date().toISOString(),
        // });

        res.status(200).json({
            success: true,
            message: "Staff Qualification Successfully Created",
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};
const providerSingleQualification = async (req, res, next) => {
    try {
        const { qual_id } = req.params;
        const qualification = await ProviderQualification.findOne({
            where: {
                id: qual_id,
            },
        });
        return res.status(200).json({
            status: "success",
            message: "Employee Qualification Info",
            qualification,
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};
const providerQualificationUpdate = async (req, res, next) => {
    try {
        const data = await ProviderQualification.findByPk(req.body.qual_id);

        // if (req.file) {
        //   const imageUrl = "assets/dashboard/staffdocument/" + req.file.filename;
        //   data.clearance_file = imageUrl;
        // }

        data.qualification_name = req.body.qual_type;
        data.qualification_date_issue = req.body.date_issue;
        data.qualification_date_exp = req.body.date_expire;
        data.qualification_applicable = req.body.qual_apply;
        await data.save();

        return res.status(200).json({
            status: "success",
            message: "Employee Qualification Successfully Updated",
        });
    } catch (e) {
        res.status(500).send("Server error");
    }
};

const providerQualificationDelete = async (req, res, next) => {
    try {
        const result = await ProviderQualification.destroy({
            where: { id: req.body.qual_id },
        });
        if (!result) {
            return res.status(404).send("Employee Qualification not found");
        }
        return res.status(200).json({
            status: "success",
            message: "Employee Qualification Successfully Deleted",
        });
    } catch (e) {
        console.log(e.message);
        res.status(500).send("Server error");
    }
};






export default { credentials, credentials_save, singleCredentials, credentials_Update, credentials_delete, clearanceDelete, clearanceUpdate, singleClearance, clearanceSave, clearance, providerQualificationList, providerQualificationSave, providerSingleQualification, providerQualificationUpdate, providerQualificationDelete }