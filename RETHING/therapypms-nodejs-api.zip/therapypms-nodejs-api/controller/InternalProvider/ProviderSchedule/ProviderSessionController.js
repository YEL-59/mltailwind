import { Op } from "sequelize";
import Appointment from "../../../models/Appointment/Appointment.js";
import ProviderDepartment from "../../../models/Provider/ProviderDepartment.js";
import Patient from "../../../models/Patient/Patient.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import Provider from "../../../models/Provider/Provider.js";
import { isQueryParam, isQueryParamArray } from "../../../helpers/queryValidation.js";
import { sequelize } from "../../../config/db.js";
import SettingPos from "../../../models/Setting/PointOfService.js";

const getAllProviders = async (req, res) => {
  try {
    const appointments = await Appointment.findAll({
      attributes: [[sequelize.fn("DISTINCT", sequelize.col("provider_id")), "provider_id"]],
      where: {
        admin_id: req.user.admin_id,
      },
    });

    const providerIds = appointments.map((appointment) => appointment.provider_id);

    const providers = await Provider.findAll({
      attributes: ["id", "full_name"],
      where: {
        id: providerIds,
        admin_id: req.user.admin_id,
      },
    });

    return res.status(200).json(providers);
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const getAllPatients = async (req, res) => {
  try {
    const appointments = await Appointment.findAll({
      attributes: [[sequelize.fn("DISTINCT", sequelize.col("client_id")), "client_id"], "provider_id"],
      where: {
        provider_id: req.user.id,
        admin_id: req.user.admin_id,
      },
    });

    const clientIds = appointments.map((appointment) => appointment.client_id);

    const clients = await Patient.findAll({
      attributes: ["id", "client_full_name"],
      where: {
        id: clientIds,
        admin_id: req.user.admin_id,
      },
      order: [["client_full_name", "ASC"]],
    });

    return res.status(200).json(clients);
  } catch (error) {
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const getAllPos = async (req, res) => {
  try {
    const pos = await SettingPos.findAll({
      where: {
        admin_id: req.user.admin_id,
      },
    });

    return res.status(200).json(pos);
  } catch (error) {
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const getAllSessions = async (req, res) => {
  try {
    const adminId = req.user.admin_id;
    const providerId = req.user.id;

    const patient_ids = req.body.patient_ids;
    const provider_ids = req.body.provider_ids;
    const status = req.body.status;
    const billable = req.body.app_type_check;
    const notesAvail = req.body.notes_avail;
    const loadCheck = req.body.load_check;
    const start_date = req.body.start_date;
    const end_date = req.body.end_date;

    const supervisor = await ProviderDepartment.findOne({
      attributes: ["id", "is_supervisor"],
      where: {
        employee_id: req.user.id,
        is_supervisor: 1,
        admin_id: req.user.admin_id,
      },
    });

    let supervisorId = null;
    if (supervisor) {
      supervisorId = supervisor.id;
    }

    let searchParamsQuery = {};
    searchParamsQuery.admin_id = adminId;
    if (await isQueryParamArray(patient_ids)) {
      searchParamsQuery.client_id = {
        [Op.in]: patient_ids,
      };
    }

    if (await isQueryParamArray(provider_ids)) {
      searchParamsQuery.provider_id = {
        [Op.in]: provider_ids,
      };
    }

    if (await isQueryParamArray(status)) {
      searchParamsQuery.status = {
        [Op.in]: status,
      };
    }

    if ((await isQueryParam(start_date)) && (await isQueryParam(end_date))) {
      searchParamsQuery.schedule_date = {
        [Op.between]: [start_date, end_date],
      };
    }

    if (await isQueryParam(billable)) {
      searchParamsQuery.billable = {
        [Op.eq]: billable,
      };
    }

    //If no provider is selected, then show all sessions of the logged in provider
    if (provider_ids.length === 0) {
      searchParamsQuery.provider_id = {
        [Op.eq]: providerId,
      };
    }
    //Only show sessions which have the status is not deleted
    if (status.length === 0) {
      searchParamsQuery.status = {
        [Op.ne]: "deleted",
      };
    }

    console.log("Query", searchParamsQuery);

    let sessions = await Appointment.findAll({
      attributes: [
        "id",
        "admin_id",
        "is_locked",
        "billable",
        "client_id",
        "authorization_activity_id",
        "provider_id",
        "location",
        "schedule_date",
        "from_time",
        "to_time",
        "time_duration",
        "status",
        "rendered_at",
        "updated_at",
        "comment",
        "audit",
      ],
      where: searchParamsQuery,
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
        {
          model: PatientAuthorization,
          as: "app_auth",
          attributes: ["id", "admin_id", "authorization_name"],
        },
        {
          model: PatientAuthActivity,
          as: "app_activity",
          attributes: ["id", "admin_id", "activity_name"],
        },
        {
          model: Provider,
          as: "app_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
        // {
        //   model: SettingPos,
        //   as: "app_pos",
        //   attributes: ["id", "pos_name"],
        // },
      ],
      order: [["schedule_date", "DESC"]],
    });

    if (supervisor && supervisor.is_supervisor === 1) {
      const auths = await PatientAuthorization.findAll({
        attributes: ["id"],
        where: {
          supervisor_id: providerId,
          admin_id: adminId,
        },
      });

      if (auths.length > 0) {
        sessions = sessions.filter((session) => auths.some((auth) => auth.id === session.authorization_id) || session.provider_id === providerId);
      } else {
        sessions = sessions.filter((session) => session.provider_id === providerId);
      }
    } else {
      sessions = sessions.filter((session) => session.provider_id === providerId);
    }

    if (notesAvail === "2") {
      sessions = sessions.filter((session) => session.appNotes !== null);
    } else if (notesAvail === "3") {
      sessions = sessions.filter((session) => session.appNotes === null);
    }

    return res.status(200).json({ sessions });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Internal server error" });
  }
};

const monthlyUtilizationAndTotalUtilization = async (req, res) => {
  try {
    const appoientment = await Appointment.findAll({
      where: {
        id: req.body.sessionIds,
        admin_id: req.user.admin_id,
      },
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
      ],
    });

    return res.json({
      monthly_utilization: appoientment.reduce((acc, curr) => acc + curr.time_duration, 0),
      total_utilization: appoientment.reduce((acc, curr) => acc + curr.time_duration, 0),
      utilization: appoientment,
    });
  } catch (error) {
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const deleteSession = async (req, res) => {
  try {
    const updateApp = await Appointment.update(
      { status: "deleted" },
      {
        where: {
          id: req.body.sessionIds,
          admin_id: req.user.admin_id,
          is_locked: 0,
        },
      }
    );

    return res.send({
      success: true,
      msg: "Session deleted successfully",
      updateApp,
    });
  } catch (error) {
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

export default { getAllSessions, getAllProviders, getAllPatients, monthlyUtilizationAndTotalUtilization, deleteSession, getAllPos };
