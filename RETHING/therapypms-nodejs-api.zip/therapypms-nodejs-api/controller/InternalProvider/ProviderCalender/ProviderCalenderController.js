import { Op } from "sequelize";
import Appointment from "../../../models/Appointment/Appointment.js";
import PatientColors from "../../../models/Patient/PatientColors.js";
import Provider from "../../../models/Provider/Provider.js";
import Patient from "../../../models/Patient/Patient.js";
import SettingPos from "../../../models/Setting/PointOfService.js";
import moment from "moment";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";

// const getCalenderData = async (req, res, next) => {
//   try {
//     const get_start = req.query.start;
//     const get_end = req.query.end;

//     const seconds = Math.ceil(get_start / 1000);
//     const seconds2 = Math.ceil(get_end / 1000);

//     const data1 = new Date(seconds * 1000).toISOString().split("T")[0];
//     const data2 = new Date(seconds2 * 1000).toISOString().split("T")[0];

//     // const supervisor = await Employee_department.findOne({
//     //   attributes: ["id", "is_supervisor"],
//     //   where: {
//     //     employee_id: req.user.id,
//     //     is_supervisor: 1,
//     //     admin_id: req.user.admin_id,
//     //   },
//     // });

//     // let supervisorValue = null;
//     // if (supervisor) {
//     //   supervisorValue = 1;
//     // }

//     const settings = await general_setting.findOne({
//       attributes: ["client_initial"],
//       where: {
//         admin_id: req.user.admin_id,
//       },
//     });

//     const provider_id = req.user.id;

//     let apps = await Appointment.findAll({
//       attributes: [
//         "id",
//         "admin_id",
//         "authorization_activity_id",
//         "location",
//         "client_id",
//         "provider_id",
//         "from_time",
//         "to_time",
//         "status",
//         "activity_type",
//         "is_group",
//         "recurring_id",
//         "billable",
//       ],
//       include: [
//         { model: Client, as: "appClient", attributes: ["id", "client_first_name", "client_last_name", "client_full_name", "client_dob", "email"] },
//         { model: Employee, as: "appProvider" },
//       ],
//       where: {
//         admin_id: req.user.admin_id,
//         provider_id,
//         schedule_date: {
//           [Sequelize.Op.between]: [data1, data2],
//         },
//       },
//     });

//     const data = [];
//     for (const app of apps) {
//       const event = {};
//       const pro_name = (app.appProvider.last_name?.substring(0, 2) ?? "") + " " + (app.appProvider.first_name?.substring(0, 2) ?? "");
//       const client = await Client.findOne({
//         attributes: ["id", "client_first_name", "client_last_name", "client_full_name", "client_dob", "email"],
//         where: {
//           admin_id: req.user.admin_id,
//           id: app.client_id,
//         },
//       });

//       event.client_name = client?.client_full_name ?? "";
//       event.client_dob = client?.client_dob ?? "";
//       event.email = client?.email ?? "";
//       event.activity_type = app.activity_type ?? "";
//       event.from_time = app.from_time;
//       event.to_time = app.to_time;
//       const client_name =
//         settings.client_initial === 1
//           ? (app.appClient.client_last_name?.substring(0, 2) ?? "") + " " + (app.appClient.client_first_name?.substring(0, 2) ?? "")
//           : (app.appClient.client_last_name ?? "") + " " + (app.appClient.client_first_name ?? "");
//       const pos = await point_of_service.findOne({
//         attributes: ["is_tele"],
//         where: {
//           admin_id: req.user.admin_id,
//           pos_code: app.location,
//         },
//       });
//       const posValue = pos?.is_tele ?? 0;
//       const title = pro_name + ": " + client_name;

//       const client_color = await client_color.findOne({
//         where: {
//           provider_id,
//           client_id: app.client_id,
//         },
//       });
//       const bg_color = client_color?.back_color ?? "#E0EBF5";
//       const text_color = bg_color === "#E0EBF5" ? "#212529" : "#080808";

//       event.title = title;

//       if (posValue === 1) {
//         event.icon = "camera";
//       } else {
//         event.icon = "none";
//       }

//       if (app.comment) {
//         event.comment = "comment";
//       } else {
//         event.comment = "empty";
//       }

//       event.provider_name = req.user.full_name;
//       event.textColor = text_color;
//       event.backgroundColor = bg_color;

//       const cancelled = ["Cancelled by Provider", "Cancelled by Client", "CC more than 24 hrs", "CC less than 24 hrs"];
//       if (app.status === "Rendered") {
//         event.display = "block";
//       } else {
//         event.display = "list-item";
//       }

//       event.allDay = false;
//       event.start = new Date(app.from_time).toISOString();
//       event.end = new Date(app.to_time).toISOString();
//       event.status = app.status;
//       event.activity_type = app.activity_type;
//       event.is_group = app.is_group;
//       event.recurring_id = app.recurring_id;
//       event.billable = app.billable;
//       event.authorization_activity_id = app.authorization_activity_id;

//       if (app.from_time && app.to_time) {
//         event.cstm_deadline = new Date(app.to_time).toISOString().split("T")[0];
//       }

//       event.eventid = app.id;
//       event.id = app.id;

//       data.push(event);
//     }

//     res.json(data);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: "Internal server error" });
//   }
// };

const getCalenderData = async (req, res, next) => {
  try {
    const { start_date, end_date } = req.body;
    const providerId = req.user.id;

    const events = await Appointment.findAll({
      where: {
        admin_id: req.user.admin_id,
        provider_id: providerId,
        schedule_date: {
          [Op.between]: [start_date, end_date],
        },
      },
      raw: true, //This helps to manipulate the data and add new properties to data
    });

    let data = [];
    for (let event of events) {
      const client = await Patient.findOne({
        where: {
          id: event.client_id,
        },
      });

      const provider = await Provider.findOne({
        where: {
          id: providerId,
        },
      });

      const pos = await SettingPos.findOne({
        attributes: ["is_tele"],
        where: {
          admin_id: req.user.admin_id,
          pos_code: event.location,
        },
      });
      const posValue = pos?.is_tele ?? 0;
      if (posValue === 1) {
        event.icon = "camera";
      } else {
        event.icon = "none";
      }

      event.title = `${provider.last_name} ${provider.first_name[0]} : ${client.client_last_name?.slice(0, 2)} ${client.client_first_name?.slice(0, 2)}`;
      event.patientName = client.client_full_name;
      event.patientDOB = client.client_dob;
      event.patientEmail = client.email;
      event.providerName = provider?.full_name;

      let client_color = null;
      client_color = await PatientColors.findOne({
        where: {
          provider_id: providerId,
          client_id: event.client_id,
        },
      });

      const bg_color = client_color?.back_color && "#E0EBF5";
      const text_color = bg_color === "#E0EBF5" ? "#212529" : "#080808";
      event.textColor = text_color;
      event.backgroundColor = bg_color;

      if (event.comment) {
        event.comment = "comment";
      } else {
        event.comment = "empty";
      }

      if (event.status === "Rendered") {
        event.display = "block";
      } else {
        event.display = "list-item";
      }

      if (!event.is_all_day) {
        event.allDay = false;
        // This is the right way to format the date with time using moment As when i hit the api it gives me the the date with time in one format to achieve the format of DB i have to use moment
        event.start = moment(event.from_time).format("YYYY-MM-DDTHH:mm:ss");
        event.end = moment(event.to_time).format("YYYY-MM-DDTHH:mm:ss");
      } else {
        event.allDay = true;
        event.start = `${event.from_time}T12:00:00`;
        event.end = `${event.to_time}T23:59:00`;
      }

      if (event.from_time && event.to_time) {
        event.cstm_deadline = new Date(event.to_time).toISOString().split("T")[0];
      }

      event.eventid = event.id;
      event.start_time = moment(event.from_time).format("hh:mm A");
      event.end_time = moment(event.to_time).format("hh:mm A");

      data.push(event);
    }
    // console.log(data);
    res.status(200).json({
      message: "success",
      data: events,
    });
  } catch (error) {
    console.log(error.message);
    return res.status(500).send("Server error");
  }
};

const singleEventDetails = async (req, res, next) => {
  try {
    const { appointment_id } = req.body;
    const singleAppointment = await Appointment.findOne({
      where: {
        admin_id: req.user.admin_id,
        id: appointment_id,
      },
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
        {
          model: PatientAuthorization,
          as: "app_auth",
          attributes: ["id", "admin_id", "authorization_name"],
        },
        {
          model: PatientAuthActivity,
          as: "app_activity",
          attributes: ["id", "admin_id", "activity_name"],
        },
        {
          model: Provider,
          as: "app_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
        {
          model: SettingPos,
          as: "app_pos",
          attributes: ["id", "pos_code", "pos_name"],
        },
      ],
    });

    res.json({
      status: "success",
      message: "calender appointment single session",
      data: singleAppointment,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

export default {
  getCalenderData,
  singleEventDetails,
};
