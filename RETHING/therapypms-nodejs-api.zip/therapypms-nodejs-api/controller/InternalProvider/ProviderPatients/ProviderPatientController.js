import { getPagination, getPagingData } from "../../../helpers/pagination.js";
import Patient from "../../../models/Patient/Patient.js";
import PatientActivity from "../../../models/Patient/PatientActivity.js";
import PatientAddress from "../../../models/Patient/PatientAddress.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import PatientCallLog from "../../../models/Patient/PatientCallLog.js";
import PatientDocument from "../../../models/Patient/PatientDocument.js";
import PatientEmail from "../../../models/Patient/PatientEmail.js";
import PatientGurantorInfo from "../../../models/Patient/PatientGurantorInfo.js";
import PatientInfo from "../../../models/Patient/PatientInfo.js";
import PatientPhone from "../../../models/Patient/PatientPhone.js";
import AllSubActivity from "../../../models/Setting/AllSubActivity.js";
import PayorFacility from "../../../models/Setting/PayorFacility.js";
import ReferringProvider from "../../../models/Setting/RenderingProvider.js";
import SettingCptCode from "../../../models/Setting/SettingCptCode.js";
import SettingNameLocationBoxTwo from "../../../models/Setting/SettingNameLocationBoxTwo.js";
import ZoneSetup from "../../../models/Setting/ZoneSetup.js";

const patientList = async (req, res, next) => {
  try {
    const { page } = req.body;
    const { perPage, offset } = getPagination(page);

    const patientList = await Patient.findAndCountAll({
      where: {
        admin_id: req.user.admin_id,
      },
      order: [["client_full_name", "ASC"]],
      limit: perPage,
      offset,
    });

    res.json({
      status: "success",
      message: "Patient List",
      data: getPagingData(patientList, page, perPage),
    });
  } catch (e) {
    console.log(e.message);
    res.status(500).send("Server error");
  }
};

const patientInformation = async (req, res, next) => {
  try {
    const { patient_id } = req.body;
    const client = await Patient.findOne({
      where: {
        id: patient_id,
        admin_id: req.user.admin_id,
      },
    });

    const phones = await PatientPhone.findAll({
      where: {
        client_id: patient_id,
        admin_id: req.user.admin_id,
      },
    });

    const emails = await PatientEmail.findAll({
      where: {
        client_id: patient_id,
        admin_id: req.user.admin_id,
      },
    });

    const address = await PatientAddress.findAll({
      where: {
        client_id: patient_id,
        admin_id: req.user.admin_id,
      },
    });

    const allZone = await ZoneSetup.findAll();

    const renProviders = await ReferringProvider.findAll({
      where: {
        admin_id: req.user.admin_id,
      },
    });

    let clientInfo = await PatientInfo.findOne({
      where: {
        client_id: patient_id,
        admin_id: req.user.admin_id,
      },
    });

    if (!clientInfo) {
      clientInfo = await PatientInfo.create({
        client_id: client.id,
        admin_id: req.user.admin_id,
      });
    }

    const guarantorInfoInstance = await PatientGurantorInfo.findOne({
      where: {
        client_id: patient_id,
        admin_id: req.user.admin_id,
      },
    });

    let guarantorInfo;
    if (guarantorInfoInstance) {
      guarantorInfo = guarantorInfoInstance;
    } else {
      const lastRecord = await PatientGurantorInfo.findOne({
        order: [["id", "DESC"]],
      });
      guarantorInfo = await PatientGurantorInfo.create({
        id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
        client_id: patient_id,
        admin_id: req.user.admin_id,
        // is_up_admin: req.user.is_up_admin == 1 ? 1 : 2,
        // down_admin_id: req.user.is_up_admin == 1 ? 0 : req.user.admin_id,
      });
    }

    const box32 = await SettingNameLocationBoxTwo.findAll({
      where: {
        admin_id: req.user.admin_id,
      },
    });

    res.status(200).json({
      status: "success",
      message: "patient info get",
      client_info: client,
      client_other_info: clientInfo,
      phones: phones,
      emails: emails,
      address: address,
      guarantor_info: guarantorInfo,
      all_zone: allZone,
      box_32: box32,
      ren_providers: renProviders,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send("Server error");
  }
};

const patientInfoUpdate = async (req, res, next) => {
  try {
    const {
      client_edit_id,
      client_first_name,
      client_middle,
      client_last_name,
      client_preferred,
      client_phone,
      client_phone_type,
      is_voice_sms,
      is_send_sms,
      client_email,
      client_email_type,
      email_reminder,
      is_email_ok,
      client_dob,
      client_gender,
      client_street,
      client_city,
      client_state,
      client_zip,
      location,
      zone,
      is_active_client,
      client_gender_identity,
      client_relationship,
      client_employe_status,
      race_ethnicity,
      race_ethnicity_details,
      preferred_language,
      client_notes,
      client_date_first_seen,
      client_reffered_by,
      relationship,
      asignment,
      phy_type,
      is_guarantor,
      guarantor_first_name,
      guarantor_last_name,
    } = req.body;

    // Basic Patient Info Update
    const patientInstance = await Patient.findOne({
      where: {
        id: client_edit_id,
        admin_id: req.user.admin_id,
      },
    });

    patientInstance.is_active_client = is_active_client;
    patientInstance.client_full_name = `${client_first_name} ${client_middle} ${client_last_name}`;
    patientInstance.client_first_name = client_first_name;
    patientInstance.client_middle = client_middle;
    patientInstance.client_last_name = client_last_name;
    patientInstance.client_preferred = client_preferred;
    patientInstance.phone_number = client_phone;
    patientInstance.phone_type = client_phone_type;
    patientInstance.is_voice_sms = is_voice_sms;
    patientInstance.is_send_sms = is_send_sms;
    patientInstance.email = client_email;
    patientInstance.email_type = client_email_type;
    patientInstance.email_reminder = email_reminder;
    patientInstance.is_email_ok = is_email_ok;
    patientInstance.client_dob = format(parseISO(client_dob), "yyyy-MM-dd");
    patientInstance.client_gender = client_gender;
    patientInstance.client_street = client_street;
    patientInstance.client_city = client_city;
    patientInstance.client_state = client_state;
    patientInstance.client_zip = client_zip;
    patientInstance.location = location;
    patientInstance.zone = zone;
    await patientInstance.save();

    // Other Patient Info Update
    const patientInfoInstance = await patientInfo.findOne({
      where: {
        client_id: client_edit_id,
        admin_id: req.user.admin_id,
      },
    });

    patientInfoInstance.is_active_client = is_active_client;
    patientInfoInstance.client_gender_identity = client_gender_identity;
    patientInfoInstance.client_relationship = client_relationship;
    patientInfoInstance.client_employe_status = client_employe_status;
    patientInfoInstance.race_ethnicity = race_ethnicity;
    patientInfoInstance.race_ethnicity_details = race_ethnicity_details;
    patientInfoInstance.preferred_language = preferred_language;
    patientInfoInstance.client_notes = client_notes;
    patientInfoInstance.client_date_first_seen = format(parseISO(client_date_first_seen), "yyyy-MM-dd");
    patientInfoInstance.client_reffered_by = client_reffered_by;
    patientInfoInstance.relationship = relationship;
    patientInfoInstance.asignment = asignment;
    patientInfoInstance.phy_type = phy_type;
    patientInfoInstance.is_guarantor = is_guarantor;

    await patientInfoInstance.save();

    // Guarantor Info Update
    const guarantorInfoInstance = await PatientGurantorInfo.findOne({
      where: {
        client_id: client_edit_id,
        admin_id: req.user.admin_id,
      },
    });
    guarantorInfoInstance.guarantor_first_name = request.guarantor_first_name;
    guarantorInfoInstance.guarantor_last_name = request.guarantor_last_name;
    guarantorInfoInstance.guarantor_relationship = request.guarantor_relationship;
    guarantorInfoInstance.guarantor_dob = moment(request.guarantor_dob).format("YYYY-MM-DD");
    guarantorInfoInstance.g_street = request.g_street;
    guarantorInfoInstance.g_city = request.g_city;
    guarantorInfoInstance.g_state = request.g_state;
    guarantorInfoInstance.g_zip = request.g_zip;

    await guarantorInfoInstance.save();
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

//=========================Patient Authorization===========================

const patientAuthList = async (req, res, next) => {
  try {
    const id = req.body.patient_id;
    const patient = await Patient.findOne({ where: { id, admin_id: req.user.admin_id } });
    const allAuthorization = await PatientAuthorization.findAll({
      where: { client_id: id, admin_id: req.user.admin_id },
      order: [["id", "DESC"]],
    });
    const selectedPayors = await PayorFacility.findAll({
      where: { admin_id: req.user.admin_id },
      attributes: ["id", "payor_id", "payor_name"],
    });
    const allSubActivity = await AllSubActivity.findAll({
      where: { admin_id: req.user.admin_id },
      order: [["sub_activity", "ASC"]],
    });
    const cptCodes = await SettingCptCode.findAll({
      where: {
        admin_id: req.user.admin_id,
      },
    });
    return res.status(200).json({
      message: "success",
      patient,
      allAuthorization,
      selectedPayors,
      allSubActivity,
      cptCodes,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
};

//===============Patient Auth Activity=================
const patientAuthActList = async (req, res, next) => {
  try {
    const { authorization_id } = req.body;
    const authActivity = await PatientAuthActivity.findAll({
      where: { authorization_id, admin_id: req.user.admin_id },
      order: [["id", "desc"]],
    });

    return res.status(200).json({
      message: "success",
      patientActivities: authActivity,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send("Internal Server Error");
  }
};

//===================Patient Documents===================
const patientDocuments = async (req, res, next) => {
  try {
    const { id } = req.body;

    const patient = await Patient.findOne({
      where: {
        id,
        admin_id: req.user.admin_id,
      },
    });

    const documents = await PatientDocument.findAll({
      where: {
        client_id: id,
        admin_id: req.user.admin_id,
      },
      order: [["id", "DESC"]],
      limit: 10,
    });

    res.status(200).json({
      status: "success",
      message: "patient documents get",
      patient,
      documents,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const patientDocumentSave = async (req, res) => {
  try {
    const { client_id, description, exp_date } = req.body;

    const clientDocument = new PatientDocument();
    if (req.file) {
      const image = req.file;
      const name = image.originalname;
      const tempName = `${Date.now()}${Math.floor(Math.random() * 90) + 10}${name}`;
      const uploadPath = "assets/dashboard/documents/";
      const filePath = path.join(uploadPath, name);
      const tempFilePath = path.join(uploadPath, tempName);

      await image.mv(tempFilePath);
      clientDocument.file_name = filePath;
      clientDocument.file_name_temp = tempFilePath;
    }

    clientDocument.admin_id = req.user.admin_id;
    clientDocument.is_up_admin = 0;
    clientDocument.down_admin_id = 0;
    clientDocument.client_id = client_id;
    clientDocument.description = description;
    clientDocument.exp_date = exp_date;
    // clientDocument.created_by = Auth.user().full_name;
    clientDocument.created_by = null;
    await clientDocument.save();

    await PatientActivity.create({
      admin_id: req.user.admin_id,
      client_id: clientDocument.client_id,
      title: "Client Document Deleted",
      message: "Client Document Created",
      act_date: new Date().toISOString(),
    });

    return res.status(200).json({
      status: "success",
      message: "Document uploaded successfully",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

//===============Patient Calllog=================
const patientCalllog = async (req, res, next) => {
  try {
    const { id } = req.params;
    const admin_id = req.user.admin_id;

    const logs = await PatientCallLog.findAll({
      where: {
        admin_id: req.user.admin_id,
        client_id: id,
      },
    });

    const patient = await Patient.findOne({
      where: {
        id,
        admin_id: req.user.admin_id,
      },
    });

    return res.status(200).json({
      message: "success",
      logs,
      patient,
    });
  } catch (error) {
    console.error(error);
    return res.redirect("back").with("error", "Failed to retrieve client call logs");
  }
};

export default {
  patientList,
  patientInformation,
  patientInfoUpdate,
  patientAuthList,
  patientAuthActList,
  patientDocuments,
  patientDocumentSave,
  patientCalllog,
};
