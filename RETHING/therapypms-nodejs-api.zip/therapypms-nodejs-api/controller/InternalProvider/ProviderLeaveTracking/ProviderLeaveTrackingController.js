// --------------------------leave tracking------------------

import ProviderLeave from "../../../models/Provider/ProviderLeave.js";
import HolidaySetup from "../../../models/Setting/HolidaySetup.js";

const get_provider_leave_tracking = async (req, res) => {
    // const { employee_id } = req.body;
    try {
        const employee_leave = await ProviderLeave.findAll({
            where: {
                admin_id: req.user.admin_id,
                employee_id: req.user.id,
            },
        });
        return res.status(200).json({
            status: "success",
            message: "Staff get all leave tracking",
            leave_list: employee_leave,
        });
    } catch (err) {
        console.log(err);
        return res.status(500).json({
            status: "error",
            message: "Server error",
            e: err,
        });
    }
};

const providerLeaveTrackingSave = async (req, res) => {
    const leave_date = new Date(req.body.leave_date);
    const formatted_leave_date = leave_date.toISOString().slice(0, 10);

    const check1 = await ProviderLeave.findOne({
        where: {
            admin_id: req.user.admin_id,
            employee_id: req.user.id,
            leave_date: formatted_leave_date,
        },
    });

    const check2 = await HolidaySetup.findOne({
        where: {
            admin_id: req.user.admin_id,
            holiday_date: formatted_leave_date,
        },
    });

    if (check1) {
        return res.status(400).json({
            status: "error",
            message: "Leave already exists",
        });
    } else if (check2) {
        return res.status(400).json({
            status: "error",
            message: "Leave is under holiday",
        });
    }

    const lastRecord = await ProviderLeave.findOne({
        order: [["id", "DESC"]],
    });

    const new_leave = await ProviderLeave.create({
        id: lastRecord ? parseInt(lastRecord.id) + 1 : 1,
        admin_id: req.user.admin_id,
        employee_id: req.user.id,
        leave_date: formatted_leave_date,
        description: req.body.desc,
    });

    return res.status(200).json({
        status: "success",
        message: "Staff leave successfully created",
        leave: new_leave,
    });
};

// providerLeaveTrackingDelete
const providerLeaveTrackingDelete = async (req, res) => {
    try {
        const delPayor = await ProviderLeave.findOne({
            where: { id: req.body.del_id, admin_id: req.user.admin_id, employee_id: req.user.id },
        });
        console.log(delPayor);

        if (delPayor) {
            await delPayor.destroy();
        }

        res.status(200).json({
            status: "success",
            message: "Staff payor exclusion successfully deleted",
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ status: "error", message: "Something went wrong" });
    }
};



export default { get_provider_leave_tracking, providerLeaveTrackingDelete, providerLeaveTrackingSave }