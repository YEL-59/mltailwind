import { Op } from "sequelize";
import ProviderClockIn from "../../../models/Provider/ProviderClockIn.js";
import PayPeriod from "../../../models/Setting/PayPeriod.js";
import moment from "moment/moment.js";

const punch = async (req, res, next) => {
  try {
    const { punch_check, current_time, current_date } = req.body;
    const dateObj = `${current_date} ${current_time}`;

    const formattedDateTime = dateObj
      .toLocaleString("UTC", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" })
      .replace(/\//g, "-");

    if (punch_check === "found") {
      const currentPunch = await ProviderClockIn.findOne({
        where: {
          provider_id: req.user.id,
          punch_date: current_date,
          status: null,
        },
        order: [["createdAt", "DESC"]],
      });

      if (currentPunch) {
        currentPunch.time_out = formattedDateTime;
        currentPunch.status = 1;
        await currentPunch.save();
      }
    } else {
      const newPunch = await ProviderClockIn.create({
        admin_id: req.user.admin_id,
        provider_id: req.user.id,
        time_in: formattedDateTime,
        punch_date: current_date,
      });
    }

    res.status(200).send({
      message: "Success",
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const clockInTimeGet = async (req, res, next) => {
  try {
    //todays date
    const today = new Date();
    const clockInOrOut = await ProviderClockIn.findOne({
      where: {
        provider_id: req.user.id,
        punch_date: today,
      },
      order: [["createdAt", "DESC"]],
    });

    return res.status(200).json(clockInOrOut);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Failed to retrieve pay periods" });
  }
};

const fetchClockInReq = async (req, res, next) => {
  try {
    const payData = await PayPeriod.findOne({
      attributes: ["id", "admin_id", "start_date", "end_date"],
      where: {
        id: req.body.period,
        admin_id: req.user.admin_id,
      },
    });

    const times = await ProviderClockIn.findAll({
      where: {
        admin_id: req.user.admin_id,
        punch_date: {
          [Op.between]: [payData.start_date, payData.end_date],
        },
      },
      order: [["punch_date", "ASC"]],
    });

    let currentDate = moment(payData.start_date);
    const endDate = moment(payData.end_date);
    while (currentDate <= endDate) {
      //console.log("Times ===>", currentDate);
      let found = false;
      for (const time of times) {
        if (moment(time.punch_date).format("Y-MM-DD") === currentDate.format("Y-MM-DD")) {
          found = true;
          break;
        }
      }
      if (!found) {
        const missingData = {
          admin_id: req.user.admin_id,
          provider_id: req.user.id,
          punch_date: currentDate.format("Y-MM-DD"),
          time_in: null,
          time_out: null,
          pass: null,
          no_entry: true,
          note: null,
        };
        times.push(missingData);
      }
      currentDate.add(1, "day");
    }
    times.sort((a, b) => moment(a.punch_date).diff(moment(b.punch_date)));

    res.status(200).json(times);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};

const addClockInManually = async (req, res, next) => {
  try {
    let newClockLog;
    let msg;
    const inTime = moment.utc(`${req.body.clockin_date} ${req.body.clockin_start_time}`, "YYYY-MM-DD HH:mm:ss");
    // const inTime = `${req.body.clockin_date} ${req.body.clockin_start_time}`
    //   .toLocaleString("en-US", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" })
    //   .replace(/\//g, "-");

    const outTime = moment.utc(`${req.body.clockin_date} ${req.body.clockin_end_time}`, "YYYY-MM-DD HH:mm:ss");
    // const outTime = `${req.body.clockin_date} ${req.body.clockin_end_time}`
    //   .toLocaleString("en-US", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" })
    //   .replace(/\//g, "-");

    if (req.body.id) {
      msg = "Successfully Clock log Updated";
      newClockLog = await ProviderClockIn.findByPk(req.body.id);
    } else {
      msg = "Successfully Clock log Added";
      newClockLog = await ProviderClockIn.build();
    }

    newClockLog.admin_id = req.user.admin_id;
    newClockLog.provider_id = req.user.id;
    newClockLog.time_in = inTime;
    newClockLog.punch_date = req.body.clockin_date;
    newClockLog.time_out = outTime;
    newClockLog.note = req.body.clockin_note;

    await newClockLog.save();

    res.status(200).json({ message: msg });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};

export default { punch, clockInTimeGet, fetchClockInReq, addClockInManually };
