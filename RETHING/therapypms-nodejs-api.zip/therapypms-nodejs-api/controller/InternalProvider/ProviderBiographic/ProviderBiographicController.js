import Provider from "../../../models/Provider/Provider.js";
import EmployeeTypeAssign from "../../../models/Setting/EmployeeTypeAssign.js";
import TreatmentFacility from "../../../models/Setting/TreatmentFacility.js";

const providerInfo = async (req, res) => {
    // res.send("hello")
    try {
        const employee = await Provider.findOne({
            where: {
                id: req.user.id,
                admin_id: req.user.admin_id
            }
        });

        const assignType = await EmployeeTypeAssign.findAll({
            where: {
                admin_id: req.user.admin_id
            }
        });

        const txTypes = await TreatmentFacility.findAll({
            where: {
                admin_id: req.user.admin_id
            }
        });

        res.status(200).json({ employee, assignType, txTypes });
    } catch (error) {
        console.error(error);
        res.status(500).json({ e: error });
    }
};



const providerInfoUpdate = async (req, res) => {
    try {
        const employeeBioUpdate = await Provider.findOne({
            where: {
                id: req.user.id,
                admin_id: req.user.admin_id,
            },
        });

        //   if (req.file) {
        //     const ext = req.file.extension;
        //     const imageName = `${Date.now()}${Math.random().toString(36).substring(2)}.${ext}`;
        //     const directory = 'assets/profile/';
        //     const imgUrl = directory + imageName;
        //     // Save the file and update the profile_photo field
        //     // Replace this code with your logic to save the image
        //     // e.g., using a file storage service or copying to a specific location
        //     // Image::make($image)->save($imgUrl);
        //     employeeBioUpdate.profile_photo = imgUrl;
        //   }

        // Update other fields
        employeeBioUpdate.first_name = req.body.first_name;
        employeeBioUpdate.middle_name = req.body.middle_name;
        employeeBioUpdate.last_name = req.body.last_name;
        employeeBioUpdate.full_name = `${req.body.first_name} ${req.body.middle_name} ${req.body.last_name}`;
        employeeBioUpdate.nickname = req.body.nickname;
        employeeBioUpdate.staff_birthday = req.body.staff_birthday;
        employeeBioUpdate.ssn = req.body.ssn;
        employeeBioUpdate.staff_other_id = req.body.staff_other_id;
        employeeBioUpdate.office_phone = req.body.office_phone;
        employeeBioUpdate.office_fax = req.body.office_fax;
        employeeBioUpdate.office_email = req.body.office_email;
        employeeBioUpdate.driver_license = req.body.driver_license;
        employeeBioUpdate.license_exp_date = req.body.license_exp_date;
        employeeBioUpdate.title = req.body.title;
        employeeBioUpdate.hir_date_compnay = req.body.hir_date_compnay;
        employeeBioUpdate.credential_type = req.body.credential_type;
        employeeBioUpdate.treatment_type = req.body.treatment_type;
        employeeBioUpdate.individual_npi = req.body.individual_npi;
        employeeBioUpdate.caqh_id = req.body.caqh_id;
        employeeBioUpdate.service_area_zip = req.body.service_area_zip;
        employeeBioUpdate.terminated_date = req.body.terminated_date;
        employeeBioUpdate.language = req.body.language;
        employeeBioUpdate.taxonomy_code = req.body.taxonomy_code;
        employeeBioUpdate.gender = req.body.gender;
        employeeBioUpdate.military_service = req.body.military_service;
        employeeBioUpdate.therapist_bill = req.body.therapist_bill;
        employeeBioUpdate.is_staff_active = req.body.is_staff_active;
        employeeBioUpdate.enable_fource_creation = req.body.enable_fource_creation;
        employeeBioUpdate.has_catalsty_access = req.body.has_catalsty_access;
        employeeBioUpdate.notes = req.body.notes;
        employeeBioUpdate.timezone = req.body.default_tz;
        await employeeBioUpdate.save();

        return res.status(200).json({ success: true, message: 'Biographic Successfully Updated' });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};





export default { providerInfo, providerInfoUpdate }
