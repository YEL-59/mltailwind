import { Op, Sequelize } from "sequelize";
import { sequelize } from "../../../config/db.js";
import Provider from "../../../models/Provider/Provider.js";
import PayPeriod from "../../../models/Setting/PayPeriod.js";
import Appointment from "../../../models/Appointment/Appointment.js";
import TimeSheet from "../../../models/Payment/TimeSheet.js";

const payrollPayTimeGet = async (req, res, next) => {
  try {
    const payPeriods = await PayPeriod.findAll({
      attributes: ["id", "start_date", "end_date"],
      where: {
        admin_id: req.user.admin_id,
      },
    });

    return res.status(200).json(payPeriods);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Failed to retrieve pay periods" });
  }
};

const payrollTimesheetAppoinment = async (req, res) => {
  try {
    const payData = await PayPeriod.findOne({
      attributes: ["id", "start_date", "end_date"],
      where: {
        id: req.body.pay_id,
        admin_id: req.user.admin_id,
      },
    });

    //const povid = [Auth.user().id]; // Assuming you have the Auth user available
    const povid = [req.user.id];

    let query = `SELECT timesheets.*, employees.full_name, clients.client_full_name AS patientName,
client_authorization_activities.activity_name AS serviceName
      FROM timesheets 

      LEFT JOIN employees ON timesheets.provider_id = employees.id 
      LEFT JOIN clients ON timesheets.client_id = clients.id
      LEFT JOIN client_authorization_activities ON timesheets.activity_id = client_authorization_activities.id

      WHERE timesheets.admin_id = ${req.user.admin_id} 
      AND timesheets.is_del = 1 
      AND timesheets.status <> 'Completed' 
      AND timesheets.provider_id IN ('${povid.join("','")}')`;

    if (payData) {
      query += ` AND timesheets.schedule_date >= '${payData.start_date}' 
        AND timesheets.schedule_date <= '${payData.end_date}'`;
    }
    if (req.body.status !== 0) {
      query += ` AND timesheets.submitted = ${req.body.status}`;
    }

    query += ` ORDER BY employees.full_name ASC, timesheets.schedule_date ASC`;

    let payrollData = await sequelize.query(query, { type: Sequelize.QueryTypes.SELECT });

    return res.status(200).json({
      payData,
      payrollData,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Failed to retrieve pay periods" });
  }
};


const payrollTimeSheetChangeSave = async (req, res, next) => {
  try {
    const { pay_id, edit_id, miles, timein_one, timein_two, timein_three, timeout_one, timeout_two, timeout_three } = req.body;
    console.log(pay_id);
    const payData = await PayPeriod.findOne({
      attributes: ["id", "time_sheet_date"],
      where: {
        id: pay_id,
        admin_id: req.user.admin_id,
      },
    });

    const currentDate = new Date();

    for (let i = 0; i < edit_id.length; i++) {
      const sheet = await TimeSheet.findOne({
        where: {
          id: edit_id[i],
          admin_id: req.user.admin_id,
        },
      });

      if (payData.time_sheet_date < currentDate) {
        return res.status(400).json("expired");
      }

      sheet.timein_one = timein_one[i] || null;
      sheet.timein_two = timein_two[i] || null;
      sheet.timein_three = timein_three[i] || null;
      sheet.timeout_one = timeout_one[i] || null;
      sheet.timeout_two = timeout_two[i] || null;
      sheet.timeout_three = timeout_three[i] || null;
      sheet.miles = miles[i] || null;

      await sheet.save();
    }

    return res.status(200).json("done");
  } catch (error) {
    console.error(error);
    return res.status(500).json("error");
  }
};

export default {
  payrollPayTimeGet,
  payrollTimesheetAppoinment,
  payrollTimeSheetChangeSave,
};
