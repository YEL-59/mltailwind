import { sequelize } from "../../../config/db.js";
import DepositApplyTransaction from "../../../models/Patient/DepositApplyTransactions.js";
import Patient from "../../../models/Patient/Patient.js";
import PatientStatement from "../../../models/Patient/PatientStatement.js";
import { Op } from "sequelize";

const patientMyStatement = async (req, res, next) => {
  try {
    const patients = await Patient.findOne({
      where: {
        id: req.user.id,
        admin_id: req.user.admin_id,
      },
    });

    const statements = await PatientStatement.findAll({
      where: {
        client_id: req.user.id,
        admin_id: req.user.admin_id,
        is_paid: 0,
        is_submit: 1,
      },
      attributes: [
        [sequelize.fn("sum", sequelize.col("co_pay")), "copay"],
        [sequelize.fn("sum", sequelize.col("coins")), "cocoind"],
        [sequelize.fn("sum", sequelize.col("ded")), "ded"],
      ],
    });

    const { copay, cocoind, ded } = statements[0].dataValues;
    const totalSum = copay + cocoind - ded;

    return res.status(200).json({ patients, statements, totalSum });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

const patientMyStatementPaid = async (req, res, next) => {
  try {
    const patientStatements = await PatientStatement.findAll({
      where: {
        client_id: req.user.id,
        admin_id: req.user.admin_id,
        is_submit: 1,
        is_paid: 1,
      },
    });

    res.status(200).json({
      message: "success",
      paidData: patientStatements,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

const patientMyStatementUnpaid = async (req, res, next) => {
  try {
    const client_statements = await PatientStatement.findAll({
      where: {
        client_id: req.user.id,
        admin_id: req.user.admin_id,
        is_submit: 1,
        is_paid: 0,
      },
    });

    res.status(200).json({
      message: "success",
      unpaidData: client_statements,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

const patientMyStatementGetData = async (req, res, next) => {
  try {
    const data = await PatientStatement.findAll({
      attributes: ["deposit_apply_id"],
      where: {
        client_id: req.user.id,
        admin_id: req.user.admin_id,
        is_submit: 1,
        is_paid: 1,
      },
    });

    const depIds = [];
    for (const dat of data) {
      const dep = await DepositApplyTransaction.findOne({
        attributes: ["deposit_apply_id", "status"],
        where: {
          deposit_apply_id: dat.deposit_apply_id,
          client_id: req.user.id,
          admin_id: req.user.admin_id,
          status: {
            [Op.or]: ["PR CoIns", "PR Copay", "PR Ded"],
          },
        },
      });

      if (dep) {
        depIds.push(dep.deposit_apply_id);
      }
    }

    const clientStatements = await PatientStatement.findAll({
      where: {
        deposit_apply_id: {
          [Op.in]: depIds,
        },
        client_id: req.user.id,
        admin_id: req.user.admin_id,
      },
    });

    return res.status(200).json({
      message: "success",
      clientStatements,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

export default {
  patientMyStatement,
  patientMyStatementPaid,
  patientMyStatementUnpaid,
  patientMyStatementGetData,
};
