import { Op } from "sequelize";
import Appointment from "../../../models/Appointment/Appointment.js";
import Patient from "../../../models/Patient/Patient.js";
import Provider from "../../../models/Provider/Provider.js";
import PatientColors from "../../../models/Patient/PatientColors.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import moment from "moment";

const myCalenderGetData = async (req, res, next) => {
  try {
    const { start_date, end_date } = req.body;

    const events = await Appointment.findAll({
      where: {
        client_id: req.user.id,
        schedule_date: {
          [Op.between]: [start_date, end_date],
        },
      },
      raw: true, //This helps to manipulate the data and add new properties to data
    });

    let data = [];
    for (let event of events) {
      const client = await Patient.findOne({
        where: {
          id: event.client_id,
        },
      });

      let provider;
      if (event?.provider_id) {
        provider = await Provider.findOne({
          where: {
            id: event.provider_id,
          },
        });
      }
      event.patientName = client.client_full_name;
      event.patientDOB = client.client_dob;
      event.patientEmail = client.email;
      event.providerName = provider?.full_name;

      //   event.title = "shaik";
      //   event.start = "2021-09-01T12:00:00";
      //   data.push(event);

      let client_name = "";
      let client_color = null;

      if (provider) {
        client_name = `${provider.last_name} ${provider.first_name[0]} : ${client.client_last_name.slice(0, 2)} ${client.client_first_name.slice(0, 2)}`;
        client_color = await PatientColors.findOne({
          where: {
            client_id: client.id,
          },
        });
      } else {
        client_name = `${client.client_last_name} ${client.client_first_name[0]}`;
      }

      if (!event.is_all_day) {
        event.allDay = false;
        event.start = moment(event.from_time).format("YYYY-MM-DDTHH:mm:ss");
        event.end = moment(event.to_time).format("YYYY-MM-DDTHH:mm:ss");
      } else {
        event.allDay = true;
        event.start = `${event.from_time}T12:00:00`;
        event.end = `${event.to_time}T23:59:00`;
      }

      if (event.from_time && event.to_time) {
        event.cstm_deadline = new Date(event.to_time).toISOString().split("T")[0];
      }

      event.eventid = event.id;
      event.start_time = moment(event.from_time).format("hh:mm A");
      event.end_time = moment(event.to_time).format("hh:mm A");
      event.title = client_name;

      if (client_color) {
        if (client_color.back_color) {
          event.textColor = "#212529";
          event.backgroundColor = client_color.back_color;
          event.display = "block";
        } else {
          event.textColor = "#212529";
          event.eventBackgroundColor = "#E0EBF5";
          event.display = "block";
        }
      } else {
        event.textColor = "#212529";
        event.eventBackgroundColor = "#E0EBF5";
        event.display = "block";
      }

      data.push(event);
    }
    // console.log(data);
    res.status(200).json({
      message: "success",
      data: data,
    });
  } catch (error) {
    console.log(error.message);
    return res.status(500).send("Server error");
  }
};

const calenderSingleSession = async (req, res, next) => {
  try {
    const { appointment_id } = req.body;
    const single_appointment = await Appointment.findOne({
      where: {
        admin_id: req.user.admin_id,
        client_id: req.user.id,
        id: appointment_id,
      },
      include: [
        {
          model: Patient,
          as: "app_patient",
          attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
        },
        {
          model: PatientAuthorization,
          as: "app_auth",
          attributes: ["id", "admin_id", "authorization_name"],
        },
        {
          model: PatientAuthActivity,
          as: "app_activity",
          attributes: ["id", "admin_id", "activity_name"],
        },
        {
          model: Provider,
          as: "app_provider",
          attributes: ["id", "admin_id", "first_name", "middle_name", "last_name", "full_name"],
        },
      ],
    });

    res.json({
      status: "success",
      message: "calender appointment single",
      data: single_appointment,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};

export default {
  myCalenderGetData,
  calenderSingleSession,
};
