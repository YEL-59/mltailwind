import Patient from "../../../models/Patient/Patient.js";
import PatientAuthActivity from "../../../models/Patient/PatientAuthActivity.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";
import AllSubActivity from "../../../models/Setting/AllSubActivity.js";
import SettingCptCode from "../../../models/Setting/SettingCptCode.js";

const myAuthorizations = async (req, res, next) => {
  try {
    const patientInfo = await Patient.findOne({
      where: {
        id: req.user.id,
        admin_id: req.user.admin_id,
      },
    });

    const allAuthorizations = await PatientAuthorization.findAll({
      where: {
        client_id: req.user.id,
        admin_id: req.user.admin_id,
      },
      order: [["id", "desc"]],
    });

    const cptCodes = await SettingCptCode.findAll({
      where: {
        admin_id: req.user.admin_id,
      },
    });

    const allSubActivities = await AllSubActivity.findAll({
      where: {
        admin_id: req.user.admin_id,
      },
    });

    res.status(200).json({
      message: "success",
      patientInfo,
      allAuthorizations,
      cptCodes,
      allSubActivities,
    });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const authActivities = async (req, res, next) => {
  try {
    const act = await PatientAuthActivity.findAll({
      where: {
        authorization_id: req.body.authId,
      },
    });

    res.status(200).json({
      message: "success",
      act,
    });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export default { myAuthorizations, authActivities };
