import Patient from "../../../models/Patient/Patient.js";
import PatientAddress from "../../../models/Patient/PatientAddress.js";
import PatientEmail from "../../../models/Patient/PatientEmail.js";
import PatientGurantorInfo from "../../../models/Patient/PatientGurantorInfo.js";
import PatientInfo from "../../../models/Patient/PatientInfo.js";
import PatientPhone from "../../../models/Patient/PatientPhone.js";
import ReferringProvider from "../../../models/Setting/RenderingProvider.js";
import SettingNameLocationBoxTwo from "../../../models/Setting/SettingNameLocationBoxTwo.js";
import ZoneSetup from "../../../models/Setting/ZoneSetup.js";

const myInfo = async (req, res, next) => {
  try {
    const patientInitialInfo = await Patient.findOne({
      where: {
        id: req.user.id,
      },
    });

    const phones = await PatientPhone.findAll({
      where: {
        client_id: req.user.id,
      },
    });

    const emails = await PatientEmail.findAll({
      where: {
        client_id: req.user.id,
      },
    });

    const addresses = await PatientAddress.findAll({
      where: {
        client_id: req.user.id,
      },
    });

    const allZones = await ZoneSetup.findAll();

    const renderingProviders = await ReferringProvider.findAll({
      where: {
        admin_id: req.user.admin_id,
      },
    });

    const patientInfo = await PatientInfo.findOne({
      where: {
        client_id: req.user.id,
      },
    });

    let garanterInfo = await PatientGurantorInfo.findOne({
      where: {
        client_id: req.user.id,
      },
    });

    if (!garanterInfo) {
      garanterInfo = await PatientGurantorInfo.create({
        client_id: req.user.id,
        admin_id: req.user.admin_id,
      });
    }

    const box32 = await SettingNameLocationBoxTwo.findAll({
      where: {
        admin_id: req.user.admin_id,
      },
    });

    return res.status(200).json({
      patientInitialInfo,
      phones,
      emails,
      addresses,
      all_zone: allZones,
      ren_providers: renderingProviders,
      patientMoreInfo: patientInfo,
      garanter_info: garanterInfo,
      box_32: box32,
    });
  } catch (error) {
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

export default { myInfo };
