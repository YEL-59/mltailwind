import { Op } from "sequelize";
import Appointment from "../../../models/Appointment/Appointment.js";
import PatientAuthorization from "../../../models/Patient/PatientAuthorization.js";

const getAllAuthorizationsBypatient = async (req, res) => {
  try {
    const allAuthorization = await PatientAuthorization.findAll({
      where: { client_id: req.user.id, admin_id: req.user.admin_id },
      order: [["id", "DESC"]],
    });
    res.status(200).json({ data: allAuthorization });
  } catch (error) {
    console.log(error.message);
    res.status(500).send("Server error");
  }
};
const getMySessions = async (req, res) => {
  const { search_by, reportrange } = req.body;

  const reportrange_one1 = reportrange.substring(0, 10);
  const reportrange_one2 = reportrange.substring(13, 24);

  const adminId = req.user.admin_id;
  const clientId = req.user.id;

  const today = new Date().toISOString().split("T")[0];
  const tomorrow = new Date(new Date().getTime() + 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const lastDat = new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const nextSevenDays = new Date(new Date().getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const last15Days = new Date(new Date().getTime() - 15 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const next15Days = new Date(new Date().getTime() + 15 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const last30Days = new Date(new Date().getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const next30Days = new Date(new Date().getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

  const whereCondition = { admin_id: adminId, client_id: clientId };

  if (search_by === 1) {
    whereCondition.schedule_date = today;
  }

  if (search_by === 2) {
    whereCondition.schedule_date = tomorrow;
  }

  if (search_by === 3) {
    whereCondition.schedule_date = lastDat;
  }

  if (search_by === 4) {
    whereCondition.schedule_date = { [Op.gte]: today, [Op.lte]: nextSevenDays };
  }

  if (search_by === 5) {
    whereCondition.schedule_date = { [Op.gte]: reportrange_one1, [Op.lte]: reportrange_one2 };
  }

  if (search_by === 7) {
    whereCondition.schedule_date = { [Op.lte]: today, [Op.gte]: last15Days };
  }

  if (search_by === 8) {
    whereCondition.schedule_date = { [Op.gte]: today, [Op.lte]: next15Days };
  }

  if (search_by === 9) {
    whereCondition.schedule_date = { [Op.lte]: today, [Op.gte]: last30Days };
  }

  if (search_by === 10) {
    whereCondition.schedule_date = { [Op.gte]: today, [Op.lte]: next30Days };
  }

  try {
    const appointments = await Appointment.findAll({
      where: whereCondition,
      order: [["schedule_date", "DESC"]],
    });
    res.status(200).json({
      message: "My Sessions",
      scheduledData: appointments,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Server Error" });
  }
};

export default {
  getMySessions,
  getAllAuthorizationsBypatient,
};
