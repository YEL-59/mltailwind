export const getPagination = (page) => {
  let perPage = 100;
  let offset = page * perPage - perPage;

  return { perPage, offset };
};

export const getPagingData = (data, page, limit) => {
  const { count, rows } = data;
  const currentPage = page ? +page : 0;
  const totalPages = Math.ceil(count / limit);
  const lastPage = Math.max(totalPages);
  const nextPage = count < limit ? null : page + 1;

  return {
    totalData: count,
    totalPages,
    currentPage: page,
    nextPage,
    lastPage,
    data: rows,
  };
};
