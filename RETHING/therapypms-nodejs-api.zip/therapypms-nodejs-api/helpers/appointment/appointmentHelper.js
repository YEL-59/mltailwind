import { json } from "sequelize";
import Patient from "../../models/Patient/Patient.js";
import PatientAuthorization from "../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../models/Patient/PatientAuthActivity.js";
import PatientInfo from "../../models/Patient/PatientInfo.js";
import Provider from "../../models/Provider/Provider.js";

export const createSession = async (req, admin_id) => {
  const patient_data = await getPatientData(req, admin_id);
  const provider_data = await getProviderData(req, admin_id);
  const setting_data = await getSettingData(req, admin_id);

  if (req.billable === 1) {
    if (req.chkrecurrence === 1) {
    }
  }
};

async function createSingleSession() {}

async function getPatientData(req, admin_id) {
  const patient = await Patient.findOne({
    attributes: ["id", "is_active_client", "client_first_name", "client_middle", "client_last_name", "client_gender", "zone"],
    where: {
      admin_id: admin_id,
      id: req.client_id,
    },
  });

  const patient_info = await PatientInfo.findOne({
    attributes: ["id", "admin_id", "client_id", "preferred_language"],
    where: {
      admin_id: admin_id,
      id: req.client_id,
    },
  });

  const patient_auth = await PatientAuthorization.findOne({
    attributes: ["client_id", "onset_date", "end_date", "payor_id", "is_placeholder"],
    where: {
      admin_id: admin_id,
      id: req.authorization_id,
    },
  });

  const patient_auth_act = await PatientAuthActivity.findOne({
    where: {
      admin_id: admin_id,
      id: req.activity_id,
    },
  });

  return json({
    patient_data: patient,
    patient_auth_data: patient_auth,
  });
}

async function getProviderData() {
  const provider = Provider.findOne({
    attributes: ["id", "admin_id", "first_name", "middle_name", "last_name"],
    where: {
      admin_id: admin_id,
    },
  });
}

async function getSettingData(req, admin_id) {}
