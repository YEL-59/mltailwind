import moment from "moment";
import SettingNameLocation from "../../models/Setting/SettingNameLocation.js";

export const convertDateTime = (data) => {
  try {
	const received_date = new Date(data);
	return moment(received_date).format("L");
  } catch (e) {
	return "received_date_format_not_correct";
  }
};

export const checkDateTimeDiff = (st_date, ed_date) => {
};

export const getNameLocation = async (admin_id) => {
  return await SettingNameLocation.findOne({
	attributes: ["id", "admin_id", "is_combo"],
	where: {
	  admin_id: admin_id,
	},
  });
};

export const firstDate = async (startDate, weekDay) => {
  const start = moment(startDate);
  const end = moment(start).add(7, "days");
  //console.log(start, end);
  let result = "";
  while (start <= end) {
	const timeStamp = start.format("YYYY-MM-DDTHH:mm:ss.SSSZ");
	const week = moment(timeStamp).format("dddd");
	console.log(week);
	if (week === weekDay) {
	  result = moment(timeStamp).format("YYYY-MM-DD");
	  break;
	}
	start.add(1, "day");
  }
  console.log("result====>", result);
  return result;
};

export const checkDateFunction = async (lastDate, checkDay) => {
  const startDate = moment(lastDate).add(1, "day");
  const endDate = moment(lastDate).add(8, "days");
  let result = "";
  
  while (startDate <= endDate) {
	const weekDay = startDate.format("dddd");
	if (weekDay === checkDay) {
	  result = startDate.format("YYYY-MM-DD");
	  break;
	}
	startDate.add(1, "day");
  }
  
  return result;
};
