export const isQueryParam = async (param) => {
  return param && Object.is(param) !== null;
  
}
export const isQueryParamArray = async (param) => {
  return Array.isArray(param) && param.length > 0;
}
