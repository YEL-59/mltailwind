import PriManageClaimTransaction from "../../models/PrimaryBilling/ManageClaimTransaction.js";
import ProcessClaim from "../../models/PrimaryBilling/ProcessClaim.js";
import { Op, where } from "sequelize";
import depositApply from "../../models/Payment/depositApply.js";
import DepositApply from "../../models/Payment/depositApply.js";

export const getProcessClaims = async (admin_id, claim_no) => {
  const manage_claim_trns = PriManageClaimTransaction.findAll({
    where: {
      admin_id: admin_id,
    },
  });

  let prc_clm_ids = [];
  await Promise.all(
    (
      await manage_claim_trns
    ).map(async (i) => {
      prc_clm_ids.push(i.processing_claim_id);
    })
  );

  return await ProcessClaim.findAll({
    where: {
      admin_id: admin_id,
      id: {
        [Op.in]: prc_clm_ids,
      },
    },
  });
};

export const updateDepositData = async (admin_id, procc_claim_datas) => {};

async function checkExistsDeposit(admin_id) {}

async function createNewDepositApply(admin_id, deposit_id, single_data) {
  return await depositApply.create({
    admin_id: admin_id,
    deopsit_id: deposit_id,
    appointment_id: single_data.appointment_id,
    processing_claim_id: single_data.processing_claim_id,
    client_id: single_data.client_id,
    provider_id: single_data.provider_id,
    authorization_id: single_data.authorization_id,
    activity_id: single_data.activity_id,
    payor_id: single_data.payor_id,
    dos: single_data.dos,
    amount: 0.0,
    payment: 0.0,
    adjustment: 0.0,
    balance: 0.0,
    reason: "Contractual Adj",
    status: "Open",
    billed_am: 0.0,
  });
}

async function updateExistNullDeposit(admin_id, prc_clm_id) {}

async function updateProccStatus(admin_id) {
  await ProcessClaim.update(
    { has_deposit: 1 },
    {
      where: {
        admin_id: admin_id,
        id: prc_clm_id,
      },
    }
  );

  return "prc_claim_dep_update";
}

async function checkExistDistinct(admin_id, client_id, dep_id) {
  return DepositApply.findOne({
    group: ["admin_id", "client_id"],
    where: {
      admin_id: admin_id,
      client_id,
    },
  });
}

async function updateDepositApply(admin_id, prc_clm_id, dep_id) {
  return DepositApply.findOne({
    attributes: ["id", "admin_id", "processing_claim_id", "deopsit_id", "amount", "billed_am", "balance"],
    where: {
      admin_id: admin_id,
      processing_claim_i: prc_clm_id,
      deopsit_id: dep_id,
    },
  });
}

async function checkExistsNullDeposit(admin_id) {}
