import { Op, Sequelize } from "sequelize";
import Ledger from "../../models/Ledger/Ledger.js";
import PriManageClaimTransaction from "../../models/PrimaryBilling/ManageClaimTransaction.js";
import ProcessClaim from "../../models/PrimaryBilling/ProcessClaim.js";
import Patient from "../../models/Patient/Patient.js";
import PayorFacility from "../../models/Setting/PayorFacility.js";
import PriManageClaim from "../../models/PrimaryBilling/ManageClaim.js";

export const clmWiseClaimNo = async (admin_id, claim_no) => {
  return await PriManageClaim.findAll({
    attributes: ["admin_id", "claim_id"],
    where: {
      admin_id: admin_id,
      claim_id: claim_no,
    },
    include: [
      {
        model: PriManageClaimTransaction,
        as: "mngclam_tran_asc",
        attributes: ["admin_id", "claim_id"],
        include: [
          {
            model: ProcessClaim,
            as: "pri_mngclmtrn_prcclm",
            attributes: [[Sequelize.literal("(SELECT sum(rate*units) FROM processing_claims)"), "billed_amount"]],
          },
        ],
      },
      {
        model: Patient,
        as: "mngclam_patient",
        attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
      },
    ],
  });
};

export const clmWisePatientData = async (admin_id, patient_ids, start_date, end_date) => {
  return PriManageClaimTransaction.findAll({
    attributes: ["admin_id", "claim_id"],
    where: {
      admin_id: admin_id,
      client_id: {
        [Op.in]: patient_ids,
      },
      schedule_date: {
        [Op.between]: [start_date, end_date],
      },
    },
    include: [
      {
        model: ProcessClaim,
        as: "pri_mngclmtrn_prcclm",
      },
      {
        model: Patient,
        as: "pri_mngclmtrn_patient",
        attributes: ["id", "admin_id", "client_first_name", "client_middle", "client_last_name", "client_full_name"],
      },
    ],
  });
};
