import Appointment from "../../models/Appointment/Appointment.js";
import { Op } from "sequelize";
import { isQueryParam, isQueryParamArray } from "../../helpers/queryValidation.js";
import PatientAuthorization from "../../models/Patient/PatientAuthorization.js";
import PatientAuthActivity from "../../models/Patient/PatientAuthActivity.js";
import ProcessClaim from "../../models/PrimaryBilling/ProcessClaim.js";
import PayorFacility from "../../models/Setting/PayorFacility.js";
import Provider from "../../models/Provider/Provider.js";

export const getAppointmentData = async (admin_id, to_date) => {
  return await Appointment.findAll({
    where: {
      admin_id: admin_id,
      schedule_date: {
        [Op.lt]: to_date,
      },
      billable: 1,
      is_locked: 0,
      is_show: 0,
      status: "Rendered",
    },
    order: [["schedule_date", "DESC"]],
  });
};

export const processWithoutComboCode = async (admin_id, app_data) => {
  await Promise.all(
    app_data.map(async (i) => {
      const single_appointment = await Appointment.findOne({
        where: {
          admin_id: admin_id,
          id: i.id,
        },
        include: [
          {
            model: PatientAuthorization,
            as: "app_auth",
          },
          {
            model: PatientAuthActivity,
            as: "app_activity",
          },
        ],
      });

      const check_procc_claim = await ProcessClaim.findOne({
        where: {
          admin_id: admin_id,
          appointment_id: i.id,
        },
      });

      if (!check_procc_claim) {
        if (single_appointment.app_auth.is_placeholder !== 1) {
          await ProcessClaim.create({
            admin_id: admin_id,
            down_admin_id: admin_id,
            appointment_id: single_appointment.id,
            client_id: single_appointment.client_id,
            provider_id: single_appointment.provider_id,
            authorization_id: single_appointment.authorization_id,
            activity_id: single_appointment.activity_id,
            payor_id: single_appointment.app_auth.payor_id,
            schedule_date: single_appointment.schedule_date,
            from_time: single_appointment.from_time,
            to_time: single_appointment.to_time,
            time_duration: single_appointment.time_duration,
            cpt: single_appointment.cpt,
            m1: single_appointment.app_activity.m1,
            m2: single_appointment.app_activity.m2,
            m3: single_appointment.app_activity.m3,
            m4: single_appointment.app_activity.m4,
            rate: single_appointment.app_auth.rate,
            cms_24j: single_appointment.app_auth.supervisor_id,
            status: "Ready To Bill",
            degree_level: single_appointment.degree_level,
            zone: single_appointment.zone,
            location: single_appointment.location,
            is_mark_gen: 0,
            has_deposit: 0,
          });

          single_appointment.set({
            is_locked: 0,
          });

          await single_appointment.save();
        }
      } else {
        single_appointment.set({
          is_locked: 0,
          is_mark_gen: 0,
        });

        await single_appointment.save();
      }

      return "claim_created";
    })
  );
};

export const getPayorNames = async (admin_id, to_date) => {
  let p_array = [];

  const prc_ap_data = await ProcessClaim.findAll({
    attributes: ["admin_id", "payor_id"],
    group: ["admin_id", "payor_id"],
    where: {
      admin_id: admin_id,
      is_mark_gen: 0,
      status: {
        [Op.or]: ["Ready To Bill", "Pending for Approval"],
      },
      schedule_date: {
        [Op.lt]: to_date,
      },
    },
  });

  await Promise.all(
    prc_ap_data.map(async (i) => {
      p_array.push(i.payor_id);
    })
  );

  return await PayorFacility.findAll({
    attributes: ["id", "admin_id", "payor_id", "payor_name"],
    where: {
      admin_id: admin_id,
      payor_id: {
        [Op.in]: p_array,
      },
    },
  });
};

export const processWithComboCode = async (req, app_data) => {
  return "app_data";
};

export const updateStatus = async (admin_id, prc_claim_ids) => {
  await ProcessClaim.update(
    { status: "Ready To Bill" },
    {
      where: {
        admin_id: admin_id,
        id: prc_claim_ids,
      },
    }
  );

  return ProcessClaim.findAndCountAll({
    where: {
      admin_id: admin_id,
      status: "Pending for Approval",
    },
  });
};

export const updateStatusClarificationPending = async (admin_id, prc_claim_ids) => {
  return await ProcessClaim.update(
    { status: "Pending for Approval" },
    {
      where: {
        admin_id: admin_id,
        id: {
          [Op.in]: prc_claim_ids,
        },
      },
    }
  );
};

export const retractSession = async (admin_id, prc_claim_ids) => {
  return ProcessClaim.destroy({
    where: {
      admin_id: admin_id,
      id: {
        [Op.in]: prc_claim_ids,
      },
    },
  });
};

export const nonBillableServ = async (admin_id, prc_claim_ids) => {
  return await ProcessClaim.update(
    { status: "Unbillable Activity" },
    {
      where: {
        admin_id: admin_id,
        id: {
          [Op.in]: prc_claim_ids,
        },
      },
    }
  );
};

export const update24jProvider = async (admin_id, prc_claim_ids, cms_provider_id) => {
  const prc_claims = await ProcessClaim.update(
    {
      cms_24j: cms_provider_id,
    },
    {
      where: {
        admin_id: admin_id,
        id: {
          [Op.in]: prc_claim_ids,
        },
      },
    }
  );

  return await Provider.findOne({
    where: {
      admin_id: admin_id,
      id: cms_provider_id,
    },
  });
};

export const updateIdQualifires = async (admin_id, prc_claim_ids, id_qualifiers_val) => {
  const prc_claims = await ProcessClaim.update(
    {
      id_qualifier: id_qualifiers_val,
    },
    {
      where: {
        admin_id: admin_id,
        id: {
          [Op.in]: prc_claim_ids,
        },
      },
    }
  );

  return id_qualifiers_val;
};

export const updateModifires = async (admin_id, prc_claim_ids, m1_val, m2_val, m3_val, m4_val) => {
  let updateModifire = {};
  if (await isQueryParam(m1_val)) {
    updateModifire.m1 = m1_val;
  }

  if (await isQueryParam(m2_val)) {
    updateModifire.m2 = m2_val;
  }
  if (await isQueryParam(m3_val)) {
    updateModifire.m3 = m3_val;
  }
  if (await isQueryParam(m4_val)) {
    updateModifire.m4 = m4_val;
  }

  return await ProcessClaim.update(updateModifire, {
    where: {
      admin_id: admin_id,
      id: {
        [Op.in]: prc_claim_ids,
      },
    },
  });
};

export const updateChargeAmount = async (admin_id, prc_claim_ids, rate_val) => {
  return await ProcessClaim.update(
    { rate: rate_val },
    {
      where: {
        admin_id: admin_id,
        id: {
          [Op.in]: prc_claim_ids,
        },
      },
    }
  );
};

export const addCptCode = async (admin_id, prc_claim_ids, cpt_val, unit_val) => {
  let updateCptUnit = {};
  if (await isQueryParam(cpt_val)) {
    updateCptUnit.cpt = cpt_val;
  }

  if (await isQueryParam(unit_val)) {
    updateCptUnit.units = unit_val;
  }

  return await ProcessClaim.update(updateCptUnit, {
    where: {
      admin_id: admin_id,
      id: {
        [Op.in]: prc_claim_ids,
      },
    },
  });
};

export const updateTxProvider = async (admin_id, prc_claim_ids, provider_id) => {
  let updateProvider = {};
  if (await isQueryParam(provider_id)) {
    updateProvider.cms_24j = provider_id;
  }

  return await ProcessClaim.update(updateProvider, {
    where: {
      admin_id: admin_id,
      id: {
        [Op.in]: prc_claim_ids,
      },
    },
  });
};

export const updatePos = async (admin_id, prc_claim_ids, pos_val) => {
  let updatePos = {};
  if (await isQueryParam(pos_val)) {
    updatePos.location = pos_val;
  }

  return await ProcessClaim.update(updatePos, {
    where: {
      admin_id: admin_id,
      id: {
        [Op.in]: prc_claim_ids,
      },
    },
  });
};

export const updateTelMod = async (admin_id, prc_claim_ids, tele_mod_value) => {
  let updateCptUnit = {};
  if (await isQueryParam(tele_mod_value)) {
    updateCptUnit.cpt = tele_mod_value;
  }

  if (await isQueryParam(unit_val)) {
    updateCptUnit.units = unit_val;
  }

  return await ProcessClaim.update(updateCptUnit, {
    where: {
      admin_id: admin_id,
      id: {
        [Op.in]: prc_claim_ids,
      },
    },
  });
};
