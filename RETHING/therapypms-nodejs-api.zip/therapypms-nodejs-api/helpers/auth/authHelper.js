import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import config from "config";
export const jwtTokenGenerate = async (user_id, type) => {
  const payload = {
    user: {
      id: user_id,
      type: type,
    },
  };
  return payload;
};

export const comparePassword = async () => {};
