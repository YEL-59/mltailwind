import { Op } from "sequelize";
import ProcessClaim from "../../models/PrimaryBilling/ProcessClaim";
import PriManageClaimTransaction from "../../models/PrimaryBilling/ManageClaimTransaction";
import Ledger from "../../models/Ledger/Ledger";
import PatientAuthorization from "../../models/Patient/PatientAuthorization";
import PriManageClaim from "../../models/PrimaryBilling/ManageClaim";

export const genPribatch = async (admin_id, prc_claim_ids) => {
  //   const update_status = updatePrcClaimStatus(admin_id, prc_claim_ids);
  //   const prc_clm_to_mng_clm = processToManageClaim(admin_id, prc_claim_ids);
  //   const prc_clm_to_dep = processToDeposit(admin_id, prc_claim_ids);

  return "done";
};

async function updatePrcClaimStatus(admin_id, prc_claim_ids) {
  await ProcessClaim.update(
    { is_mark_gen: 0 },
    {
      where: {
        admin_id: admin_id,
        id: {
          [Op.in]: prc_claim_ids,
        },
      },
    }
  );

  return "status_updated";
}

async function processToManageClaim(admin_id, prc_claim_ids) {
  await createNewBatchId(admin_id);
  await getLastClaimId(admin_id);
  await countManageClim(admin_id);
  await statusMCDate(admin_id);
  await createNewManageClaim(admin_id);
  await createNewMngClimTran(admin_id);
  await createNewLedger(admin_id);
}

async function createNewBatchId(admin_id) {
  return (check_manage_claim_b_id = await PriManageClaimTransaction.findOne({
    attributes: ["id", "admin_id", "batch_id"],
    group: ["admin_id", "batch_id"],
    where: {
      admin_id: admin_id,
    },
    order: [["batch_id", "DESC"]],
  }));
}

async function getLastClaimId(admin_id) {
  const check_mng_clam_last_cid = await PriManageClaimTransaction({
    where: {
      admin_id: admin_id,
    },
    orderBy: [["claim_id", "desc"]],
  });

  let claim_id;
  if (check_mng_clam_last_cid) {
    claim_id = check_mng_clam_last_cid.claim_id;
  } else {
    claim_id = 1000;
  }

  return claim_id;
}

async function countManageClim() {
  return await PriManageClaimTransaction.findAndCountAll({
    attributes: ["claim_id", "batch_id", "admin_id", "authorization_id", "client_id"],
    where: {
      admin_id: admin_id,
    },
  });
}

async function statusMCDate() {}

async function createNewManageClaim(sing_claim, admin_id, batch_id, new_claim_id, edi_type) {
  await PriManageClaim.create({
    admin_id: admin_id,
    claim_id: new_claim_id,
    batch_id: batch_id,
    appointment_id: sing_claim.appointment_id,
    client_id: sing_claim.client_id,
    provider_id: sing_claim.provider_id,
    authorization_id: sing_claim.authorization_id,
    activity_id: sing_claim.activity_id,
    payor_id: sing_claim.payor_id,
    activity_type: sing_claim.activity_id,
    schedule_date: sing_claim.schedule_date,
    is_primary: edi_type,
  });
}

async function createNewMngClimTran(batch_id, new_claim_id, sing_claim, admin_id, edi_type) {
  const getAuthNo = await ProcessClaim.findOne({
    where: {
      admin_id: admin_id,
      id: sing_claim.id,
    },
    include: [
      {
        model: PatientAuthorization,
        as: "procc_patient_auth",
        attributes: ["id", "admin_id", "client_id", "authorization_number"],
      },
    ],
  });

  await PriManageClaimTransaction.create({
    admin_id: admin_id,
    claim_id: new_claim_id,
    batch_id: batch_id,
    processing_claim_id: sing_claim.admin_id,
    appointment_id: sing_claim.appointment_id,
    client_id: sing_claim.client_id,
    provider_id: sing_claim.provider_id,
    authorization_id: sing_claim.authorization_id,
    activity_id: sing_claim.activity_id,
    payor_id: sing_claim.payor_id,
    activity_type: sing_claim.activity_id,
    schedule_date: sing_claim.schedule_date,
    billed_date: sing_claim.billed_date,
    resubmit_date: null,
    auth_no: getAuthNo.id, // replace to patient auth num
    is_primary: edi_type,
  });
}

async function createNewLedger(sing_claim, admin_id) {
  await Ledger.create({
    admin_id: admin_id,
    processing_claim_id: sing_claim.id,
    appointment_id: sing_claim.appointment_id,
    client_id: sing_claim.client_id,
    provider_id: sing_claim.provider_id,
    authorization_id: sing_claim.authorization_id,
    activity_id: sing_claim.activity_id,
    payor_id: sing_claim.payor_id,
    activity_type: sing_claim.activity_type,
    schedule_date: sing_claim.schedule_date,
    billed_date: sing_claim.billed_date,
    is_mark_gen: sing_claim.is_mark_gen,
    has_manage_claim: edi_gen_type,
  });
}

async function processToDeposit(admin_id, prc_claim_ids) {}
