import Patient from "../../models/Patient/Patient.js";

const patientById = async (admin_id, patient_id) => {
  return await Patient.findOne({
    where: {
      admin_id: admin_id,
      id: patient_id,
    },
  });
};

export default {
  patientById,
};
