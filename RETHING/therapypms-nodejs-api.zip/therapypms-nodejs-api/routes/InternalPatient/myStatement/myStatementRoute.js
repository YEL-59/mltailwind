import express from "express";
import { auth } from "../../../middleware/AuthMiddleware.js";
import MyStatementController from "../../../controller/InternalPatient/MyStatement/MyStatementController.js";
let router = express.Router();

router.post("/due", [auth], MyStatementController.patientMyStatement);
router.post("/paid", [auth], MyStatementController.patientMyStatementPaid);
router.post("/unpaid", [auth], MyStatementController.patientMyStatementUnpaid);
router.post("/get/data", [auth], MyStatementController.patientMyStatementGetData);

export default router;
