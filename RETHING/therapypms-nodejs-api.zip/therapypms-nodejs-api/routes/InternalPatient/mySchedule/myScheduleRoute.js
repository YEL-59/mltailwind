import express from "express";

let router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";
import MyScheduleController from "../../../controller/InternalPatient/MySchedule/MyScheduleController.js";

router.post("/get/my/sessions", [auth], MyScheduleController.getMySessions);
router.post("/get/all/auth", [auth], MyScheduleController.getAllAuthorizationsBypatient);
export default router;
