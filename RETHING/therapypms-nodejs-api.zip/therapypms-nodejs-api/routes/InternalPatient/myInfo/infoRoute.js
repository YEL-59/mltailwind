import express from "express";
import { auth } from "../../../middleware/AuthMiddleware.js";
import MyInfoController from "../../../controller/InternalPatient/MyInfo/MyInfoController.js";

let router = express.Router();

//patient info
router.get("/", [auth], MyInfoController.myInfo);

export default router;
