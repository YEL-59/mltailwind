import express from "express";
import { auth } from "../../../middleware/AuthMiddleware.js";
import MyAuthorizationController from "../../../controller/InternalPatient/MyInfo/MyAuthorizationController.js";

let router = express.Router();

//patient info
router.post("/authorizations", [auth], MyAuthorizationController.myAuthorizations);
router.post("/authorization/activity", [auth], MyAuthorizationController.authActivities);

export default router;
