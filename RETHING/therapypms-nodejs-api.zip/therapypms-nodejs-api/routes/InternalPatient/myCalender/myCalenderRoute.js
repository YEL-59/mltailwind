import express from "express";
import MyCalenderController from "../../../controller/InternalPatient/MyCalender/MyCalenderController.js";
import { auth } from "../../../middleware/AuthMiddleware.js";
let router = express.Router();

router.post("/get/data", [auth], MyCalenderController.myCalenderGetData);
router.post("/get/single/data", [auth], MyCalenderController.calenderSingleSession);

export default router;
