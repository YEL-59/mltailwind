import express from "express";

let router = express.Router();
import { check } from "express-validator";

import { auth } from "../../../../middleware/AuthMiddleware.js";

import HirasmusController from "../../../../controller/API/ExternalAdmin/HirasmusAppointmentController.js";

router.post("/get/appointment", HirasmusController.getAppointment);

export default router;
