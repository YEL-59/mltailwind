import express from "express";

let router = express.Router();
import { check } from "express-validator";
import { auth } from "../../../middleware/AuthMiddleware.js";
import ProviderRecurringSessionController from "../../../controller/InternalProvider/ProviderRecurringSession/ProviderRecurringSessionController.js";

router.get("/get/all/setting/pos", [auth], ProviderRecurringSessionController.settingpos);
router.post("/get/all/info", [auth], ProviderRecurringSessionController.recurringSessionGetSortedInfo);
router.post("/get/all/data", [auth], ProviderRecurringSessionController.recurringSessionDataGet);
router.get("/single/data/:id", [auth], ProviderRecurringSessionController.recurringSessionEdit);

export default router;
