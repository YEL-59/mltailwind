import express from "express";

let router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";
import ProviderSessionController from "../../../controller/InternalProvider/ProviderSchedule/ProviderSessionController.js";

router.post("/get/all/providers", [auth], ProviderSessionController.getAllProviders);
router.post("/get/all/patients", [auth], ProviderSessionController.getAllPatients);
router.post("/get/all/pos", [auth], ProviderSessionController.getAllPos);
router.post("/get/all/sessions", [auth], ProviderSessionController.getAllSessions);
router.post("/get/monthly/utilization", [auth], ProviderSessionController.monthlyUtilizationAndTotalUtilization);
router.post("/delete/session", [auth], ProviderSessionController.deleteSession);
export default router;
