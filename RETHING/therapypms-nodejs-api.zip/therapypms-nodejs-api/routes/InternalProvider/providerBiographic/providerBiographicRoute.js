import express from "express";
const router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";
import ProviderBiographicController from "../../../controller/InternalProvider/ProviderBiographic/ProviderBiographicController.js";


router.post('/', [auth], ProviderBiographicController.providerInfo);
router.post('/biographic/update', [auth], ProviderBiographicController.providerInfoUpdate);

export default router;