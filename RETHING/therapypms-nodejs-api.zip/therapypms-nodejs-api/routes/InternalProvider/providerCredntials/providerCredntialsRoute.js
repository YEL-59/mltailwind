import express from "express";
const router = express.Router();
import ProviderCredntialsController from "../../../controller/InternalProvider/ProviderCredntials/ProviderCredntialsController.js";
import ProviderLeaveTrackingController from "../../../controller/InternalProvider/ProviderLeaveTracking/ProviderLeaveTrackingController.js";
import { auth } from "../../../middleware/AuthMiddleware.js";

//---------------------Provider Credentials Route----------------------//
router.post("/get/credentials", [auth], ProviderCredntialsController.credentials);
router.post("/credentials/save", [auth], ProviderCredntialsController.credentials_save);
router.get("/credentials/single/:cred_id", [auth], ProviderCredntialsController.singleCredentials);
router.post("/credentials/update", [auth], ProviderCredntialsController.credentials_Update);
router.post("/credentials/delete", [auth], ProviderCredntialsController.credentials_delete);
router.post("/get/clearance", [auth], ProviderCredntialsController.clearance);
router.get("/clearance/single/:clearance_id", [auth], ProviderCredntialsController.singleClearance);
router.post("/clearance/save", [auth], ProviderCredntialsController.clearanceSave);
router.post("/clearance/update", [auth], ProviderCredntialsController.clearanceUpdate);
router.post("/clearance/delete", [auth], ProviderCredntialsController.clearanceDelete);
router.post("/qualification/list", [auth], ProviderCredntialsController.providerQualificationList);
router.post("/qualification/save", [auth], ProviderCredntialsController.providerQualificationSave);
router.get("/single/qualification/:qual_id", [auth], ProviderCredntialsController.providerSingleQualification);
router.post("/qualification/update", [auth], ProviderCredntialsController.providerQualificationUpdate);
router.post("/qualification/delete", [auth], ProviderCredntialsController.providerQualificationDelete);
// ------------------leave tracking ----------------------
router.post("/leave/tracking", [auth], ProviderLeaveTrackingController.get_provider_leave_tracking);
router.post("/leave/tracking/save", [auth], ProviderLeaveTrackingController.providerLeaveTrackingSave);
router.post("/leave/delete", [auth], ProviderLeaveTrackingController.providerLeaveTrackingDelete);

//------------------provider/Work Schedule---------------
// router.get("/get/working/schedule/:id", [auth], ProviderCredntialsController.getWorkingSchedule);
// router.post("/create/working/schedule", [auth], ProviderCredntialsController.createWorkingSchedule);
// router.post("/list/block/off/time", [auth], ProviderCredntialsController.getAllBlockOffTTime);
// router.post("/create/block/off/time", [auth], ProviderCredntialsController.createBlockOffTime);
// router.post("/delete/block/off/time", [auth], ProviderCredntialsController.deleteBlockOffTime);

export default router;
