import express from "express";
import { auth } from "../../../middleware/AuthMiddleware.js";
import ProviderTimeSheetController from "../../../controller/InternalProvider/ProviderTimesheets/ProviderTimeSheetController.js";

let router = express.Router();

router.post("/get/all/time/periods", [auth], ProviderTimeSheetController.payrollPayTimeGet);
router.post("/get/all/time/sheet/appointments", [auth], ProviderTimeSheetController.payrollTimesheetAppoinment);
router.post("/payroll/time/sheet/save/changes", [auth], ProviderTimeSheetController.payrollTimeSheetChangeSave);

export default router;
