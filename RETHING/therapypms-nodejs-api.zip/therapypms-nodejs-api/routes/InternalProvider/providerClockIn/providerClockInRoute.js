import express from "express";
import { auth } from "../../../middleware/AuthMiddleware.js";
import ProviderClockInController from "../../../controller/InternalProvider/ProviderClockIn/ProviderClockInController.js";
const router = express.Router();

router.post("/punch", [auth], ProviderClockInController.punch);
router.get("/specific/day/clock/in", [auth], ProviderClockInController.clockInTimeGet);
router.post("/get/clockin/reqs", [auth], ProviderClockInController.fetchClockInReq);
router.post("/update/clockin/reqs", [auth], ProviderClockInController.addClockInManually);

export default router;
