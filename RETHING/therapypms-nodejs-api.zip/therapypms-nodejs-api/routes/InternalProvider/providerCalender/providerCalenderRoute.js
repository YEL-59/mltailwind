import express from "express";
import { auth } from "../../../middleware/AuthMiddleware.js";
import ProviderCalenderController from "../../../controller/InternalProvider/ProviderCalender/ProviderCalenderController.js";

let router = express.Router();

router.post("/get/all/events", [auth], ProviderCalenderController.getCalenderData);
router.post("/single/event/details", [auth], ProviderCalenderController.singleEventDetails);

export default router;
