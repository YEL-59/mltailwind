import express from "express";
const router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";
import ProviderContactInfoController from "../../../controller/InternalProvider/ProviderContactInfo/ProviderContactInfoController.js";

// GET /contact-info
router.post("/info", [auth], ProviderContactInfoController.providerContactInfo);
// POST /contact-info-update
router.post("/info/update", [auth], ProviderContactInfoController.providerContactDetailsUpdate);
// POST /emergency-contact-update
router.post("/emergency/update", [auth], ProviderContactInfoController.providerEmergencyContactUpdate);

export default router;
