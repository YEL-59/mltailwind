import express from "express";
import ProviderPatientController from "../../../controller/InternalProvider/ProviderPatients/ProviderPatientController.js";
import { auth } from "../../../middleware/AuthMiddleware.js";
let router = express.Router();

router.post("/get/all", [auth], ProviderPatientController.patientList);
router.post("/get/patient/info", [auth], ProviderPatientController.patientInformation);
router.post("/update/patient/info", [auth], ProviderPatientController.patientInfoUpdate);
router.post("/get/patient/auth/list", [auth], ProviderPatientController.patientAuthList);
router.post("/get/patient/auth/activity/list", [auth], ProviderPatientController.patientAuthActList);

router.post("/get/patient/document", [auth], ProviderPatientController.patientDocuments);
router.post("/save/patient/document", [auth], ProviderPatientController.patientDocumentSave);

router.get("/get/patient/calllog/list/:id", [auth], ProviderPatientController.patientCalllog);

export default router;
