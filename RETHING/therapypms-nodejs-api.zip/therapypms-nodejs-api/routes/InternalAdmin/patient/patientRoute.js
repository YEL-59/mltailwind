import express from "express";

let router = express.Router();
import { check } from "express-validator";
import { auth } from "../../../middleware/AuthMiddleware.js";

import PatientController from "../../../controller/InternalAdmin/Patient/PatientController.js";

router.post("/create", [auth], PatientController.patientCreate);
router.post("/list", [auth], PatientController.patientList);
router.post("/active/status/change", [auth], PatientController.patientStatusChange);

//patient info
router.post("/info", [auth], PatientController.patientInfo);

//patient authorization
router.post("/authorization/list", [auth], PatientController.patientAuthList);
router.get("/authorization/create/info/:id", [auth], PatientController.patientAuthorizationCreateInfo);
router.post("/authorization/create", [auth], PatientController.patientAuthCreate);
router.get("/authorization/single/:id", [auth], PatientController.patientAuthSingle);
router.post("/authorization/update", [auth], PatientController.patientAuthUpdate);
router.post("/authorization/delete", [auth], PatientController.patientAuthDelete);

//patient authorization activity
router.post("/authorization/activity/list", [auth], PatientController.patientAuthActList);
router.post("/authorization/activity/create", [auth], PatientController.patientAuthActCreate);
router.get("/authorization/activity/get/single/:id", [auth], PatientController.patientAuthActSingle);
router.post("/authorization/activity/update", [auth], PatientController.patientAuthActUpdate);
router.post("/authorization/activity/delete", [auth], PatientController.patientAuthActDelete);

router.post("/authorization/get/service/bytxtype", [auth], PatientController.getServiceTxType);
router.post("/authorization/get/subtype/bytxtype", [auth], PatientController.getSubTypeTxType);
router.post("/authorization/get/cpt/bytxtype", [auth], PatientController.getCptCodesTxType);
router.post("/authorization/get/service/subtype", [auth], PatientController.getServiceSubType);
//patient document
router.post("/document/list", [auth], PatientController.patientDocList);
router.post("/document/create", [auth], PatientController.patientDocCreate);
router.post("/document/get/single", [auth], PatientController.patientDocGetSingle);

// patient call log

router.post("/patient/calllog", [auth], PatientController.patientCallLogs);
router.post("/patient/calllog/insert", [auth], PatientController.PatientCalllogInsert);
router.post("/patient/calllog/update", [auth], PatientController.patientDocGetSingle);
router.post("/patient/calllog/delete", [auth], PatientController.patientDocGetSingle);

export default router;
