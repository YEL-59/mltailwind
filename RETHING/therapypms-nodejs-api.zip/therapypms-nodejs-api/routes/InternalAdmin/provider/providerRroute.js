import express from "express";

let router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";

import ProviderController from "../../../controller/InternalAdmin/Provider/ProviderController.js";

router.post("/create", [auth], ProviderController.createProvider);
router.post("/list", [auth], ProviderController.providerList);
router.post("/employee/status/update", [auth], ProviderController.employeeStatusUpdate);

// Provider Biographic
router.get("/biographic/:providerid", [auth], ProviderController.providerBiographic);
router.post("/biographic/update", [auth], ProviderController.providerBiographicUpdate);

// provider contact info
router.get("/contact/info/:providerid", [auth], ProviderController.providerContactInfo);
router.post("/contact/info/update", [auth], ProviderController.providerContactInfoUpdate);
router.post("/emergency/contact/info/update", [auth], ProviderController.providerEmergencyContactDetailsUpdate);

//------------provider/credentials----------------
router.post("/credential/list", [auth], ProviderController.providerCredentialList);
router.post("/credential/save", [auth], ProviderController.providerCredentialSave);
router.get("/single/credential/:cred_id", [auth], ProviderController.singleProviderCredential);
router.post("/credential/update", [auth], ProviderController.providerCredentialUpdate);
router.post("/credential/delete", [auth], ProviderController.providerCredentialDelete);

router.post("/clearance/list", [auth], ProviderController.providerClearenceList);
router.post("/clearance/save", [auth], ProviderController.providerClearenceSave);
router.get("/single/clearance/:clearance_id", [auth], ProviderController.singleProviderClearance);

router.post("/clearance/update", [auth], ProviderController.providerClearanceupdate);
router.post("/clearance/delete", [auth], ProviderController.providerClearanceDelete);

router.post("/qualification/list", [auth], ProviderController.providerQualificationList);
router.post("/qualification/save", [auth], ProviderController.providerQualificationSave);
router.get("/single/qualification/:qual_id", [auth], ProviderController.providerSingleQualification);
router.post("/qualification/update", [auth], ProviderController.providerQualificationUpdate);
router.post("/qualification/delete", [auth], ProviderController.providerQualificationDelete);
//------------provider/dept. Supervisor----------------
router.get("/department/supervisor/:id", [auth], ProviderController.providerDeptSupervisor);
router.post("/department/supervisor/update", [auth], ProviderController.providerDepartmentSupervisorUpdate);
//------------------provider/payroll setup----------------
router.post("/payroll/list/get", [auth], ProviderController.providerPayroll);
router.post("/payroll/save", [auth], ProviderController.providerPayrollSave);
router.post("/payroll/update", [auth], ProviderController.providerPayrollUpdate);
router.post("/payroll/delete", [auth], ProviderController.providerPayrollDelete);
router.post("/payroll/bulk/update", [auth], ProviderController.providerPayrollBulkEdit);
//------------------provider/other-setup----------------
router.get("/other/setup/:id", [auth], ProviderController.providerOtherSetup);
router.post("/other/setup/update", [auth], ProviderController.providerOtherSetupUpdate);

// ------------------leave tracking ----------------------
router.post("/ac/staff/leave/tracking", [auth], ProviderController.get_provider_leave_tracking);
router.post("/ac/staff/leave/tracking/save", [auth], ProviderController.providerLeaveTrackingSave);
router.post("/ac/staffs/leave/delete", [auth], ProviderController.providerLeaveTrackingDelete);

// -------------------insurance exclusion --------------
router.post("/ac/staffs/get/all/payor", [auth], ProviderController.get_provider_get_all_payor);
router.post("/ac/staffs/get/assign/payor", [auth], ProviderController.get_provider_get_assign_payor);
router.post("/ac/staffs/payor/exclusion/add", [auth], ProviderController.provider_payor_exclution_add);
router.post("/ac/staffs/payor/exclusion/delete", [auth], ProviderController.provider_payor_exclution_delete);
//------------------provider/service sub-type exclusion---------------
router.post("/all/service/subtype", [auth], ProviderController.providerAllServiceSubtype);
router.post("/assigned/service/subtype", [auth], ProviderController.providerAssignedSubtype);
router.post("/add/service/subtype", [auth], ProviderController.providerSubActExclusionSave);
router.post("/remove/service/subtype", [auth], ProviderController.providerSubtActExclusionDelete);
//------------------provider/patient exclusion---------------
router.post("/patient/exclusion/get/all", [auth], ProviderController.providerGetAllPatient);
router.post("/patient/assigned/get/all", [auth], ProviderController.providerAllAssignedPatient);
router.post("/add/patient/to/assigned", [auth], ProviderController.providerPatientExclusionSave);
router.post("/delete/assigned/patient", [auth], ProviderController.providerPatientExclusionDelete);
//------------------provider/Work Schedule---------------
router.get("/get/working/schedule/:id", [auth], ProviderController.getWorkingSchedule);
router.post("/create/working/schedule", [auth], ProviderController.createWorkingSchedule);
router.post("/list/block/off/time", [auth], ProviderController.getAllBlockOffTTime);
router.post("/create/block/off/time", [auth], ProviderController.createBlockOffTime);
router.post("/delete/block/off/time", [auth], ProviderController.deleteBlockOffTime);

export default router;
