import express from "express";

let router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";

import AppointmentController from "../../../controller/InternalAdmin/Appointment/AppointmentController.js";

router.post("/get/patient/list", [auth], AppointmentController.getPatientList);
router.post("/get/auth/by/patientid", [auth], AppointmentController.getAuthByPatientID);

router.post("/get/patient/act/by/authid", [auth], AppointmentController.getActByAuthID);

router.post("/get/available/time", [auth], AppointmentController.getAvailableTime);

router.post("/create/session", [auth], AppointmentController.createAppointment);

export default router;
