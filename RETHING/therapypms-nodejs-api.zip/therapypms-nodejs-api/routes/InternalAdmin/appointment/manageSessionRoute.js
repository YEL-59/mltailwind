import express from "express";

let router = express.Router();
import { check } from "express-validator";
import { auth } from "../../../middleware/AuthMiddleware.js";

import ManageSessionController from "../../../controller/InternalAdmin/Appointment/ManageSessionController.js";

router.post("/get/all/client", [auth], ManageSessionController.getSessionClientAll);
router.post("/get/all/provider", [auth], ManageSessionController.getSessionProviderAll);
router.post("/appointment/list/billable", [auth], ManageSessionController.getAppointmentListBillable);

router.post("/appointment/list/non/billable", [auth], ManageSessionController.getAppointmentListNonBillable);

router.post("/appointment/single", [auth], ManageSessionController.getAppointmentSingle);

router.post("/appointment/update", [auth], ManageSessionController.getAppointmentUpdate);

router.post("/appointment/bulk/status/update", [auth], ManageSessionController.appointmentStatusUpdate);

router.post("/appointment/bulk/delete", [auth], ManageSessionController.appointmentBulkDelete);

export default router;
