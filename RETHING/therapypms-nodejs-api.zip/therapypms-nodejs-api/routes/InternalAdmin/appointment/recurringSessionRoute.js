import express from "express";
let router = express.Router();
import { check } from "express-validator";
import { auth } from "../../../middleware/AuthMiddleware.js";
import SessionRecurringController from "../../../controller/InternalAdmin/Appointment/RecurringSessionController.js";

router.post("/get/all/info", [auth], SessionRecurringController.recurringSessionGetSortedInfo);
router.post("/get/all/data", [auth], SessionRecurringController.recurringSessionDataGet);

export default router;
