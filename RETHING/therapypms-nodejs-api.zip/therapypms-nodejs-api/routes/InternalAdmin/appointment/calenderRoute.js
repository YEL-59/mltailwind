import express from "express";

let router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";

import CalenderController from "../../../controller/InternalAdmin/Appointment/CalenderController.js";

router.post("/list", [auth], CalenderController.calenderList);
router.post("/single/appointment", [auth], CalenderController.calenderSingleSession);

export default router;
