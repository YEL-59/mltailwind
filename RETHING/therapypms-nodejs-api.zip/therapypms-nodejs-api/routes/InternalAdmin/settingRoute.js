import express from "express";

let router = express.Router();
import { check } from "express-validator";
import { auth } from "../../middleware/AuthMiddleware.js";

import SettingController from "../../controller/InternalAdmin/SettingController.js";

//======================================setting name & location=====================//
router.get("/get/name/location", [auth], SettingController.getNameLocation);
router.post("/update/name/location", [auth], SettingController.updateNameLocation);

//=====================================Add Insurance=====================//
router.post("/get/all/insurance/search", [auth], SettingController.searchInsurance);

router.post("/get/facility/selected/insurance", [auth], SettingController.facilitySearchInsurance);

router.get("/get/all/insurance", [auth], SettingController.getAllInsurance);
router.get("/get/facility/selected/insurance", [auth], SettingController.getFacilitySelectedInsurance);
router.post("/add/insurance/facility", [auth], SettingController.addInsuranceToFacility);
router.post("/delete/insurance/facility", [auth], SettingController.deleteInsuranceFacility);
router.post("/all/insurance/details", SettingController.allInsuranceDetails);

router.post("/get/payor/selected/facility/details", SettingController.facilitySelectedInsuranceDetails);

router.post("/update/insurance/facility", [auth], SettingController.updateInsuranceFacility);

//=================================================//

//=====================Insurance Setup=====================//
router.post("/get/all/insurance/details", [auth], SettingController.payorSetup);
router.post("/get/insurance/setup/details", [auth], SettingController.payorSetupDetailsGet);
router.post("/payor/setup/details/update", [auth], SettingController.payorSetupDetailsUpdate);
router.post("/payorsetup/box33/update", [auth], SettingController.payorSetupBox33Update);
router.post("/payorsetup/box32/update", [auth], SettingController.payorSetupBox32Update);
router.post("/update/insurance/table/data", [auth], SettingController.payorSetupUpdateTable);

//=====================Add Treatments=====================//
router.post("/get/all/treatment/search", [auth], SettingController.searchTreatment);
router.post("/get/all/Selectedtreatment/search", [auth], SettingController.searchSelectedTreatment);
router.post("/get/all/treatment", [auth], SettingController.getAllTreatment);
router.post("/get/all/facility/treatment", [auth], SettingController.getFacilityTreatment);
router.post("/add/treatment/facility", [auth], SettingController.addTreatmentToFacility);
router.post("/remove/treatment/facility/", [auth], SettingController.removeFacilityTreatment);

//=================== SETTING/ SERVICE =======================
router.post("/list/setting/service", [auth], SettingController.listSettingService);
router.post("/add/setting/service", [auth], SettingController.addSettingService);
router.post("/single/setting/service", [auth], SettingController.singleSettingService);
router.post("/update/setting/service", [auth], SettingController.updateSettingService);
router.post("/delete/setting/service", [auth], SettingController.deleteSettingService);
//=================================================//

// =================== SETTING/ CPT CODE =======================
router.post("/list/cpt/code", [auth], SettingController.listCptCode);
router.post("/add/cpt/code", [auth], SettingController.addCptCode);
router.post("/single/cpt/code", [auth], SettingController.singleCptCode);
router.post("/update/cpt/code", [auth], SettingController.updateCptCode);
router.post("/delete/cpt/code", [auth], SettingController.deleteCptCode);
// ===================================================

// =================== SETTING/ CPT CODE EXCLUSION =======================
router.post("/available/cpt/codes", [auth], SettingController.availableCptCodes);
router.post("/excluded/cpt/codes", [auth], SettingController.getExcludedCptCodes);
router.post("/add/cpt/exclusion", [auth], SettingController.addCptExclusion);
router.post("/remove/cpt/exclusion", [auth], SettingController.removeCptExclusion);
// =======================================================================

// =================== SETTING/ Add Service Sub Type =======================
router.post("/subactivity/treatment/billable/type", [auth], SettingController.subActivityTreatmentBillableType);
router.post("/subactivity/treatment/service/get", [auth], SettingController.subActivityTreatmentServiceGet);
router.post("/subactivity/get", [auth], SettingController.subActivityGetData);
router.post("/new/subactivity/save", [auth], SettingController.subActivitySetupSave);
router.post("/single/subactivity", [auth], SettingController.singleSubActivity);
router.post("/update/subactivity", [auth], SettingController.subActivityUpdate);
router.post("/subactivity/status/change", [auth], SettingController.subActivityStatusChange);
router.post("/delete/subactivity", [auth], SettingController.subActivityDelete);

// =======================================================================

// =================== SETTING/ Add Staff type =======================
router.post("/all/staff/types", [auth], SettingController.employeeGetAll);
router.post("/selected/staff/types", [auth], SettingController.allSelectedEmployee);
router.post("/add/staff/type/to/selected", [auth], SettingController.addEmployeeToFacilitySelected);
router.post("/remove/staff/type/from/selected", [auth], SettingController.removeStaffFromFacility);
// =======================================================================

// =================== SETTING/ Place of Service =======================
router.post("/list/pos/code", [auth], SettingController.posListWithPagination);
router.post("/list/all/pos/code", [auth], SettingController.listPOS);
router.post("/add/pos/code", [auth], SettingController.addPOS);
router.post("/single/pos/code", [auth], SettingController.singlePOS);
router.post("/update/pos/code", [auth], SettingController.updatePOS);
router.post("/delete/pos/code", [auth], SettingController.deletePOS);
// =======================================================================

// =================== SETTING/ Pay Period =======================
router.post("/list/pay/period", [auth], SettingController.allPayperiods);
router.post("/pay/period/add", [auth], SettingController.payPeriodSave);
router.post("/pay/period/update", [auth], SettingController.payPeriodUpdate);
router.post("/pay/period/delete", [auth], SettingController.deletePayPeriod);
router.post("/pay/period/bulk/delete", [auth], SettingController.bulkDeletePayPeriod);

// =================== SETTING/ Vendor Number Setup =======================
router.post("/vendor/number", [auth], SettingController.vendorNumber);
router.post("/vendor/number/regional/center", [auth], SettingController.vendorNumberRegionalCenter);
router.post("/vendor/number/list", [auth], SettingController.getVendorNumberList);
router.post("/add/vendor/number", [auth], SettingController.addVendorNumber);
router.post("/update/vendor/number", [auth], SettingController.vendorNumberUpdate);
router.post("/delete/vendor/number", [auth], SettingController.deleteVendorNumber);
// =================== SETTING/ Referring Provider =======================
router.post("/list/referring/provider", [auth], SettingController.referringProviderWithPagination);
router.post("/list/all/referring/provider", [auth], SettingController.referringProviderList);
router.post("/add/referring/provider", [auth], SettingController.addReferringProvider);
router.post("/single/referring/provider", [auth], SettingController.singleReferringProvider);
router.post("/update/referring/provider", [auth], SettingController.updateReferringProvider);
router.post("/delete/referring/provider", [auth], SettingController.deleteReferringProvider);
// =======================================================================

// =================== SETTING/ Holiday setup =======================
router.post("/all/holiday", [auth], SettingController.holidaySetup);
router.post("/new/holiday/save", [auth], SettingController.holidaySetupSave);
router.post("/federal/holiday/save", [auth], SettingController.federalHolidaySave);
router.post("/holiday/delete", [auth], SettingController.holidayDelete);
export default router;
