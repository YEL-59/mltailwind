import express from "express";

let router = express.Router();
import { auth } from "../../middleware/AuthMiddleware.js";
import CommonController from "../../controller/InternalAdmin/Common/CommonController.js";

router.post("/global/patient/list", [auth], CommonController.globalPatientList);
router.post("/global/provider/list", [auth], CommonController.globalProviderList);
