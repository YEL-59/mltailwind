import express from "express";

let router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";

import CashPostingController from "../../../controller/InternalAdmin/Payments/CashPostingController.js";
import CommonController from "../../../controller/InternalAdmin/Common/CommonController.js";

//deposit
router.post("/patient/list", [auth], CommonController.globalPatientList);
router.post("/insurance/list", [auth], CommonController.globalSelectedFacility);
router.post("/list", [auth], CashPostingController.cashPostingList);
router.post("/create", [auth], CashPostingController.cashPostingCreate);
router.post("/edit", [auth], CashPostingController.cashPostingEdit);
router.post("/update", [auth], CashPostingController.cashPostingUpdate);
router.post("/delete", [auth], CashPostingController.cashPostingDelete);

//select action
router.post("/get/transactions", [auth], CashPostingController.depGetTransactions);
router.post("/data/revert", [auth], CashPostingController.depDataRevert);

//deposit apply
router.post("/apply/by/depid/", [auth], CashPostingController.depApplyById);
router.post("/apply/show/adj/pay/top", [auth], CashPostingController.depAppShowAdjPayTop);
router.post("/apply/get/data", [auth], CashPostingController.depApplyGetData);
router.post("/apply/save/data", [auth], CashPostingController.depApplySaveData);

export default router;
