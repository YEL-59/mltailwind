import express from "express";

let router = express.Router();

import { auth } from "../../../middleware/AuthMiddleware.js";

import PriManageClaimController from "../../../controller/InternalAdmin/Billing/PriManageClaimController.js";

router.post("/get/batchid/list", [auth], PriManageClaimController.getBatchId);
router.post("/get/claimid/list", [auth], PriManageClaimController.getClaimId);
router.post("/get/patient/list", [auth], PriManageClaimController.getPatientList);
router.post("/get/tx/provider", [auth], PriManageClaimController.getTxProvider);
router.post("/get/cms/provider", [auth], PriManageClaimController.getCmsProvider);
router.post("/list", [auth], PriManageClaimController.manageClaimList);
router.post("/list/transaction", [auth], PriManageClaimController.manageClaimListTransaction);

export default router;
