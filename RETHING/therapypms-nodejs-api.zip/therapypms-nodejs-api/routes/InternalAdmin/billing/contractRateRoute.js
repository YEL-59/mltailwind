import express from "express";

let router = express.Router();

import { auth } from "../../../middleware/AuthMiddleware.js";
import ContractRateController from "../../../controller/InternalAdmin/Billing/ContractRateController.js";
import CommonController from "../../../controller/InternalAdmin/Common/CommonController.js";

router.post("/list/payor/facility", [auth], CommonController.globalSelectedFacility);
router.post("/list/setting/service", [auth], CommonController.globalSettingService);
router.post("/list/treatment/facility", [auth], CommonController.globalSelectedTreatment);
router.post("/list/all/suc/activity", [auth], CommonController.globalAllSubActivity);
router.post("/list", [auth], ContractRateController.billingRateList);
router.post("/add", [auth], ContractRateController.contractRateAdd);
router.post("/create", [auth], ContractRateController.contractRateCreate);
router.post("/edit", [auth], ContractRateController.contractRateEdit);
router.post("/update", [auth], ContractRateController.contractRateUpdate);
router.post("/delete", [auth], ContractRateController.contractRateDelete);

export default router;
