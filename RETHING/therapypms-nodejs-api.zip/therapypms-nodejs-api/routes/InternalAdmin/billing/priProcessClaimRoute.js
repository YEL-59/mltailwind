import express from "express";

let router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";

import PriProcessClaimController from "../../../controller/InternalAdmin/Billing/PriProcessClaimController.js";

router.post("/get/data/by/date", [auth], PriProcessClaimController.getAppointmentByDate);
router.post("/short/by/patient", [auth], PriProcessClaimController.shortByPatient);
router.post("/short/by/treating/therapist", [auth], PriProcessClaimController.shortByTreatingTherapist);
router.post("/short/by/cms/therapist", [auth], PriProcessClaimController.shortByCmsTherapist);
router.post("/short/by/activity/type", [auth], PriProcessClaimController.shortByActivityType);
router.post("/short/by/cpt", [auth], PriProcessClaimController.shortByCpt);
router.post("/short/by/modifire", [auth], PriProcessClaimController.shortByModifire);
router.post("/get/billing/data", [auth], PriProcessClaimController.getBillingData);
router.post("/billing/data/update", [auth], PriProcessClaimController.getBillingDataUpdate);

export default router;
