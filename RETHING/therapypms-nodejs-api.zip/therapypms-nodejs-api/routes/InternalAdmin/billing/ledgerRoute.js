import express from "express";

let router = express.Router();
import { auth } from "../../../middleware/AuthMiddleware.js";

import LedgerController from "../../../controller/InternalAdmin/Billing/LedgerController.js";
import CommonController from "../../../controller/InternalAdmin/Common/CommonController.js";

router.post("/list/patient", [auth], LedgerController.patientList);
router.post("/list/insurance", [auth], LedgerController.insuranceList);
router.post("/list/cpt", [auth], LedgerController.cptList);
router.post("/list/claim/wise", [auth], LedgerController.ledgerListClaimWise);
router.post("/list/ctp/wise", [auth], LedgerController.ledgerListCptWise);

export default router;
