import express from "express";

let router = express.Router();
import { check } from "express-validator";

import { adminAuth } from "../../controller/InternalAuth/AdminAuthController.js";

router.post("/", [check("email", "Email is required").isEmail(), check("password", "password is required").exists()], adminAuth);

export default router;
