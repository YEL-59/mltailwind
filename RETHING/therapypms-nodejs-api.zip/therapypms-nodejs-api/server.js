import express from "express";
import cors from "cors";
import "dotenv/config";


//swagger
import swaggerConfig from "./config/swaggerConfig.js";

//routes import
import authRoute from "./routes/InternalAdmin/authRoute.js";
import settingRoute from "./routes/InternalAdmin/settingRoute.js";
import PatientRoute from "./routes/InternalAdmin/patient/patientRoute.js";
import ProviderRoute from "./routes/InternalAdmin/provider/providerRroute.js";
import AppointmentRoute from "./routes/InternalAdmin/appointment/appointmentRoute.js";
import CalenderRoute from "./routes/InternalAdmin/appointment/calenderRoute.js";
import ManageSessionRoute from "./routes/InternalAdmin/appointment/manageSessionRoute.js";
import RecurringSessionRoute from "./routes/InternalAdmin/appointment/recurringSessionRoute.js";

// api routes
import HirasmusRoute from "./routes/Api/ExternamAdmin/Hirasmus/appointment.js";

// billing routes
import priPrcClmRoute from "./routes/InternalAdmin/billing/priProcessClaimRoute.js";
import priMngClmRoute from "./routes/InternalAdmin/billing/priManageClaimRoute.js";
import ledgerRoute from "./routes/InternalAdmin/billing/ledgerRoute.js";
import contractRateRoute from "./routes/InternalAdmin/billing/contractRateRoute.js";
import ptStatementRoute from "./routes/InternalAdmin/billing/patientStatementRoute.js";

//payment routes
import cashPostingRoute from "./routes/InternalAdmin/payment/cashPostingRoute.js";

//patient portal routes
import myScheduleRoute from "./routes/InternalPatient/mySchedule/myScheduleRoute.js";
import myStatementRoute from "./routes/InternalPatient/myStatement/myStatementRoute.js";
import myCalenderRoute from "./routes/InternalPatient/myCalender/myCalenderRoute.js";
import myInfoRoute from "./routes/InternalPatient/myInfo/infoRoute.js";
import myAuthRoute from "./routes/InternalPatient/myInfo/authRoute.js";

//provider portal routes
import providerScheduleRoute from "./routes/InternalProvider/providerSchedule/providerSessionRoute.js";
import providerRecurrinSessionRoute from "./routes/InternalProvider/providerRecurringSession/providerRecurringSessionRoute.js";
import providerPatientRoute from "./routes/InternalProvider/providerPatients/providerPatientRoute.js";
import providerTimesheetRoute from "./routes/InternalProvider/providerTimesheets/providerTimeSheetRoute.js";
import providerCalenderRoute from "./routes/InternalProvider/providerCalender/providerCalenderRoute.js";
import providerBiographicRoute from "./routes/InternalProvider/providerBiographic/providerBiographicRoute.js";
import ProviderContactInfoRoute from "./routes/InternalProvider/providerContactinfo/providerContactinfoRoute.js";
import ProviderCredentialRoute from "./routes/InternalProvider/providerCredntials/providerCredntialsRoute.js";
import providerClockInRoute from "./routes/InternalProvider/providerClockIn/providerClockInRoute.js";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// cors
// var corsOptions = {
//   origin: ["http://localhost:3000", "https://rtapp.therapypms.com/"],
//   optionsSuccessStatus: 200,
// };
app.use(
  cors({
    origin: "*",
  })
);

//init route
app.use("/api/v1/inadmin/auth", authRoute);
app.use("/api/v1/inadmin/setting", settingRoute);
app.use("/api/v1/inadmin/patient", PatientRoute);
app.use("/api/v1/inadmin/provider", ProviderRoute);
app.use("/api/v1/inadmin/appointment", AppointmentRoute);
app.use("/api/v1/inadmin/manage/session", ManageSessionRoute);
app.use("/api/v1/inadmin/calender", CalenderRoute);
app.use("/api/v1/inadmin/recurring/session", RecurringSessionRoute);

//billing routes
app.use("/api/v1/inadmin/pri/process/claim", priPrcClmRoute);
app.use("/api/v1/inadmin/pri/manage/claim", priMngClmRoute);
app.use("/api/v1/inadmin/ledger", ledgerRoute);
app.use("/api/v1/inadmin/contract/rate", contractRateRoute);
app.use("/api/v1/inadmin/cash/posting", cashPostingRoute);

//cashposting routes
app.use("/api/v1/inadmin/patient/statement", ptStatementRoute);

// api init route
app.use("/api/v1/admin/get/appointment", HirasmusRoute);

//patient portal routes
app.use("/api/v1/patient", myScheduleRoute);
app.use("/api/v1/patient/my/statement", myStatementRoute);
app.use("/api/v1/patient/my/calender", myCalenderRoute);
app.use("/api/v1/patient/my/info", myInfoRoute);
app.use("/api/v1/patient/my/all", myAuthRoute);

//provider portal routes
app.use("/api/v1/provider", providerScheduleRoute);
app.use("/api/v1/provider/recurring-session", providerRecurrinSessionRoute);
app.use("/api/v1/provider/calender", providerCalenderRoute);
app.use("/api/v1/provider/patients", providerPatientRoute);
app.use("/api/v1/provider/clock", providerClockInRoute);
app.use("/api/v1/provider/timesheet", providerTimesheetRoute);
app.use("/api/v1/provider/biographic", providerBiographicRoute);
app.use("/api/v1/provider/contact", ProviderContactInfoRoute);
app.use("/api/v1/provider/cred", ProviderCredentialRoute);

//swagger doc
app.use("/api-docs", swaggerConfig.swaggerServe, swaggerConfig.swaggerSetup);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
