/*======================================
Preloader
=========================================*/
$("my-preloaderr").html(
	`<div id="loading">
	    <div id="loading-center"></div>
	</div>`
);
/*======================================
Sidebar
=========================================*/
$("my-sidebar").html(`
<div class="iq-sidebar">
	<div class="iq-sidebar-logo d-flex justify-content-between">
		<a href="index.html">
			<img src="images/logo-new.png" class="img-fluid logo-big" alt="tpms">
			<img src="images/favicon.png" class="img-fluid logo-small" alt="tpms">
		</a>
		<div class="iq-menu-bt-sidebar">
			<div class="iq-menu-bt align-self-center">
				<div class="wrapper-menu">
					<div class="main-circle"><i class="ri-more-fill"></i></div>
					<div class="hover-circle"><i class="ri-more-2-fill"></i></div>
				</div>
			</div>
		</div>
	</div>
	<div id="sidebar-scrollbar">
		<nav class="iq-sidebar-menu">
			<ul id="iq-sidebar-toggle" class="iq-menu">
				<li>
					<a href="dashboard.html" class="iq-waves-effect"><i
							class="ri-home-4-line"></i><span>Dashboard </span></a>
				</li>
				<li  class="sidebar-button-spacing">
					<a href="#m1" class="iq-waves-effect collapsed" data-toggle="collapse"
						aria-expanded="false"><i class="fa fa-calendar"></i><span>Appointment</span><i
							class="ri-arrow-right-s-line iq-arrow-right"></i></a>
					<ul id="m1" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
						<li><a href="appointment.html" class="iq-waves-effect"><i
									class="ri-grid-fill"></i><span>List View</span></a></li>
						<li><a href="appointment-calender.html" class="iq-waves-effect"><i
									class="ri-calendar-line"></i><span>Calendar View</span></a></li>
						<li><a href="appointment-recurring.html" class="iq-waves-effect"><i
									class="ri-links-line"></i><span>Recurring Session </span></a></li>
					</ul>
				</li>
				<li class="sidebar-button-spacing">
					<a href="index.html" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Patient(s)
						</span></a>
				</li>
				<li class="sidebar-button-spacing">
					<a href="staff.html" class="iq-waves-effect"><i
							class="fa fa-user-md"></i><span>Staff</span></a>
				</li>
				<li class="sidebar-button-spacing">
					<a href="#mailbox" class="iq-waves-effect collapsed" data-toggle="collapse"
						aria-expanded="false"><i class="ri-exchange-dollar-line"></i><span>Billing</span><i
							class="ri-arrow-right-s-line iq-arrow-right"></i></a>
					<ul id="mailbox" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
						<li><a href="billing.html"><i class="lab la-hornbill"></i>Billing Manager</a>
						</li>
						<li><a href="billing-ledger.html"><i class="las la-donate"></i>Ar-Ledger</a></li>
						<li><a href="billing-ledger-scenario.html"><i class="las la-donate"></i>Ar-Ledger Scenario</a></li>
						<li><a href="billing-rate.html"><i class="lab la-gg"></i>Contract Rate</a></li>
						<li><a href="billing-statement.html"><i class="ri-shield-star-line"></i>Patient
								Statement</a></li>
						<li><a href="billing-eligibility.html"><i class="las la-address-card"></i>Eligibility</a></li>
					</ul>
				</li>
				<li class="sidebar-button-spacing">
					<a href="#mailboxa" class="iq-waves-effect collapsed" data-toggle="collapse"
						aria-expanded="false"><i class="fa fa-credit-card"></i><span>Payments</span><i
							class="ri-arrow-right-s-line iq-arrow-right"></i></a>
					<ul id="mailboxa" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
						<li><a href="payments-eremittance.html"><i
									class="ri-file-text-fill"></i>E-Remittance</a></li>
						<li><a href="payments-mremittance.html"><i class="las la-donate"></i>M-Remittance</a>
						</li>
						<li><a href="payments-era.html"><i class="ri-bill-line"></i>ERA Manager</a>
						</li>
					</ul>
				</li>
				<li class="sidebar-button-spacing">
					<a href="#mailboxp" class="iq-waves-effect collapsed" data-toggle="collapse"
						aria-expanded="false"><i class="ri-file-shred-line"></i><span>Payroll</span><i
							class="ri-arrow-right-s-line iq-arrow-right"></i></a>
					<ul id="mailboxp" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
						<li><a href="payroll.html" class="iq-waves-effect"><i
									class="ri-refund-line"></i><span>Processing Payroll</span></a></li>
						<li><a href="payroll-timesheet.html"><i class="ri-file-list-line"></i>Timesheet(s)
								Submission</a></li>
					</ul>
				</li>
				<li class="sidebar-button-spacing"><a href="report.html" class="iq-waves-effect"><i
							class="las la-chart-bar"></i><span>Report</span></a></li>
				<li class="sidebar-button-spacing"><a href="account-activity.html" class="iq-waves-effect"><i
							class="las la-file-archive"></i><span>Account Activity</span></a></li>
				<li class="sidebar-button-spacing"><a href="#" class="iq-waves-effect"><i class="las la-bell"></i><span>Reminders</span></a>
				</li>
				<li class="sidebar-button-spacing"><a href="setting.html" class="iq-waves-effect"><i
							class="las la-cogs"></i><span>Settings</span></a></li>
			</ul>
		</nav>
		<div class="p-3"></div>
	</div>
</div>
`);

/*======================================
Link up with reboot CSS file
=========================================*/
$("<link/>", {
	rel: "stylesheet",
	type: "text/css",
	href: "/css/reboot.css",
}).appendTo("head");

/*======================================
Topbar
=========================================*/
$("my-topbar").html(`
<div class="top-navbar-spacing iq-top-navbar header-top-sticky">
	<div class="iq-navbar-custom">
		<nav class="navbar navbar-expand-lg navbar-light p-0 top-navbar-user-btn top-relative">
			<div class="iq-search-bar d-flex align-items-center navbar-user-flex">
				<img src="images/man.jpg" class="img-fluid rounded-circle logo-big" alt="tpms"><h5>ABC
					Behavioral Therapy Center</h5>
			</div>
			
			<button class="top-navbar-toggler navbar-toggler menu-3-line-btn" type="button" data-toggle="collapse"
				data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				aria-expanded="false" aria-label="Toggle navigation"
				>
				<i class="ri-menu-3-line"></i>
			</button>
			
			<div class="iq-menu-bt align-self-center top-navbar-toggler">
				<div class="wrapper-menu">
					<div class="main-circle menu-3-dot"><i class="ri-more-fill"></i></div>
				</div>
			</div>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto navbar-list">
					<li class="nav-item iq-full-screen">
						<a href="#" class="iq-waves-effect" id="btnFullscreen"><i
								class="ri-fullscreen-line"></i></a>
					</li>
					<li class="nav-item">
						<a class="dropdown-toggle" href="#" data-toggle="dropdown"><i
								class="las la-plus"></i></a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="#"><i
									class="las la-plus-circle mr-2"></i>Updates</a>
							<a class="dropdown-item" href="https://ovh.therapypms.com/admin#"><i
									class="las la-calendar-plus mr-2"></i>Knowledge Base</a>
							<a class="dropdown-item" href="#requestEligibility" data-toggle="modal"><i
									class="las la-address-card mr-2"></i>Request Eligibility</a>
						</div>
					</li>
					
					<li class="nav-item">
						<a class="dropdown-toggle" href="#" data-toggle="dropdown"><i
								class="fa fa-fw fa-bullhorn black"></i></a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="#" ><i
									class="las la-plus-circle mr-2"></i>Updates</a>
							<a class="dropdown-item" href="https://ovh.therapypms.com/admin#"><i
									class="las la-calendar-plus mr-2"></i>Knowledge Base</a>
						</div>
					</li>


					<li class="nav-item dropdown">
						<a href="#" class="search-toggle iq-waves-effect">
							<i class="ri-download-2-line"></i>
						</a>
						<div class="iq-sub-dropdown">
							<div class="iq-card shadow-none m-0">
								<div class="iq-card-body p-0">
									<div class="bg-primary p-3">
										<h5 class="mb-0 text-white">Scheduled Export<small
												class="badge  badge-light float-right pt-1">5</small>
										</h5>
									</div>
									<div class="iq-sub-card download mh-300">
										<div class="d-flex">
											<div class="mr-3">
												<button type="button" class="btn p-0"><img
														class="avatar-30 rounded"
														src="images/cloud-computing.png"
														alt="tpms"></button>
											</div>
											<div class="flex-fill right-side">
												<h6 title="">report-insurance-collection-11635501307.csv
												</h6>
												<div class="overflow-hidden rounded-0">
													<p class="float-left m-0 text-success">CSV File</p>
												</div>
												<p class="text-muted m-0">15 hours ago</p>
												<p class="text-primary">Completed</p>
											</div>
										</div>
										<div class="d-flex">
											<div class="mr-3">
												<button type="button" class="btn p-0"><img
														class="avatar-30 rounded"
														src="images/cloud-computing.png"
														alt="tpms"></button>
											</div>
											<div class="flex-fill right-side">
												<h6 title="">report-insurance-collection-11635501307.csv
												</h6>
												<div class="overflow-hidden rounded-0">
													<p class="float-left m-0 text-success">CSV File</p>
												</div>
												<p class="text-muted m-0">15 hours ago</p>
												<p class="text-primary">Completed</p>
											</div>
										</div>
										<div class="d-flex">
											<div class="mr-3">
												<button type="button" class="btn p-0"><img
														class="avatar-30 rounded"
														src="images/cloud-computing.png"
														alt="tpms"></button>
											</div>
											<div class="flex-fill right-side">
												<h6 title="">report-insurance-collection-11635501307.csv
												</h6>
												<div class="overflow-hidden rounded-0">
													<p class="float-left m-0 text-success">CSV File</p>
												</div>
												<p class="text-muted m-0">15 hours ago</p>
												<p class="text-primary">Completed</p>
											</div>
										</div>
										<div class="d-flex">
											<div class="mr-3">
												<button type="button" class="btn p-0"><img
														class="avatar-30 rounded"
														src="images/cloud-computing.png"
														alt="tpms"></button>
											</div>
											<div class="flex-fill right-side">
												<h6 title="">report-insurance-collection-11635501307.csv
												</h6>
												<div class="overflow-hidden rounded-0">
													<p class="float-left m-0 text-success">CSV File</p>
												</div>
												<p class="text-muted m-0">15 hours ago</p>
												<p class="text-primary">Completed</p>
											</div>
										</div>
										<div class="d-flex">
											<div class="mr-3">
												<button type="button" class="btn p-0"><img
														class="avatar-30 rounded"
														src="images/cloud-computing.png"
														alt="tpms"></button>
											</div>
											<div class="flex-fill right-side">
												<h6 title="">report-insurance-collection-11635501307.csv
												</h6>
												<div class="overflow-hidden rounded-0">
													<p class="float-left m-0 text-success">CSV File</p>
												</div>
												<p class="text-muted m-0">15 hours ago</p>
												<p class="text-primary">Completed</p>
											</div>
										</div>
									</div>
									<div class="text-center my-2">
										<a href="download-detail.html" class="btn btn-sm btn-primary">
											View More
										</a>
									</div>
								</div>
							</div>
						</div>
					</li>
					<li class="nav-item">
						<a href="#" class="search-toggle iq-waves-effect">
							<i class="ri-notification-3-fill"></i>
						</a>
						<div class="iq-sub-dropdown">
							<div class="iq-card shadow-none m-0">
								<div class="iq-card-body p-0 ">
									<div class="bg-primary p-3">
										<h5 class="mb-0 text-white">All Notifications<small
												class="badge  badge-light float-right pt-1">4</small>
										</h5>
									</div>
									<a href="notification.html" class="iq-sub-card">
										<div class="media align-items-center">
											<div class="">
												<img class="avatar-40 rounded img-fluid border"
													src="images/user/02.jpg" alt="therapy">
											</div>
											<div class="media-body ml-3">
												<h6 class="mb-0 ">New customer is join</h6>
												<small class="float-right font-size-12">5 days
													ago</small>
												<p class="mb-0">Jond Bini</p>
											</div>
										</div>
									</a>
									<a href="notification.html" class="iq-sub-card">
										<div class="media align-items-center">
											<div class="">
												<img class="avatar-40 rounded img-fluid border"
													src="images/user/03.jpg" alt="therapy">
											</div>
											<div class="media-body ml-3">
												<h6 class="mb-0 ">Two customer is left</h6>
												<small class="float-right font-size-12">2 days
													ago</small>
												<p class="mb-0">Jond Bini</p>
											</div>
										</div>
									</a>
								</div>
							</div>
						</div>
					</li>
					<li class="nav-item">
						<a href="lockscreen/lockscreen.html" title="Lock Screen"
							class="iq-waves-effect"><i class="ri-lock-line"></i></a>
					</li>
					
				</ul>
			</div>
			<ul class="navbar-list">
				<li>
					<a href="#" class="search-toggle iq-waves-effect d-flex align-items-center">
						<img src="images/user/1.jpg" class="img-fluid rounded mr-3" alt="user">
						<div class="caption">
							<h6 class="mb-0 line-height">Bini Jets</h6>
							<span class="font-size-12">Available</span>
						</div>
					</a>
					<div class="iq-sub-dropdown iq-user-dropdown">
						<div class="iq-card shadow-none m-0">
							<div class="iq-card-body p-0 ">
								<div class="bg-primary p-3">
									<h5 class="mb-0 text-white line-height">Hello Bini Jets</h5>
									<span class="text-white font-size-12">Available</span>
								</div>
								<a href="profile.html" class="iq-sub-card iq-bg-primary-hover">
									<div class="media align-items-center">
										<div class="rounded iq-card-icon iq-bg-primary">
											<i class="ri-file-user-line"></i>
										</div>
										<div class="media-body ml-3">
											<h6 class="mb-0 ">My Profile</h6>
											<p class="mb-0 font-size-12">View personal profile details.
											</p>
										</div>
									</div>
								</a>
								<a href="profile-edit.html" class="iq-sub-card iq-bg-primary-hover">
									<div class="media align-items-center">
										<div class="rounded iq-card-icon iq-bg-primary">
											<i class="ri-lock-line"></i>
										</div>
										<div class="media-body ml-3">
											<h6 class="mb-0 ">Change Password</h6>
											<p class="mb-0 font-size-12">Update your password.
											</p>
										</div>
									</div>
								</a>
								<div class="d-inline-block w-100 text-center p-3">
									<a class="bg-primary iq-sign-btn" href="sign-in.html"
										role="button">Sign out<i class="ri-login-box-line ml-2"></i></a>
								</div>
							</div>
						</div>
					</div>
				</li>
			</ul>
		</nav>
	</div>
</div>
<!-- Create Client -->
<div class="modal fade" id="createClient" data-backdrop="static">
	<div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<h4>Create Patient</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<iframe id="HW_frame" class="HW_frame" src="https://headway-widget.net/widgets/7vWVzJ" referrerpolicy="strict-origin" sandbox="allow-same-origin allow-scripts allow-top-navigation allow-popups allow-forms allow-popups-to-escape-sandbox" tabindex="0" aria-hidden="false" style="height: 311px;"></iframe>
		</div>
	</div>
</div>
<!-- Create Appointement -->
<div class="modal fade appointment" id="createAppointement" data-backdrop="static">
	<div class="modal-dialog modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header">
				<h4>Add Appoinments</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<form action="#" novalidate>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-4 mb-2">
							<label>App Type</label>
						</div>
						<div class="col-md-8 mb-2">
							<div class="row">
								<div class="col-md-4 align-self-center">
									<div class="custom-control custom-switch app-switch">
									<input type="checkbox" class="custom-control-input" id="bn" checked>
									<label class="custom-control-label" for="bn">Billable</label>
								</div>
							</div>
								<div class="col-md-8 align-self-center">
									<button type="button" class="btn btn-sm btn-success"><i class="ri-vidicon-fill align-middle mr-1"></i> <span class="align-middle"></span>Start Video Appointment</button>
								</div>
							</div>
						</div>
						<div class="col-md-4 mb-2">
							<label>Patient Name</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Alabama</option>
							</select>
						</div>
						<div class="col-md-4 mb-2">
							<label>Authorization</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Alabama</option>
							</select>
						</div>
						<div class="col-md-4 mb-2">
							<label>Service Type</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Alabama</option>
							</select>
						</div>
						<div class="col-md-4 mb-2">
							<label>Provider Name</label>
						</div>
						<div class="col-md-8 mb-2">
							<div class="billable-provider">
								<select class="form-control form-control-sm" required>
									<option></option>
									<option>Alabama</option>
								</select>
							</div>
							<div class="nonbillable-provider">
								<div class="input-group">
									<select class="form-control form-control-sm multiselect" multiple
										required>
										<option></option>
										<option>Alabama</option>
									</select>
									<div class="input-group-append ml-2">
										<button type="button" class="btn btn-sm btn-primary">
											All</button>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4 mb-2">
							<label>Place of Service</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Tele-health</option>
								<option>Office</option>
							</select>
						</div>
						<div class="col-md-4 mb-2">
							<label>Time Duration</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option value="15">15 mins</option>
								<option value="30">30 mins</option>
								<option value="45">45 mins</option>
								<option value="60">1 Hour</option>
								<option value="75">1 Hour 15 mins</option>
								<option value="90">1 Hour 30 mins</option>
								<option value="105">1 Hour 45 mins</option>
								<option value="120">2 Hour</option>
								<option value="135">2 Hour 15 mins</option>
								<option value="150">2 Hour 30 mins</option>
								<option value="165">2 Hour 45 mins</option>
								<option value="180">3 Hour</option>
								<option value="195">3 Hour 15 mins</option>
								<option value="210">3 Hour 30 mins</option>
								<option value="225">3 Hour 45 mins</option>
								<option value="240">4 Hour</option>
								<option value="255">4 Hour 15 mins</option>
								<option value="270">4 Hour 30 mins</option>
								<option value="285">4 Hour 45 mins</option>
								<option value="300">5 Hour</option>
								<option value="315">5 Hour 15 mins</option>
								<option value="330">5 Hour 30 mins</option>
								<option value="345">5 Hour 45 mins</option>
								<option value="360">6 Hour</option>
								<option value="375">6 Hour 15 mins</option>
								<option value="390">6 Hour 30 mins</option>
								<option value="405">6 Hour 45 mins</option>
								<option value="420">7 Hour</option>
								<option value="435">7 Hour 15 mins</option>
								<option value="450">7 Hour 30 mins</option>
								<option value="465">7 Hour 45 mins</option>
								<option value="480">8 Hour</option>
								<option value="495">8 Hour 15 mins</option>
								<option value="510">8 Hour 30 mins</option>
								<option value="525">8 Hour 45 mins</option>
								<option value="540">9 Hour</option>
								<option value="555">9 Hour 15 mins</option>
								<option value="570">9 Hour 30 mins</option>
								<option value="585">9 Hour 45 mins</option>
								<option value="600">10 Hour</option>
							</select>
						</div>
						<div class="col-md-4 mb-2">
							<label>Date & Time</label>
						</div>
						<div class="col-md-8 mb-2">
							<div class="input-group">
								<input class="form-control form-control-sm date-time" type="datetime-local" required>
								<div class="input-group-append">
									<span class="input-group-text"><i class="ri-calendar-line"></i></span>
								</div>
							</div>
						</div>
						<div class="col-md-4 mb-2">
							<label>Status</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Scheduled</option>
								<option>No Show</option>
								<option>Hold</option>
								<option>Cancelled by Patient</option>
								<option>CC more than 24 hrs</option>
								<option>CC less than 24 hrs</option>
								<option>Cancelled by Provider</option>
								<option>Rendered</option>
							</select>
						</div>
						<div class="col-md-5">
							<div class="custom-control custom-switch rpattern-switch">
								<input type="checkbox" class="custom-control-input" id="rp">
								<label class="custom-control-label" for="rp">Recurrence Pattern?</label>
							</div>
							<div class="custom-control custom-switch daily-switch">
								<input type="checkbox" class="custom-control-input" id="dw" checked>
								<label class="custom-control-label" for="dw">Daily</label>
							</div>
						</div>
						<div class="col-md-7">
							<div class="row endate">
								<div class="col-md-12 mb-2">
									<input class="form-control form-control-sm" type="date">
								</div>
							</div>
							<div class="perday">
								<div class="form-check-inline">
									<label class="form-check-label">
										<input type="checkbox" class="form-check-input">SU
									</label>
								</div>
								<div class="form-check-inline">
									<label class="form-check-label">
										<input type="checkbox" class="form-check-input">MO
									</label>
								</div>
								<div class="form-check-inline">
									<label class="form-check-label">
										<input type="checkbox" class="form-check-input">TU
									</label>
								</div>
								<div class="form-check-inline">
									<label class="form-check-label">
										<input type="checkbox" class="form-check-input">WE
									</label>
								</div>
								<div class="form-check-inline">
									<label class="form-check-label">
										<input type="checkbox" class="form-check-input">TH
									</label>
								</div>
								<div class="form-check-inline">
									<label class="form-check-label">
										<input type="checkbox" class="form-check-input">FR
									</label>
								</div>
								<div class="form-check-inline">
									<label class="form-check-label">
										<input type="checkbox" class="form-check-input">SA
									</label>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Add Appoinments<i
							class='bx bx-loader align-middle ml-2'></i></button>
					<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				</div>
			</form>
		</div>
	</div>
</div>

<!-- Request Eligibility -->
<div class="modal fade appointment" id="requestEligibility" data-backdrop="static">
	<div class="modal-dialog modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header">
				<h4>New Eligibility Inquiry</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<form action="#" novalidate>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-4 mb-2"></div>
						<div class="col-md-8 mb-2">
							<div class="custom-control custom-switch bill-switch">
								<input type="checkbox" class="custom-control-input" id="bill" checked>
								<label class="custom-control-label" for="bill">Billable</label>
							</div>
						</div>
						<div class="col-md-4 mb-2">
							<label>Patient Name</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Alabama</option>
							</select>
						</div>
						<div class="col-md-4 mb-2">
							<label>Auth</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Alabama</option>
							</select>
						</div>
						<div class="col-md-4 mb-2">
							<label>Benefit Type</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Alabama</option>
							</select>
						</div>
						<div class="col-md-4 mb-2">
							<label>Date & Time</label>
						</div>
						<div class="col-md-8 mb-2">
							<div class="input-group">
								<input class="form-control form-control-sm date-time" type="datetime-local" required>
								<div class="input-group-append">
									<span class="input-group-text"><i class="ri-calendar-line"></i></span>
								</div>
							</div>
						</div>
						<div class="col-md-4 mb-2">
							<label>NPI</label>
						</div>
						<div class="col-md-8 mb-2">
							<select class="form-control form-control-sm" required>
								<option></option>
								<option>Scheduled</option>
								<option>No Show</option>
								<option>Hold</option>
								<option>Cancelled by Patient</option>
								<option>CC more than 24 hrs</option>
								<option>CC less than 24 hrs</option>
								<option>Cancelled by Provider</option>
								<option>Rendered</option>
							</select>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Request Eligibility<i
							class='bx bx-loader align-middle ml-2'></i></button>
					<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				</div>
			</form>
		</div>
	</div>
</div>
`);
$(".nonbillable-provider").hide();
$(".daily-switch").hide();
$(".endate").hide();
$(".perday").hide();
$(".rpattern-switch input").click(function (e) {
	if ($(this).prop("checked") == true) {
		$(".endate").show();
		$(".daily-switch").show();
	} else if ($(this).prop("checked") == false) {
		$(".daily-switch").hide();
		$(".endate").hide();
		$(".perday").hide();
	}
});
$(".daily-switch input").click(function (e) {
	if ($(this).prop("checked") == true) {
		$(".perday").hide();
	} else if ($(this).prop("checked") == false) {
		$(".perday").show();
	}
});
$(".app-switch input").click(function (e) {
	if ($(this).prop("checked") == true) {
		$(".billable-provider").show();
		$(".nonbillable-provider").hide();
	} else if ($(this).prop("checked") == false) {
		$(".billable-provider").hide();
		$(".nonbillable-provider").show();
	}
});