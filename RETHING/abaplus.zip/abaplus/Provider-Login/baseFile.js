// Preloader
const preloader = document.querySelector('#loading');
preloader.innerHTML = `<div id="loading-center"></div>`
// Sidebar
const sidebar = document.querySelector('#sidebar');
sidebar.innerHTML = `
	<div class="iq-sidebar">
		<div class="iq-sidebar-logo d-flex justify-content-between">
			<a href="provider-scheduler.html">
				<img src="../images/logo-new.png" class="img-fluid logo-big" alt="tpms">
				<img src="../images/favicon.png" class="img-fluid logo-small" alt="tpms">
			</a>
			<div class="iq-menu-bt-sidebar">
				<div class="iq-menu-bt align-self-center">
					<div class="wrapper-menu">
						<div class="main-circle"><i class="ri-more-fill"></i></div>
						<div class="hover-circle"><i class="ri-more-2-fill"></i></div>
					</div>
				</div>
			</div>
		</div>
	    <div id="sidebar-scrollbar">
	        <nav class="iq-sidebar-menu">
	            <ul id="iq-sidebar-toggle" class="iq-menu">
	                <li>
	                    <a href="provider-scheduler.html" class="iq-waves-effect"><i class="ri-calendar-line"></i><span>My Schedule </span></a>
	                </li>
	                <li>
	                    <a href="../staff-edit.html" class="iq-waves-effect"><i class="fa fa-user-md"></i><span>Biographic </span></a>
	                </li>
	            </ul>
	        </nav>
	        <div class="p-3"></div>
	    </div>
	</div>
`
// Topbar
const topbar = document.querySelector('#topbar');
topbar.innerHTML = `
	<div class="iq-top-navbar header-top-sticky">
	    <div class="iq-navbar-custom">
	        <nav class="navbar navbar-expand-lg navbar-light p-0">
	            <div class="iq-search-bar">
	                <h5>ABC Behavioral Therapy Center</h5>
	            </div>
	            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	                <i class="ri-menu-3-line"></i>
	            </button>
	            <div class="iq-menu-bt align-self-center">
	                <div class="wrapper-menu">
	                    <div class="main-circle"><i class="ri-more-fill"></i></div>
	                    <div class="hover-circle"><i class="ri-more-2-fill"></i></div>
	                </div>
	            </div>
	            <div class="collapse navbar-collapse" id="navbarSupportedContent">
	                <ul class="navbar-nav ml-auto navbar-list">
	                    <li class="nav-item iq-full-screen">
	                        <a href="#" class="iq-waves-effect" id="btnFullscreen"><i class="ri-fullscreen-line"></i></a>
	                    </li>
	                    <li class="nav-item">
	                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"><i class="las la-plus"></i></a>
	                        <div class="dropdown-menu">
	                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#createClient"><i class="las la-plus-circle mr-2"></i>Create Patient</a>
	                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#createAppointement"><i class="las la-calendar-plus mr-2"></i>Create Appoinment</a>
	                        </div>
	                    </li>
	                    <li class="nav-item dropdown">
	                        <a href="#" class="search-toggle iq-waves-effect">
	                            <i class="ri-download-2-line"></i>
	                        </a>
	                        <div class="iq-sub-dropdown">
	                            <div class="iq-card shadow-none m-0">
	                                <div class="iq-card-body p-0 mh-300">
	                                    <div class="bg-primary p-3">
	                                        <h5 class="mb-0 text-white">Scheduled Export<small class="badge  badge-light float-right pt-1">5</small></h5>
	                                    </div>
	                                    <a href="#" class="iq-sub-card">
	                                        <div class="media align-items-center">
	                                            <div class="download">
	                                                <img class="avatar-30 rounded" src="../images/cloud-computing.png" alt="aba+">
	                                            </div>
	                                            <div class="media-body ml-3">
	                                                <h6 class="mb-0">Download File</h6>
	                                                <small class="float-left text-primary font-size-12">Completed</small>
	                                            </div>
	                                        </div>
	                                    </a>
	                                    <a href="#" class="iq-sub-card">
	                                        <div class="media align-items-center">
	                                            <div class="download">
	                                                <img class="avatar-30 rounded" src="../images/cloud-computing.png" alt="aba+">
	                                            </div>
	                                            <div class="media-body ml-3">
	                                                <h6 class="mb-0">Download File</h6>
	                                                <small class="float-left text-primary font-size-12">Completed</small>
	                                            </div>
	                                        </div>
	                                    </a>
	                                    <a href="#" class="iq-sub-card">
	                                        <div class="media align-items-center">
	                                            <div class="download">
	                                                <img class="avatar-30 rounded" src="../images/cloud-computing.png" alt="aba+">
	                                            </div>
	                                            <div class="media-body ml-3">
	                                                <h6 class="mb-0">Download File</h6>
	                                                <small class="float-left text-danger font-size-12">Pending</small>
	                                            </div>
	                                        </div>
	                                    </a>
	                                    <a href="#" class="iq-sub-card">
	                                        <div class="media align-items-center">
	                                            <div class="download">
	                                                <img class="avatar-30 rounded" src="../images/cloud-computing.png" alt="aba+">
	                                            </div>
	                                            <div class="media-body ml-3">
	                                                <h6 class="mb-0">Download File</h6>
	                                                <small class="float-left text-primary font-size-12">Completed</small>
	                                            </div>
	                                        </div>
	                                    </a>
	                                    <a href="#" class="iq-sub-card">
	                                        <div class="media align-items-center">
	                                            <div class="download">
	                                                <img class="avatar-30 rounded" src="../images/cloud-computing.png" alt="aba+">
	                                            </div>
	                                            <div class="media-body ml-3">
	                                                <h6 class="mb-0">Download File</h6>
	                                                <small class="float-left text-danger font-size-12">Pending</small>
	                                            </div>
	                                        </div>
	                                    </a>
	                                    <div class="text-center my-2">
	                                        <a href="download-detail.html" class="btn btn-sm btn-primary">
	                                            View More
	                                        </a>
	                                    </div>
	                                </div>
	                            </div>
	                        </div>
	                    </li>
	                </ul>
	            </div>
	            <ul class="navbar-list">
	                <li>
	                    <a href="#" class="search-toggle iq-waves-effect d-flex align-items-center">
	                        <img src="../images/user/1.jpg" class="img-fluid rounded mr-3" alt="user">
	                        <div class="caption">
	                            <h6 class="mb-0 line-height">Bini Jets</h6>
	                            <span class="font-size-12">Available</span>
	                        </div>
	                    </a>
	                    <div class="iq-sub-dropdown iq-user-dropdown">
	                        <div class="iq-card shadow-none m-0">
	                            <div class="iq-card-body p-0 ">
	                                <div class="bg-primary p-3">
	                                    <h5 class="mb-0 text-white line-height">Hello Bini Jets</h5>
	                                    <span class="text-white font-size-12">Available</span>
	                                </div>
	                                <a href="profile.html" class="iq-sub-card iq-bg-primary-hover">
	                                    <div class="media align-items-center">
	                                        <div class="rounded iq-card-icon iq-bg-primary">
	                                            <i class="ri-file-user-line"></i>
	                                        </div>
	                                        <div class="media-body ml-3">
	                                            <h6 class="mb-0 ">My Profile</h6>
	                                            <p class="mb-0 font-size-12">View personal profile details.</p>
	                                        </div>
	                                    </div>
	                                </a>
	                                <a href="profile-edit.html" class="iq-sub-card iq-bg-primary-hover">
	                                    <div class="media align-items-center">
	                                        <div class="rounded iq-card-icon iq-bg-primary">
	                                            <i class="ri-profile-line"></i>
	                                        </div>
	                                        <div class="media-body ml-3">
	                                            <h6 class="mb-0 ">Edit Profile</h6>
	                                            <p class="mb-0 font-size-12">Modify your personal details.</p>
	                                        </div>
	                                    </div>
	                                </a>
	                                <div class="d-inline-block w-100 text-center p-3">
	                                    <a class="bg-primary iq-sign-btn" href="sign-in.html" role="button">Sign out<i class="ri-login-box-line ml-2"></i></a>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </li>
	            </ul>
	        </nav>
	    </div>
	</div>
	<!-- Create Client -->
	<div class="modal fade" id="createClient" data-backdrop="static">
	    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
	        <div class="modal-content">
	            <div class="modal-header">
	                <h4>Create Patient</h4>
	                <button type="button" class="close" data-dismiss="modal">&times;</button>
	            </div>
	            <form action="#">
	                <div class="modal-body">
	                    <div class="row">
	                        <div class="col-md-6 mb-2">
	                            <label>First Name<span class="text-danger">*</span></label>
	                            <input type="text" class="form-control form-control-sm" required>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <label>Last Name<span class="text-danger">*</span></label>
	                            <input type="text" class="form-control form-control-sm" required>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>DOB<span class="text-danger">*</span></label>
	                            <input type="date" class="form-control form-control-sm" required>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Gender<span class="text-danger">*</span></label>
	                            <select class="form-control form-control-sm" required>
	                                <option>Male</option>
	                                <option>Female</option>
	                            </select>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>POS<span class="text-danger">*</span></label>
	                            <select class="form-control form-control-sm" required>
	                                <option>Main Office</option>
	                                <option>Telehealth</option>
	                                <option>Home</option>
	                            </select>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <label>Email Address <i class="ri-question-line" title="To grant Patient Portal access, enter an email address"></i><span class="text-danger">*</span></label>
	                            <div class="row no-gutters">
	                                <div class="col-md-8 mb-2">
	                                    <input type="email" class="form-control form-control-sm" required>
	                                </div>
	                                <div class="col-md-4 pl-2 mb-2">
	                                    <select class="form-control form-control-sm">
	                                        <option value="Work">Work</option>
	                                        <option value="Home">Home</option>
	                                    </select>
	                                </div>
	                                <div class="col-md-12">
	                                    <div class="form-check">
	                                        <label class="form-check-label">
	                                            <input type="checkbox" class="form-check-input">Send me an email reminder
	                                        </label>
	                                    </div>
	                                </div>
	                            </div>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <label>Phone Number<span class="text-danger">*</span></label>
	                            <div class="row no-gutters">
	                                <div class="col-md-8 mb-2">
	                                    <input type="text" class="form-control form-control-sm" data-mask="(000)-000-0000" pattern=".{14,}" required="" autocomplete="off" maxlength="14">
	                                </div>
	                                <div class="col-md-4 pl-2 mb-2">
	                                    <select class="form-control form-control-sm">
	                                        <option value="Work">Work</option>
	                                        <option value="Home">Home</option>
	                                    </select>
	                                </div>
	                                <div class="col-md-12">
	                                    <div class="form-check">
	                                        <label class="form-check-label">
	                                            <input type="radio" class="form-check-input" name="text">Send me a text message
	                                        </label>
	                                    </div>
	                                    <div class="form-check">
	                                        <label class="form-check-label">
	                                            <input type="radio" class="form-check-input" name="text">Send me a voice message
	                                        </label>
	                                    </div>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="modal-footer">
	                    <button type="submit" class="btn btn-primary">Create & Continue<i class='bx bx-loader align-middle ml-2'></i></button>
	                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
	                </div>
	            </form>
	        </div>
	    </div>
	</div>
	<!-- Create Appointement -->
	<div class="modal fade" id="createAppointement" data-backdrop="static">
	    <div class="modal-dialog modal-dialog-scrollable">
	        <div class="modal-content">
	            <div class="modal-header">
	                <h4>Add/Edit Appoinments</h4>
	                <button type="button" class="close" data-dismiss="modal">&times;</button>
	            </div>
	            <form action="#">
	                <div class="modal-body">
	                    <div class="row">
	                        <div class="col-md-4 mb-2">
	                            <label>App Type</label>
	                        </div>
	                        <div class="col-md-8 mb-2">
	                            <div class="form-check-inline">
	                                <label class="form-check-label">
	                                    <input type="radio" class="form-check-input" name="billable" checked>Billable
	                                </label>
	                            </div>
	                            <div class="form-check-inline">
	                                <label class="form-check-label">
	                                    <input type="radio" class="form-check-input" name="billable">Non-Billable
	                                </label>
	                            </div>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Patient Name</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <select class="form-control form-control-sm" required>
	                                <option></option>
	                                <option>Alabama</option>
	                                <option>Alaska</option>
	                                <option>Arizona</option>
	                                <option>Arkansas</option>
	                                <option>California</option>
	                                <option>Colorado</option>
	                                <option>Connecticut</option>
	                                <option>Delaware</option>
	                                <option>District of Columbia</option>
	                                <option>Florida</option>
	                                <option>Georgia</option>
	                                <option>Hawaii</option>
	                                <option>Idaho</option>
	                                <option>Illinois</option>
	                                <option>Indiana</option>
	                            </select>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Auth</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <select class="form-control form-control-sm" required>
	                                <option></option>
	                                <option>Alabama</option>
	                                <option>Alaska</option>
	                                <option>Arizona</option>
	                                <option>Arkansas</option>
	                                <option>California</option>
	                                <option>Colorado</option>
	                                <option>Connecticut</option>
	                                <option>Delaware</option>
	                                <option>District of Columbia</option>
	                                <option>Florida</option>
	                                <option>Georgia</option>
	                                <option>Hawaii</option>
	                                <option>Idaho</option>
	                                <option>Illinois</option>
	                                <option>Indiana</option>
	                            </select>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Service</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <select class="form-control form-control-sm" required>
	                                <option></option>
	                                <option>Alabama</option>
	                                <option>Alaska</option>
	                                <option>Arizona</option>
	                                <option>Arkansas</option>
	                                <option>California</option>
	                                <option>Colorado</option>
	                                <option>Connecticut</option>
	                                <option>Delaware</option>
	                                <option>District of Columbia</option>
	                                <option>Florida</option>
	                                <option>Georgia</option>
	                                <option>Hawaii</option>
	                                <option>Idaho</option>
	                                <option>Illinois</option>
	                                <option>Indiana</option>
	                            </select>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Provider Name</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <select class="form-control form-control-sm" required>
	                                <option></option>
	                                <option>Alabama</option>
	                                <option>Alaska</option>
	                                <option>Arizona</option>
	                                <option>Arkansas</option>
	                                <option>California</option>
	                                <option>Colorado</option>
	                                <option>Connecticut</option>
	                                <option>Delaware</option>
	                                <option>District of Columbia</option>
	                                <option>Florida</option>
	                                <option>Georgia</option>
	                                <option>Hawaii</option>
	                                <option>Idaho</option>
	                                <option>Illinois</option>
	                                <option>Indiana</option>
	                            </select>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>POS</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <select class="form-control form-control-sm" required>
	                                <option></option>
	                                <option>Tele-health</option>
	                                <option>Office</option>
	                            </select>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Time Duration</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <select class="form-control form-control-sm" required>
	                                <option></option>
	                                <option value="15">15 mins</option>
	                                <option value="30">30 mins</option>
	                                <option value="45">45 mins</option>
	                                <option value="60">1 Hour</option>
	                                <option value="75">1 Hour 15 mins</option>
	                                <option value="90">1 Hour 30 mins</option>
	                                <option value="105">1 Hour 45 mins</option>
	                                <option value="120">2 Hour</option>
	                                <option value="135">2 Hour 15 mins</option>
	                                <option value="150">2 Hour 30 mins</option>
	                                <option value="165">2 Hour 45 mins</option>
	                                <option value="180">3 Hour</option>
	                                <option value="195">3 Hour 15 mins</option>
	                                <option value="210">3 Hour 30 mins</option>
	                                <option value="225">3 Hour 45 mins</option>
	                                <option value="240">4 Hour</option>
	                                <option value="255">4 Hour 15 mins</option>
	                                <option value="270">4 Hour 30 mins</option>
	                                <option value="285">4 Hour 45 mins</option>
	                                <option value="300">5 Hour</option>
	                                <option value="315">5 Hour 15 mins</option>
	                                <option value="330">5 Hour 30 mins</option>
	                                <option value="345">5 Hour 45 mins</option>
	                                <option value="360">6 Hour</option>
	                                <option value="375">6 Hour 15 mins</option>
	                                <option value="390">6 Hour 30 mins</option>
	                                <option value="405">6 Hour 45 mins</option>
	                                <option value="420">7 Hour</option>
	                                <option value="435">7 Hour 15 mins</option>
	                                <option value="450">7 Hour 30 mins</option>
	                                <option value="465">7 Hour 45 mins</option>
	                                <option value="480">8 Hour</option>
	                                <option value="495">8 Hour 15 mins</option>
	                                <option value="510">8 Hour 30 mins</option>
	                                <option value="525">8 Hour 45 mins</option>
	                                <option value="540">9 Hour</option>
	                                <option value="555">9 Hour 15 mins</option>
	                                <option value="570">9 Hour 30 mins</option>
	                                <option value="585">9 Hour 45 mins</option>
	                                <option value="600">10 Hour</option>
	                            </select>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Date & Time</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <input class="form-control form-control-sm" type="text" id="datetime1" placeholder="Select Date and Time" required>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Status</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <select class="form-control form-control-sm" required>
	                                <option></option>
	                                <option>Scheduled</option>
	                                <option>No Show</option>
	                                <option>Hold</option>
	                                <option>Cancelled by Patient</option>
	                                <option>CC more than 24 hrs</option>
	                                <option>CC less than 24 hrs</option>
	                                <option>Cancelled by Provider</option>
	                                <option>Rendered</option>
	                            </select>
	                        </div>
	                        <div class="col-md-4 mb-2">
	                            <label>Office Notes</label>
	                        </div>
	                        <div class="col-md-6 mb-2">
	                            <textarea class="form-control form-control-sm"></textarea>
	                        </div>
	                        <div class="col-md-4">
	                            <div class="form-check mb-2">
	                                <label class="form-check-label">
	                                    <input type="checkbox" class="form-check-input rpattern">Recurrence Pattern?
	                                </label>
	                            </div>
	                            <div class="form-check-inline mb-2 daily">
	                                <label class="form-check-label">
	                                    <input type="radio" class="form-check-input" name="daily" checked>Daily
	                                </label>
	                            </div>
	                            <div class="form-check-inline mb-2 weekly">
	                                <label class="form-check-label">
	                                    <input type="radio" class="form-check-input" name="daily">Weekly
	                                </label>
	                            </div>
	                        </div>
	                        <div class="col-md-8">
	                            <div class="row endate">
	                                <div class="col-md-9 mb-2">
	                                    <input class="form-control form-control-sm" type="date">
	                                </div>
	                            </div>
	                            <div class="perday">
	                                <div class="form-check-inline">
	                                    <label class="form-check-label">
	                                        <input type="checkbox" class="form-check-input">SU
	                                    </label>
	                                </div>
	                                <div class="form-check-inline">
	                                    <label class="form-check-label">
	                                        <input type="checkbox" class="form-check-input">MO
	                                    </label>
	                                </div>
	                                <div class="form-check-inline">
	                                    <label class="form-check-label">
	                                        <input type="checkbox" class="form-check-input">TU
	                                    </label>
	                                </div>
	                                <div class="form-check-inline">
	                                    <label class="form-check-label">
	                                        <input type="checkbox" class="form-check-input">WE
	                                    </label>
	                                </div>
	                                <div class="form-check-inline">
	                                    <label class="form-check-label">
	                                        <input type="checkbox" class="form-check-input">TH
	                                    </label>
	                                </div>
	                                <div class="form-check-inline">
	                                    <label class="form-check-label">
	                                        <input type="checkbox" class="form-check-input">FR
	                                    </label>
	                                </div>
	                                <div class="form-check-inline">
	                                    <label class="form-check-label">
	                                        <input type="checkbox" class="form-check-input">SA
	                                    </label>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="modal-footer">
	                    <button type="submit" class="btn btn-primary">Add Appoinments<i class='bx bx-loader align-middle ml-2'></i></button>
	                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
	                </div>
	            </form>
	        </div>
	    </div>
	</div>
`
jQuery(document).ready(function ($) {
	$('.daily').hide();
	$('.weekly').hide();
	$('.endate').hide();
	$('.perday').hide();
	$('.rpattern').click(function (event) {
		if ($(this).is(':checked')) {
			$('.daily').show();
			$('.weekly').show();
			$('.endate').show();
		} else {
			$('.daily').hide();
			$('.weekly').hide();
			$('.endate').hide();
			$('.perday').hide();
		}
	});
	$('.daily').click(function (event) {
		if ($(this).prop("checked", true)) {
			$('.perday').hide();
		}
	});
	$('.weekly').click(function (event) {
		if ($(this).prop("checked", true)) {
			$('.endate').show();
			$('.perday').show();
		}
	});
});