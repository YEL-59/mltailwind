/*======================================
Setting Menu
=========================================*/
$("setting-menu").html(`
<div class="setting_menu">
	<ul class="nav flex-column">
		<!-- Facility Setup  -->
		<li class="nav-item">
			<a href="javascript:void(0);" class="nav-link active">
				<i class="fa fa-medkit"></i>
				Facility Setup
			</a>
			<div id="facility">
				<a href="setting.html"><i class="ri-profile-line"></i>Name &
					Location</a>
				<a href="setting-create-insurance.html"><i class="ri-user-add-line"></i>Add Insurance</a>
				<a href="setting-insurance-setup.html"><i class="ri-settings-line"></i>Insurance Setup</a>
				<a href="setting-create-treatment.html"><i class="ri-hospital-line"></i>Add
					Treatment</a>
				<a href="setting-create-service.html"><i class="ri-stack-line"></i>Add Services</a>
				<a href="setting-create-cpt.html"><i class="ri-stack-line"></i>Add CPT</a>
				<a href="setting-subtype.html"><i class="ri-navigation-line"></i>Service Sub-Type</a>
				<a href="setting-rendering-provider.html"><i class="ri-user-line"></i>Rendering Provider</a>
				<a href="setting-pos.html"><i class="ri-home-3-line"></i>Place of Service</a>
				<a href="setting-create-staff.html"><i class="ri-user-add-line"></i>Add Staff Type</a>
				<a href="setting-vendor.html"><i class="ri-notification-badge-line"></i>Vendor Number Setup</a>
				<a href="setting-holiday.html"><i class="ri-anchor-line"></i>Holiday Setup</a>
				<a href="setting-payperiod.html"><i class="ri-bank-card-line"></i>Pay Period</a>
				<a href="setting-logo.html"><i class="ri-attachment-2"></i>Logo</a>
				<a href="setting-unbillable.html"><i class="ri-folders-line"></i>Unbillable Activity</a>
				<a href="setting-unbillable-timesheet.html"><i class="ri-folders-line"></i>Unbillable Timesheet</a>
				<a href="setting-create-servicerule.html"><i class="ri-file-line"></i>Create Service Rules</a>
				<a href="setting-staff-setup.html"><i class="ri-shield-user-line"></i>Staff
					Setup</a>
				<a href="setting-formbuilder.html"><i class="fa fa-file-text-o"></i>Forms Builder</a>
				<a href="setting-formlib.html"><i class="fa fa-file-text-o"></i>Forms & Library</a>
				<a href="setting-businessdoc.html"><i class="fa fa-file-o"></i>Business Files</a>
				<a href="setting-dataexport.html"><i class="fa fa-exchange"></i>Data Import</a>
				<a href="setting-bulk-upload.html"><i class="fa fa-exchange"></i>Bulk Upload</a>
				<a href="setting-payment-gateway.html"><i class="fa fa-usd"></i>Payment Gateway</a>
					<a href="#program"><i class="fa fa-th"></i><span>Program</span><i
							class="fa fa-arrow-down ml-3"></i></a>
					<ul id="program" style="list-style-type: none; border-bottom: 1px solid #089bab;">
						<li style="border-left: 1px solid #089bab"><a href="setting-account-type.html" class="iq-waves-effect"><i class="fa fa-user-o"></i><span>Account Type</span></a></li>
						<li style=" border-left: 1px solid #089bab"><a href="setting-program-category.html" class="iq-waves-effect"><i
									class="fa fa-file-text-o"></i><span>Program Category</span></a></li>
						<li style="border-left: 1px solid #089bab"><a href="setting-create-program.html" class="iq-waves-effect"><i
									class="fa fa-plus-square-o"></i><span>All Programs</span></a></li>
					</ul>
			</div>
		</li>
	</ul>
</div>
`);
const currentLocation = location.href;
const menuItem = document.querySelectorAll("#facility a");
const menuLength = menuItem.length;
for (let i = 0; i < menuLength; i++) {
  if (menuItem[i].href == currentLocation) {
    menuItem[i].className = "active";
  }
}
