/*======================================
Setting Menu
=========================================*/
$("setting-menu").html(`
<div class="setting_menu">
<ul class="nav flex-column">
<!-- Facility Setup  -->
<li class="nav-item"> 
    <a href="javascript:void(0);" class="nav-link active">
    <i class='bx bx-first-aid'></i>
        Facility Setup
    </a>
    <div id="facility">
        <a href="setting.html"><i class='bx bx-terminal'></i></i>Name &
            Location</a>
        <a href="setting-create-insurance.html"><i class='bx bx-user-plus  '  ></i>Add Insurance</a>
        <a href="setting-insurance-setup.html"><i class='bx bx-cog'></i>Insurance Setup</a>
        <a href="setting-create-treatment.html"><i class='bx bxs-clinic'></i>Add
            Treatment</a>
        <a href="setting-create-service.html"><i class='bx bx-layer'></i>Add Services</a>
        <a href="setting-create-cpt.html"><i class='bx bx-layer'></i>Add CPT</a>
        <a href="setting-subtype.html"><i class='bx bx-navigation'  ></i>Service Sub-Type</a>
        <a href="setting-rendering-provider.html"><i class='bx bx-user'></i>Rendering Provider</a>
        <a href="setting-pos.html"><i class='bx bx-home'></i>Place of Service</a>
        <a href="setting-create-staff.html"><i class='bx bx-user-plus'></i>Add Staff Type</a>
        <a href="setting-vendor.html"><i class='bx bx-notification'></i>Vendor Number Setup</a>
        <a href="setting-holiday.html"><i class='bx bx-anchor'></i>Holiday Setup</a>
        <a href="setting-payperiod.html"><i class='bx bxs-credit-card-front'></i>Pay Period</a>
        <a href="setting-logo.html"><i class='bx bx-link-alt'></i>Logo</a>
        <a href="setting-unbillable.html"><i class='bx bx-folder-open'></i>Unbillable Activity</a>
        <a href="setting-unbillable-timesheet.html"><i class='bx bx-folder-open'></i>Unbillable Timesheet</a>
        <a href="setting-create-servicerule.html"><i class='bx bx-file-blank'></i>Create Service Rules</a>
        <a href="setting-staff-setup.html"><i class='bx bx-shield-plus'></i>Staff
            Setup</a>
        <a href="setting-formbuilder.html"><i class='bx bxs-file'></i>Forms Builder</a>
        <a href="setting-formlib.html"><i class='bx bxs-file'></i>Forms & Library</a>
        <a href="setting-businessdoc.html"><i class='bx bx-file-blank'></i>Business Files</a>
        <a href="setting-dataexport.html"><i class='bx bx-upload'></i>Data Import</a>
        <a href="setting-bulk-upload.html"><i class='bx bx-transfer'></i>Bulk Upload</a>
    </div>
</li>
</ul>
</div>
`);
const currentLocation = location.href;
const menuItem = document.querySelectorAll("li a");
const menuLength = menuItem.length;
for (let i = 0; i < menuLength; i++) {
  if (menuItem[i].href == currentLocation) {
    menuItem[i].className = "active";
  }
}
