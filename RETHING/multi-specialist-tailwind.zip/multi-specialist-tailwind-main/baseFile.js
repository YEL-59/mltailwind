
$("my-preloader").html(
	`<div id="loading">
	    <div id="loading-center"></div>
	</div>`
);


/*======================================
Link up with sidebar CSS file
=========================================*/
$("<link/>", {
	rel: "stylesheet",
	type: "text/css",
	href: "./test/navbar.css",
}).appendTo("head");



/*======================================
Sidebar
=========================================*/
$("my-sidebar").html(`
<div class="sidebar close sidebarnew ">
          <section class="home-section ">
            <!-- <div class="">
              <i class='bx bx-menu' ></i>
            </div> -->
          </section>
            <div class="logo-details ">
                
              <a href="" class="mini_logo">
                <img src="/assets/images/favicon.png" class="h-[50px] mx-auto mt-2"  alt="">
                
              </a>
              <span class="logo_name big_logo"><img  src="/assets/images/logo-new.png" class="h-[40px]  mt-5 ml-[30px]" alt=""></span>
            </div>
            <ul class="nav-links">
              <li>
                <a href="/dashboard.html">
                  <i class='bx bx-grid-alt' ></i>
                  <span class="link_name">Dashboard</span>
                </a>
                <ul class="sub-menu blank">
                  <li><a class="link_name" href="#">Category</a></li>
                </ul>
              </li>
              <li>
                <div class="iocn-link">
                  <a href="/appoinment.html">
                    <i class='bx bx-calendar' ></i>
                    <span class="link_name">Appointment</span>
                  </a>
                  <i class='bx bxs-chevron-down arrow' ></i>
                </div>
                <ul class="sub-menu">
                  <li><a class="link_name" href="#">list view</a></li>
                  <li><a href="#">calender view</a></li>
                  <li><a href="/appointment-recurring.html">recurring session</a></li>
                  
                </ul>
              </li>
              <!-- <li>
                <div class="iocn-link">
                  <a href="#">
                    <i class='bx bx-book-alt' ></i>
                    <span class="link_name">Posts</span>
                  </a>
                  <i class='bx bxs-chevron-down arrow' ></i>
                </div>
                <ul class="sub-menu">
                  <li><a class="link_name" href="#">Posts</a></li>
                  <li><a href="#">Web Design</a></li>
                  <li><a href="#">Login Form</a></li>
                  <li><a href="#">Card Design</a></li>
                </ul>
              </li> -->  
              <li>
                <a href="/index.html">
                  <i class='bx bx-user-plus' ></i>
                  <span class="link_name">patient's</span>
                </a>
                <!-- <ul class="sub-menu blank">
                  <li><a class="link_name" href="#">Analytics</a></li>
                </ul> -->
              </li>
              <li>
                <a href="/staff.html">
                  <i class='bx bx-line-chart' ></i>
                  <span class="link_name">staff</span>
                </a>
                <!-- <ul class="sub-menu blank">
                  <li><a class="link_name" href="#">Chart</a></li>
                </ul> -->
              </li>
              <li>
                <div class="iocn-link">
                  <a href="#">
                    <i class='bx bx-user' ></i>
                    <span class="link_name">billing's</span>
                  </a>
                  <i class='bx bxs-chevron-down arrow' ></i>
                </div>
                <ul class="sub-menu">
                  <li><a class="link_name" href="#">billing manager</a></li>
                  <li><a href="#">Ar leader</a></li>
                  <li><a href="#">contact rate</a></li>
                  <li><a href="#">patient statement</a></li>
                </ul>
              </li>
              <li>
                <div class="iocn-link">
                  <a href="payments-eremittance.html">
                    <i class='bx bx-plug' ></i>
                    <span class="link_name">payment's</span>
                  </a>
                  <i class='bx bxs-chevron-down arrow' ></i>
                </div>
                <ul class="sub-menu">
                  <li><a class="link_name" href="#">e-remetance</a></li>
                  <li><a href="payments-eremittance.html">e-remetance</a></li>
                  <li><a href="payments-mremittance.html">m-rementance</a></li>
                  <li><a href="payments-era.html">era manager</a></li>
                  
                </ul>
              </li>
              <li>
                <div class="iocn-link">
                  <a href="#">
                    <i class='bx bx-plug' ></i>
                    <span class="link_name">payroll</span>
                  </a>
                  <i class='bx bxs-chevron-down arrow' ></i>
                </div>
                <ul class="sub-menu">
                  <li><a class="link_name" href="#">processing payroll</a></li>
                  <li><a href="#">timesheet payroll</a></li>
              
                  
                </ul>
              </li>
              <li>
                <a href="/setting.html">
                  <i class='bx bx-cog' ></i>
                  <span class="link_name">report</span>
                </a>
                <!-- <ul class="sub-menu blank">
                  <li><a class="link_name" href="#">Setting</a></li>
                </ul> -->
              </li>
              <li>
              <a href="/accountactivity.html">
                <i class='bx bx-cog' ></i>
                <span class="link_name">Account Activity</span>
              </a>
              <!-- <ul class="sub-menu blank">
                <li><a class="link_name" href="#">Setting</a></li>
              </ul> -->
            </li>
              <li>
                <li>
                  <a href="/setting.html">
                    <i class='bx bx-cog' ></i>
                    <span class="link_name">setting</span>
                  </a>
                  <!-- <ul class="sub-menu blank">
                    <li><a class="link_name" href="#">Setting</a></li>
                  </ul> -->
                </li>
            <!-- <div class="profile-details">
              <div class="profile-content">
                <img src="image/profile.jpg" alt="profileImg">
              </div>
              <div class="name-job">
                <div class="profile_name">Prem Shahi</div>
                <div class="job">Web Desginer</div>
              </div>
              <i class='bx bx-log-out' ></i>
            </div> -->
          </li>
        </ul>
          </div>
          <script>
         let arrow = document.querySelectorAll(".arrow");
         for (var i = 0; i < arrow.length; i++) {
           arrow[i].addEventListener("click", (e)=>{
          let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
          arrowParent.classList.toggle("showMenu");
           });
         }
        // let sidebar = document.querySelector(".sidebar");
        // let sidebarBtn = document.querySelector(".bx-menu");
        // console.log(sidebarBtn);
        // sidebarBtn.addEventListener("click", ()=>{
        //   sidebar.classList.toggle("close");
        // });
        $('.big_logo').hide()
        $(".sidebarnew:first").on("mouseover", function() {
    $(this).removeClass("close");
    $('.mini_logo').hide()
    $('.big_logo').show()
}).on("mouseout", function() {
    $(this).addClass("close");
    $('.big_logo').hide()
    $('.mini_logo').show()
});
        </script> 
`);













$("my-topbar").html(`
<nav
class="
  flex flex-wrap
  items-center
  justify-between
  w-full
  py-4
  md:py-0
  px-4
  text-lg text-gray-700
  bg-white
  shadow-lg
  rounded-full
   mt-2
"
>
<div class="flex gap-2">
  <a href="#">
  <img src="/assets/images/man.jpg" style="height: 35px" class="rounded-full border-2 p-1 " alt=""
  loading="lazy" />
  </a>
  <p class="font-medium"style="color:[#495057];text-shadow: 2px 2px 4px #00000052;">ABC Behavioral Therapy Center</p>
  
</div>



<div class="hidden w-full md:flex md:items-center md:w-auto" id="menu">
  <ul
    class="
      pt-4
      text-base text-gray-700
      md:flex
      md:justify-between 
      md:pt-0"
  >
    <li>
      <a class="md:p-4 py-2 block hover:text-purple-400" href="#"
        ><i class='bx bx-fullscreen' style='color:#089BAB; font-size:22px;'></i></a
      >
    </li>
    <li>
    <div class="relative" data-te-dropdown-ref>
    <a
      class="hidden-arrow  mt-4 flex items-center text-neutral-500 hover:text-neutral-700 focus:text-neutral-700 disabled:text-black/30 dark:text-neutral-200 dark:hover:text-neutral-300 dark:focus:text-neutral-300 [&.active]:text-black/90 dark:[&.active]:text-neutral-400"
      href="#"
      id="dropdownMenuButton1"
      role="button"
      data-te-dropdown-toggle-ref
      aria-expanded="false">
      <i class='bx bx-bell' style='color:#089BAB; font-size:22px;'></i>
     
    </a>
    <ul
      class="absolute left-auto right-0 z-[1000] float-left m-0 mt-1 hidden min-w-max list-none overflow-hidden rounded-lg border-none bg-white bg-clip-padding text-left text-base shadow-lg dark:bg-neutral-700 [&[data-te-dropdown-show]]:block"
      aria-labelledby="dropdownMenuButton1"
      data-te-dropdown-menu-ref>
      <li>
        <a
          class="block w-full whitespace-nowrap bg-transparent py-2 px-4 text-sm font-normal text-neutral-700 hover:bg-neutral-100 active:text-neutral-800 active:no-underline disabled:pointer-events-none disabled:bg-transparent disabled:text-neutral-400 dark:text-neutral-200 dark:hover:bg-white/30"
          href="#"
          data-te-toggle="modal"
  data-te-target="#staticBackdrop"
  data-te-ripple-init
  data-te-ripple-color="light"
          data-te-dropdown-item-ref
          >Action</a
        >
      </li>
      <li>
        <a
          class="block w-full whitespace-nowrap bg-transparent py-2 px-4 text-sm font-normal text-neutral-700 hover:bg-neutral-100 active:text-neutral-800 active:no-underline disabled:pointer-events-none disabled:bg-transparent disabled:text-neutral-400 dark:text-neutral-200 dark:hover:bg-white/30"
          href="#"
          data-te-dropdown-item-ref
          >Another action</a
        >
      </li>
    </ul>
  </div>
    </li>
    <li>
      <a class="md:p-4 py-2 block hover:text-purple-400" href="#"
      
        ><i class='bx bxs-megaphone' style='color:#089BAB; font-size:22px;'></i></a
      >
    </li>
    <li>
      <a class="md:p-4 py-2 block hover:text-purple-400" href="#"
        ><i class='bx bx-download' style='color:#089BAB; font-size:22px;'></i></a
      >
    </li>
    <li>
      <a class="md:p-4 py-2 block hover:text-purple-400" href="#"
        ><i class='bx bxs-bell' style='color:#089BAB; font-size:22px;'></i></a
      >
    </li>
    <li>
    <div class="dropdown relative mt-4">
    <a class="
          text-gray-500
          hover:text-gray-700
          focus:text-gray-700
          mr-4
          dropdown-toggle
          hidden-arrow
          flex items-center
        " href="#" id="dropdownMenuButton1" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        
        <i class='bx bx-lock-open' style='color:#089BAB; font-size:22px;'></i>
    </a>
    <ul class="
      dropdown-menu
      min-w-max
      absolute
      hidden
      bg-white
      text-base
      z-50
      float-left
      
      list-none
      text-left
      rounded-lg
      shadow-lg
     
      hidden
      m-0
      bg-clip-padding
      border-none
     
    " aria-labelledby="dropdownMenuButton1">
      <li>
        <a class="
          dropdown-item
          text-sm
          py-2
          px-4
          font-normal
          block
          w-full
          whitespace-nowrap
          bg-transparent
          text-gray-700
          hover:bg-gray-100
        " href="#">Action</a>
      </li>
      <li>
        <a class="
          dropdown-item
          text-sm
          py-2
          px-4
          font-normal
          block
          w-full
          whitespace-nowrap
          bg-transparent
          text-gray-700
          hover:bg-gray-100
        " href="#">Another action</a>
      </li>
      <li>
        <a class="
          dropdown-item
          text-sm
          py-2
          px-4
          font-normal
          block
          w-full
          whitespace-nowrap
          bg-transparent
          text-gray-700
          hover:bg-gray-100
        " href="#">Something else here</a>
      </li>
    </ul>
  </div>
    </li>
    <li class="md:p-3 py-2 block">
    <div class="flex gap-2">
    <a href="#">
    <img src="/assets/images/man.jpg" style="height: 35px" class="rounded-full border-2 p-1 " alt=""
    loading="lazy" />
    </a>
    <div>
    <p class="font-bold "style="color:[#495057];">Bini jets</p>
    <p class="font-thin text-xs"style="color:[#089BAB];">Available</p>
    </div>
    
  </div>

    </li>
  </ul>
</div>
</nav>


<div
  data-te-modal-init
  class="fixed top-0 left-0 z-[1055] hidden h-full w-full overflow-y-auto overflow-x-hidden outline-none"
  id="staticBackdrop"
  data-te-backdrop="static"
  data-te-keyboard="false"
  tabindex="-1"
  aria-labelledby="staticBackdropLabel"
  aria-hidden="true">
  <div
    data-te-modal-dialog-ref
    class="pointer-events-none relative w-auto translate-y-[-50px] opacity-0 transition-all duration-300 ease-in-out min-[576px]:mx-auto min-[576px]:mt-7 min-[576px]:max-w-[500px]">
    <div
      class="min-[576px]:shadow-[0_0.5rem_1rem_rgba(#000, 0.15)] pointer-events-auto relative flex w-full flex-col rounded-md border-none bg-white bg-clip-padding text-current shadow-lg outline-none dark:bg-neutral-600">
      <div
        class="flex flex-shrink-0 items-center justify-between rounded-t-md border-b-2 border-neutral-100 border-opacity-100 p-4 dark:border-opacity-50">
        <h5
          class="text-xl font-medium leading-normal text-neutral-800 dark:text-neutral-200"
          id="exampleModalLabel">
          Modal title
        </h5>
        <button
          type="button"
          class="box-content rounded-none border-none hover:no-underline hover:opacity-75 focus:opacity-100 focus:shadow-none focus:outline-none"
          data-te-modal-dismiss
          aria-label="Close">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="h-6 w-6">
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      <div data-te-modal-body-ref class="relative p-4">...</div>
      <div
        class="flex flex-shrink-0 flex-wrap items-center justify-end rounded-b-md border-t-2 border-neutral-100 border-opacity-100 p-4 dark:border-opacity-50">
        <button
          type="button"
          class="inline-block rounded bg-primary-100 px-6 pt-2.5 pb-2 text-xs font-medium uppercase leading-normal text-primary-700 transition duration-150 ease-in-out hover:bg-primary-accent-100 focus:bg-primary-accent-100 focus:outline-none focus:ring-0 active:bg-primary-accent-200"
          data-te-modal-dismiss
          data-te-ripple-init
          data-te-ripple-color="light">
          Close
        </button>
        <button
          type="button"
          class="ml-1 inline-block rounded bg-primary px-6 pt-2.5 pb-2 text-xs font-medium uppercase leading-normal text-white shadow-[0_4px_9px_-4px_#3b71ca] transition duration-150 ease-in-out hover:bg-primary-600 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)]"
          data-te-ripple-init
          data-te-ripple-color="light">
          Understood
        </button>
      </div>
    </div>
  </div>
</div>






`);


//<p class="font-thin text-xs "style="color:[#495057];">Bini jets</p>