const picker = MCDatepicker.create({
	el: '#fromdate',
	dateFormat: 'mm/dd/yyyy'
});
const picker2 = MCDatepicker.create({
	el: '#endate',
	dateFormat: 'mm/dd/yyyy'
});