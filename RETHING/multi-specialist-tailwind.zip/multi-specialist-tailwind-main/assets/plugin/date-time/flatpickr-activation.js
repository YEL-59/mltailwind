$("input[type='datetime-local']").flatpickr({
    enableTime: true,
    dateFormat: "Y-m-d h:i K"
});

