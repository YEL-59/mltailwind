/*======================================
Staff Menu
=========================================*/
$('staff-menu').html(`
<ul class="nav  employee_menu">
	<!-- Profile Picture -->
	<li class="nav-item  text-center">
		<div class="profile-pic">
			<img src="/assets/images/man.jpg" class="" id="photo" alt="">
			<input type="file" id="file" class="hidden">
			<label for="file" id="uploadBtn">Upload</label>
		</div>
	</li>
	<!--/ Profile Picture -->
	<li class="nav-item">
		<a class="nav-link" href="staff-edit.html">Bio’s</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-contactDetails.html">Contact Info</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-credentials.html">Credentials</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-department.html">Department Supervisor(s)</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-payrollRate.html">Payroll Setup</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-otherSetup.html">Other Setup</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-tracking.html">Leave Tracking</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-payorExclusion.html">Insurance Exclusion(s)</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-subActivity.html">Service Sub-Type
			Exclusions</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-clientExclusion.html">Patient Exclusion</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-portal.html">Staff Portal</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="staff-activity.html">Staff Activity</a>
	</li>
</ul>
`);
const staffLoc = window.location.href;
const staffMenu = document.querySelectorAll('.employee_menu .nav-link');
const staffMenuLength = staffMenu.length;
for (let i = 0; i < staffMenuLength; i++) {
	if (staffMenu[i].href == staffLoc) {
		staffMenu[i].className = "active";
	}
}
const imgDiv = document.querySelector('.profile-pic-div');
const img = document.querySelector('#photo');
const file = document.querySelector('#file');
const uploadBtn = document.querySelector('#uploadBtn');
file.addEventListener('change', function () {
	const choosedFile = this.files[0];
	if (choosedFile) {
		const reader = new FileReader();
		reader.addEventListener('load', function () {
			img.setAttribute('src', reader.result);
		});
		reader.readAsDataURL(choosedFile);
	}
});