# multi-specialist-tailwind.
clone the full design of tpms in tailwind and use of jquery


